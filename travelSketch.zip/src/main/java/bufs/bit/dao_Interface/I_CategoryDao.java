package bufs.bit.dao_Interface;

import java.util.List;

import bufs.bit.domain.CategoryVO;

public interface I_CategoryDao {
	void 	Create(CategoryVO vo);
	CategoryVO Read  (CategoryVO vo);	
	void 	Update(CategoryVO vo);
	void 	Delete(CategoryVO vo);
	
	List<CategoryVO> listAll ();
	String cname(int cid);
	List cid(String cname);
}
