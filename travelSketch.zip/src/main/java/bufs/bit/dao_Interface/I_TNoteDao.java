package bufs.bit.dao_Interface;

import java.util.List;

import bufs.bit.domain.NoteReplyVO;
import bufs.bit.domain.T_NoteVO;
import bufs.bit.domain.fileVO;
import bufs.bit.domain.pageVO;

public interface I_TNoteDao {
	void add(T_NoteVO vo);
	List<T_NoteVO> NoteList(int pageno);
	int pageCount();
	T_NoteVO NoteDetail(int note_no);
	void updateNote (T_NoteVO vo);
	void delNote(int note_no);
	
	void NoteReply(NoteReplyVO vo);
	List<NoteReplyVO> NoteReplyList(int note_no);
	void DelNoteReply(int nrepyno);
	int replyCount(int noteno);
	void addAttach(fileVO vo) throws Exception;
	List<String> getAttach(int note_no ) throws Exception;
	Integer lastNo();
}
