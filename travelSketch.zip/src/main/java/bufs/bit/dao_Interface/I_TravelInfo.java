package bufs.bit.dao_Interface;

import java.util.List;

import bufs.bit.domain.T_InfoVO;

public interface I_TravelInfo {
	void create(T_InfoVO vo);
	void update(T_InfoVO vo);
	void delete(T_InfoVO vo);
	T_InfoVO selectTravelInfo_user(T_InfoVO vo);
	List<T_InfoVO> listAll(T_InfoVO vo);
	
	T_InfoVO selectOne(String userid);
	
}
