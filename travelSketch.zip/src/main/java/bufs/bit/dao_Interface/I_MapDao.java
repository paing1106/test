package bufs.bit.dao_Interface;


import java.util.List;

import bufs.bit.domain.ItemVO;

public interface I_MapDao {
List<ItemVO> rAround (ItemVO vo);
List<ItemVO> sAround (ItemVO vo);
List<ItemVO> cAround (ItemVO vo);
List<ItemVO> vAround (ItemVO vo);
List<ItemVO> hAround (ItemVO vo);
}
