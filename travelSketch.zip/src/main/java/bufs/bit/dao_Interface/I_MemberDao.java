package bufs.bit.dao_Interface;

import java.util.List;

import bufs.bit.domain.MemberVO;

public interface I_MemberDao {
	void 	adduser(MemberVO vo);
	MemberVO selectuser  (MemberVO vo);	
	void 	Update(MemberVO vo);
	void 	Delete(MemberVO vo);
	
	List<MemberVO> listAll ();
	
	int authcheck(String userid);
	int logincheck(MemberVO vo);
}
