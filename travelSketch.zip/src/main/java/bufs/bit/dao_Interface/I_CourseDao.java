package bufs.bit.dao_Interface;

import java.util.List;

import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseListVO;
import bufs.bit.domain.CourseVO;

public interface I_CourseDao {
	void add1(CourseVO vo);
	int add2 (CourseVO vo);
	
	void addlistR(CourseListVO vo);
	void addlistH(CourseListVO vo);
	void addlistV(CourseListVO vo);
	void addlistC(CourseListVO vo);
	void addlistS(CourseListVO vo);
	
	List<CourseVO> idlist(String userid);
	List<CourseVO> nolist(int course_no);
	
	List<CourseListJoinVO> courseListR(int course_no);
	List<CourseListJoinVO> courseListH(int course_no);
	List<CourseListJoinVO> courseListV(int course_no);
	List<CourseListJoinVO> courseListC(int course_no);
	List<CourseListJoinVO> courseListS(int course_no);
	
	void delete1(int course_no);
	void delete2(int course_no);
	
	int count(int course_no);
	
	void deletOne(CourseListVO vo);
	
	CourseVO lastCourse(String userid);
	
	void delRest(CourseListVO vo);
	void delHotel(CourseListVO vo);
	void delView(CourseListVO vo);
	void delCulture(CourseListVO vo);
	void delShop(CourseListVO vo);
}
