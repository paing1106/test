package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao_Interface.I_BoardDao;
import bufs.bit.domain.ReplyVO;
import bufs.bit.service_Interface.I_BoardService;

@Service
public class BoardService implements I_BoardService {

	@Inject
	private I_BoardDao BoardDao;

	@Override
	public void addReply1(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.addReply1(vo);	
	}

	@Override
	public int addReply2(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.addReply2(vo);
	}

	@Override
	public void addReply3(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.addReply3(vo);
	}

	@Override
	public List<ReplyVO> culReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.culReply(vo);
	}

	@Override
	public List<ReplyVO> viewReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.viewReply(vo);
	}

	@Override
	public List<ReplyVO> restReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.restReply(vo);
	}

	@Override
	public List<ReplyVO> shopReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.shopReply(vo);
	}

	@Override
	public List<ReplyVO> hotelReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.hotelReply(vo);
	}

	@Override
	public void insertCulReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.insertCulReply(vo);
	}

	@Override
	public void insertViewReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.insertViewReply(vo);
	}

	@Override
	public void insertRestReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.insertRestReply(vo);
	}

	@Override
	public void insertShopReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.insertShopReply(vo);
	}

	@Override
	public void insertHotelReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		BoardDao.insertHotelReply(vo);
	}

	@Override
	public int culCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.culCount(vo);
	}

	@Override
	public int viewCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.viewCount(vo);
	}

	@Override
	public int restCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.restCount(vo);
	}

	@Override
	public int shopCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.shopCount(vo);
	}

	@Override
	public int hotelCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return BoardDao.hotelCount(vo);
	}

	
	@Override
	public List<ReplyVO> ItemReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		int cid = vo.getCid();
		switch(cid){
		case 1 :  vo.setCategory("restaurant");	vo.setItemno(vo.getRestaurant());	
			break;
		case 2 :  vo.setCategory("hotel"); vo.setItemno(vo.getHotel());
			break;
		case 3 :  vo.setCategory("viewpoint"); vo.setItemno(vo.getViewpoint());
			break;
		case 4 :  vo.setCategory("culture"); vo.setItemno(vo.getCulture());
			break;
		case 5 :  vo.setCategory("shop"); vo.setItemno(vo.getShop());
			break;		
		}
		return BoardDao.ItemReply(vo);
	}

	



}
