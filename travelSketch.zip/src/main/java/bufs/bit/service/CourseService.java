package bufs.bit.service;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao.CourseDao;
import bufs.bit.dao_Interface.I_CourseDao;
import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseListVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.service_Interface.I_CourseService;

@Service
public class CourseService implements I_CourseService {

	@Inject
	private I_CourseDao courseDao;

	@Override
	public void add1(CourseVO vo) {
		// TODO Auto-generated method stub
		courseDao.add1(vo);
	}

	@Override
	public int add2(CourseVO vo) {
		// TODO Auto-generated method stub
		return courseDao.add2(vo);
	}

	@Override
	public void addlistR(CourseListVO vo) {
		// TODO Auto-generated method stub
		courseDao.addlistR(vo);
	}

	@Override
	public void addlistH(CourseListVO vo) {
		// TODO Auto-generated method stub
		courseDao.addlistH(vo);
	}

	@Override
	public void addlistV(CourseListVO vo) {
		// TODO Auto-generated method stub
		courseDao.addlistV(vo);
	}

	@Override
	public void addlistC(CourseListVO vo) {
		// TODO Auto-generated method stub
		courseDao.addlistC(vo);
	}

	@Override
	public void addlistS(CourseListVO vo) {
		// TODO Auto-generated method stub
		courseDao.addlistS(vo);
	}

	@Override
	public List<CourseVO> nolist(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.nolist(course_no);
	}

	@Override
	public List<CourseVO> idlist(String userid) {
		// TODO Auto-generated method stub
		return courseDao.idlist(userid);
	}

	@Override
	public void delete(int course_no) {
		// TODO Auto-generated method stub
		courseDao.delete1(course_no);
		courseDao.delete2(course_no);
	}

	@Override
	public int count(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.count(course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListR(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.courseListR(course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListH(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.courseListH(course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListV(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.courseListV(course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListC(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.courseListC(course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListS(int course_no) {
		// TODO Auto-generated method stub
		return courseDao.courseListS(course_no);
	}

	@Override
	public void deletOne(CourseListVO vo, int cid) {
		// TODO Auto-generated method stub
		// courseDao.deletOne(vo);
		switch (cid) {
		case 1:
			courseDao.delRest(vo);
			break;
		case 2:
			courseDao.delHotel(vo);
			break;
		case 3:
			courseDao.delView(vo);
			break;
		case 4:
			courseDao.delCulture(vo);
			break;
		case 5:
			courseDao.delShop(vo);
			break;
		}
	}

	@Override
	public CourseVO lastCourse(String userid) {
		// TODO Auto-generated method stub
		return courseDao.lastCourse(userid);
	}

	@Override
	public void addOne(int courseno, int itemno, int cid) {
		// TODO Auto-generated method stub
		CourseListVO vo = new CourseListVO();
		vo.setCourse_no(courseno);
		switch (cid) {
		case 1:
			vo.setRestaurant(itemno);
			courseDao.addlistR(vo);
			break;
		case 2:
			vo.setHotel(itemno);
			courseDao.addlistH(vo);
			break;
		case 3:
			vo.setViewpoint(itemno);
			courseDao.addlistV(vo);
			break;
		case 4:
			vo.setCulture(itemno);
			courseDao.addlistC(vo);
			break;
		case 5:
			vo.setShop(itemno);
			courseDao.addlistS(vo);
			break;
		}

	}

	@Override
	public List<SemiItemVO> listAll(int courseno) {
		// TODO Auto-generated method stub
		ArrayList<CourseListJoinVO> temp = new ArrayList<CourseListJoinVO>();
		temp.addAll(courseDao.courseListH(courseno));
		temp.addAll(courseDao.courseListR(courseno));
		temp.addAll(courseDao.courseListC(courseno));
		temp.addAll(courseDao.courseListV(courseno));
		temp.addAll(courseDao.courseListS(courseno));

		ArrayList<SemiItemVO> list = new ArrayList<SemiItemVO>();
		for (int i = 0; i < temp.size(); i++) {
			SemiItemVO vo = new SemiItemVO();
			int cid = temp.get(i).getCid();
			switch (cid) {
			case 1:
				vo.setNo(temp.get(i).getRitem_no());
				vo.setName(temp.get(i).getRname());
				break;
			case 2:
				vo.setNo(temp.get(i).getHitem_no());
				vo.setName(temp.get(i).getHname());
				break;
			case 3:
				vo.setNo(temp.get(i).getVitem_no());
				vo.setName(temp.get(i).getVname());
				break;
			case 4:
				vo.setNo(temp.get(i).getCitem_no());
				vo.setName(temp.get(i).getCname());
				break;
			case 5:
				vo.setNo(temp.get(i).getSitem_no());
				vo.setName(temp.get(i).getSname());
				break;
			}
			vo.setCategory(temp.get(i).getCname());
			vo.setCid(cid);
			String addr = temp.get(i).getAddr();
			if (temp.get(i).getAddr2() != null) {
				addr = addr + temp.get(i).getAddr2();
			}
			vo.setAddr(addr);
			vo.setTel(temp.get(i).getTel());
			vo.setContents(temp.get(i).getContents());
			vo.setMainimg(temp.get(i).getMainimg());
			list.add(vo);
		}
		return list;
	}

}
