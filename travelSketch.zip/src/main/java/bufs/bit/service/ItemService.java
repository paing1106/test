package bufs.bit.service;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao.ItemDao;
import bufs.bit.dao_Interface.I_CourseDao;
import bufs.bit.dao_Interface.I_ItemDao;
import bufs.bit.dao_Interface.I_TravelInfo;
import bufs.bit.domain.AroundVO;
import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.ItemVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.domain.T_InfoVO;
import bufs.bit.domain.pageVO;
import bufs.bit.domain.searchVO;
import bufs.bit.domain.topVO;
import bufs.bit.domain.visibleVO;
import bufs.bit.service_Interface.I_CourseService;
import bufs.bit.service_Interface.I_ItemService;
import bufs.bit.service_Interface.I_TravelInfoService;

@Service
public class ItemService implements I_ItemService {

	@Inject
	private I_ItemDao ItemDao;

	@Inject
	private I_TravelInfo infoDao;

	@Inject
	private I_CourseDao courseDao;

	@Override
	public List<ItemVO> ShopList(pageVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.ShopList(vo);
	}

	@Override
	public List<ItemVO> RestList(pageVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.RestList(vo);
	}

	@Override
	public List<ItemVO> ViewList(pageVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.ViewList(vo);
	}

	@Override
	public List<ItemVO> CulList(pageVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.CulList(vo);
	}

	@Override
	public List<ItemVO> HotelList(pageVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.HotelList(vo);
	}

	@Override
	public List<ItemVO> ShopDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.ShopDetail(vo);
	}

	@Override
	public List<ItemVO> RestDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.RestDetail(vo);
	}

	@Override
	public List<ItemVO> ViewDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.ViewDetail(vo);
	}

	@Override
	public List<ItemVO> CulDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.CulDetail(vo);
	}

	@Override
	public List<ItemVO> HotelDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.HotelDetail(vo);
	}

	// 카운트
	@Override
	public int ShopCount(int visible) {
		// TODO Auto-generated method stub
		return ItemDao.ShopCount(visible);
	}

	@Override
	public int RestCount(int visible) {
		// TODO Auto-generated method stub
		return ItemDao.RestCount(visible);
	}

	@Override
	public int ViewCount(int visible) {
		// TODO Auto-generated method stub
		return ItemDao.ViewCount(visible);
	}

	@Override
	public int CulCount(int visible) {
		// TODO Auto-generated method stub
		return ItemDao.CulCount(visible);
	}

	@Override
	public int HotelCount(int visible) {
		// TODO Auto-generated method stub
		return ItemDao.HotelCount(visible);
	}

	@Override
	public void addShop(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.addShop(vo);
	}

	@Override
	public void addRest(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.addRest(vo);
	}

	@Override
	public void addView(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.addView(vo);
	}

	@Override
	public void addCul(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.addCul(vo);
	}

	@Override
	public void addHotel(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.addHotel(vo);
	}

	@Override
	public void updateShop(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.updateShop(vo);
	}

	@Override
	public void updateRest(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.updateRest(vo);
	}

	@Override
	public void updateView(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.updateView(vo);
	}

	@Override
	public void updateCul(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.updateCul(vo);
	}

	@Override
	public void updateHotel(ItemVO vo) {
		// TODO Auto-generated method stub
		ItemDao.updateHotel(vo);
	}

	@Override
	public String checkVisibleShop(int vo) {
		// TODO Auto-generated method stub
		return ItemDao.checkVisibleShop(vo);
	}

	@Override
	public String checkVisibleRest(int vo) {
		// TODO Auto-generated method stub
		return ItemDao.checkVisibleRest(vo);
	}

	@Override
	public String checkVisibleView(int vo) {
		// TODO Auto-generated method stub
		return ItemDao.checkVisibleView(vo);
	}

	@Override
	public String checkVisibleCul(int vo) {
		// TODO Auto-generated method stub
		return ItemDao.checkVisibleCul(vo);
	}

	@Override
	public String checkVisibleHotel(int vo) {
		// TODO Auto-generated method stub
		return ItemDao.checkVisibleHotel(vo);
	}

	@Override
	public List<visibleVO> visible() {
		// TODO Auto-generated method stub
		return ItemDao.visible();
	}

	@Override
	public List<ItemVO> sname(String sname) {
		// TODO Auto-generated method stub
		return ItemDao.sname(sname);
	}

	@Override
	public List<ItemVO> rname(String rname) {
		// TODO Auto-generated method stub
		return ItemDao.rname(rname);
	}

	@Override
	public List<ItemVO> vname(String vname) {
		// TODO Auto-generated method stub
		return ItemDao.vname(vname);
	}

	@Override
	public List<ItemVO> cname(String cname) {
		// TODO Auto-generated method stub
		return ItemDao.cname(cname);
	}

	@Override
	public List<ItemVO> hname(String hname) {
		// TODO Auto-generated method stub
		return ItemDao.hname(hname);
	}

	@Override
	public List<ItemVO> search(searchVO vo) {
		// TODO Auto-generated method stub
		return ItemDao.search(vo);
	}

	@Override
	public List<ItemVO> Around(SemiItemVO vo, int type) {
		// TODO Auto-generated method stub
		List<ItemVO> temp = new ArrayList<ItemVO>(); // 들어온 itemno 의 디테일이 들어있음
		ItemVO itemVO = new ItemVO();
		AroundVO aroundVO = new AroundVO();
		int cid = vo.getCid();
		switch (cid) {
		case 1:
			itemVO.setRitem_no(vo.getNo());
			temp.addAll(ItemDao.RestDetail(itemVO));
			break;
		case 2:
			itemVO.setHitem_no(vo.getNo());
			temp.addAll(ItemDao.HotelDetail(itemVO));
			break;
		case 3:
			itemVO.setVitem_no(vo.getNo());
			temp.addAll(ItemDao.ViewDetail(itemVO));
			break;
		case 4:
			itemVO.setCitem_no(vo.getNo());
			temp.addAll(ItemDao.CulDetail(itemVO));
			break;
		case 5:
			itemVO.setSitem_no(vo.getNo());
			temp.addAll(ItemDao.ShopDetail(itemVO));
			break;
		}

		for (int i = 0; i < temp.size(); i++) {
			aroundVO.setLatitude(temp.get(i).getLatitude());
			aroundVO.setLongtitude(temp.get(i).getLongtitude());
		}

		List<ItemVO> around = new ArrayList<ItemVO>();

		aroundVO.setCategory("restaurant");
		around.addAll(ItemDao.Around(aroundVO, type));
		aroundVO.setCategory("hotel");
		around.addAll(ItemDao.Around(aroundVO, type));
		aroundVO.setCategory("viewpoint");
		around.addAll(ItemDao.Around(aroundVO, type));
		aroundVO.setCategory("culture");
		around.addAll(ItemDao.Around(aroundVO, type));
		aroundVO.setCategory("shop");
		around.addAll(ItemDao.Around(aroundVO, type));

		return around;
	}

	String category;

	@Override
	public List<ItemVO> topten(int cid) {
		// TODO Auto-generated method stub
		topVO vo = new topVO();
		vo.setCid(cid);
		return ItemDao.topten(vo);
	}

	@Override
	public List<ItemVO> recommend(int course_no, String userid) {
		// TODO Auto-generated method stub
		ArrayList<CourseListJoinVO> temp = new ArrayList<CourseListJoinVO>();
		temp.addAll(courseDao.courseListR(course_no));
		temp.addAll(courseDao.courseListH(course_no));
		temp.addAll(courseDao.courseListV(course_no));
		temp.addAll(courseDao.courseListC(course_no));
		temp.addAll(courseDao.courseListS(course_no));

		ArrayList<ItemVO> list = new ArrayList<ItemVO>();
		AroundVO aroundVO = new AroundVO();
		aroundVO.setLatitude(Double.parseDouble(temp.get(temp.size()-1).getLatitude()));
		aroundVO.setLongtitude(Double.parseDouble(temp.get(temp.size()-1).getLongtitude()));
		
		T_InfoVO infoVO =  infoDao.selectOne(userid);
		String trans = infoVO.getTransport();	
		if(trans.equals("car")){aroundVO.setType(4);}
		else if(trans.equals("bus")){aroundVO.setType(3);}
		else if(trans.equals("bicycle")){aroundVO.setType(2);}
		else if(trans.equals("walking")){aroundVO.setType(1);}
		
		int cid = infoVO.getCid();
		
		if(cid != 1){
		aroundVO.setCategory("RESTAURANT");
		list.addAll(ItemDao.recommend(aroundVO));
		}
		if (cid != 2){
		aroundVO.setCategory("HOTEL");
		list.addAll(ItemDao.recommend(aroundVO));
		}
		if (cid != 3){
		aroundVO.setCategory("VIEWPOINT");
		list.addAll(ItemDao.recommend(aroundVO));
		}
		if (cid != 4){
		aroundVO.setCategory("CULTURE");
		list.addAll(ItemDao.recommend(aroundVO));
		}
		if (cid != 5){
		aroundVO.setCategory("SHOP");
		list.addAll(ItemDao.recommend(aroundVO));
		}
		
		return list;
	}

	// RHVCS

}
