package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao_Interface.I_FavoriteDao;
import bufs.bit.domain.FavoriteVO;
import bufs.bit.service_Interface.I_FavoriteService;

@Service
public class FavoriteService implements I_FavoriteService{

	@Inject
	private I_FavoriteDao dao;
	
	@Override
	public void create(FavoriteVO vo) {
		// TODO Auto-generated method stub
		dao.create(vo);
	}

	@Override
	public void update(FavoriteVO vo) {
		// TODO Auto-generated method stub
		dao.update(vo);
	}

	@Override
	public void delete(FavoriteVO vo) {
		// TODO Auto-generated method stub
		dao.delete(vo);
	}

	@Override
	public FavoriteVO selectFavorite(FavoriteVO vo) {
		// TODO Auto-generated method stub
		return dao.selectFavorite(vo);
	}

	@Override
	public List<FavoriteVO> listAll(FavoriteVO vo) {
		// TODO Auto-generated method stub
		return dao.listAll(vo);
	}

}
