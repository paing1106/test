package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao_Interface.I_TNoteDao;
import bufs.bit.domain.NoteReplyVO;
import bufs.bit.domain.T_NoteVO;
import bufs.bit.domain.fileVO;
import bufs.bit.service_Interface.I_TNoteService;

@Service
public class TNoteService implements  I_TNoteService{
	@Inject
	private I_TNoteDao TNoteDao; 
	/*
	@Override
	public void add(T_NoteVO vo) {
		// TODO Auto-generated method stub
		TNoteDao.add(vo);
	}*/
	
	@Override
	public void add(T_NoteVO vo) throws Exception{
		// TODO Auto-generated method stub
		TNoteDao.add(vo);
		
		String[] files = vo.getFiles();
		fileVO fileVO = new fileVO();
		Integer LastNo = TNoteDao.lastNo();
		fileVO.setNote_no(LastNo);
		if(files == null){ return; }
		for (int i = 0; i < files.length; i++) {
			String fullname = files[i];
			fileVO.setFullname(fullname);
			TNoteDao.addAttach(fileVO);
		}
		
	}

	@Override
	public List<T_NoteVO> NoteList(int pageno) {
		// TODO Auto-generated method stub
		return TNoteDao.NoteList(pageno);
	}
	
	@Override
	public int pageCount() {
		// TODO Auto-generated method stub
		return TNoteDao.pageCount();
	}

	@Override
	public T_NoteVO NoteDetail(int note_no) {
		// TODO Auto-generated method stub
		return TNoteDao.NoteDetail(note_no);
	}

	@Override
	public void updateNote(T_NoteVO vo) {
		// TODO Auto-generated method stub
		TNoteDao.updateNote(vo);
	}

	@Override
	public void delNote(int note_no) {
		// TODO Auto-generated method stub
		TNoteDao.delNote(note_no);
	}

	@Override
	public void NoteReply(NoteReplyVO vo) {
		// TODO Auto-generated method stub
		TNoteDao.NoteReply(vo);
	}

	@Override
	public List<NoteReplyVO> NoteReplyList(int note_no) {
		// TODO Auto-generated method stub
		return TNoteDao.NoteReplyList(note_no);
	}

	@Override
	public void DelNoteReply(int nrepyno) {
		// TODO Auto-generated method stub
		TNoteDao.DelNoteReply(nrepyno);
	}

	@Override
	public int replyCount(int noteno) {
		// TODO Auto-generated method stub
		return TNoteDao.replyCount(noteno);
	}

	@Override
	public List<String> getAttach(int note_no) throws Exception {
		// TODO Auto-generated method stub
		return TNoteDao.getAttach(note_no);
	}

}
