package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao_Interface.I_CategoryDao;
import bufs.bit.domain.CategoryVO;
import bufs.bit.service_Interface.I_CategoryService;

@Service
public class CategoryService implements I_CategoryService {

	@Inject
	private I_CategoryDao dao;
	
	@Override
	public void register(CategoryVO category) {
		// TODO Auto-generated method stub
		dao.Create(category);
	}

	@Override
	public CategoryVO read(CategoryVO category) {
		// TODO Auto-generated method stub
		return dao.Read(category);
	}

	@Override
	public void modify(CategoryVO category) {
		// TODO Auto-generated method stub
		dao.Update(category);
	}

	@Override
	public void remove(CategoryVO category) {
		// TODO Auto-generated method stub
		dao.Delete(category);
	}

	@Override
	public List<CategoryVO> listAll() {
		// TODO Auto-generated method stub
		return dao.listAll();
	}

	@Override
	public String cname(int cid) {
		// TODO Auto-generated method stub
		return dao.cname(cid);
	}

	@Override
	public List cid(String cname) {
		// TODO Auto-generated method stub
		return dao.cid(cname);
	}

}
