package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;


import bufs.bit.dao_Interface.I_TravelInfo;
import bufs.bit.domain.T_InfoVO;
import bufs.bit.service_Interface.I_TravelInfoService;

@Service
public class TInfoService implements I_TravelInfoService{

	@Inject
	private I_TravelInfo dao;

	@Override
	public void create(T_InfoVO vo) {
		// TODO Auto-generated method stub
		dao.create(vo);		
	}

	@Override
	public void update(T_InfoVO vo) {
		// TODO Auto-generated method stub
		dao.update(vo);
	}

	@Override
	public void delete(T_InfoVO vo) {
		// TODO Auto-generated method stub
		dao.delete(vo);
	}

	@Override
	public T_InfoVO selectTravelInfo_user(T_InfoVO vo) {
		// TODO Auto-generated method stub
		return dao.selectTravelInfo_user(vo);
	}

	@Override
	public List<T_InfoVO> listAll(T_InfoVO vo) {
		// TODO Auto-generated method stub
		return dao.listAll(vo);
	}

	@Override
	public T_InfoVO selectOne(String userid) {
		// TODO Auto-generated method stub
		return dao.selectOne(userid);
	}

}
