package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao.MemberDao;
import bufs.bit.dao_Interface.I_MemberDao;
import bufs.bit.domain.MemberVO;
import bufs.bit.service_Interface.I_MemberService;

@Service
public class MemberService implements I_MemberService {

	@Inject
	private I_MemberDao dao;
		
	@Override
	public void adduser(MemberVO vo) {
		// TODO Auto-generated method stub
		dao.adduser(vo);
	}

	@Override
	public MemberVO selectuser(MemberVO vo) {
		// TODO Auto-generated method stub
		return dao.selectuser(vo);
	}

	@Override
	public void update(MemberVO vo) {
		// TODO Auto-generated method stub
		dao.Update(vo);
	}

	@Override
	public void remove(MemberVO vo) {
		// TODO Auto-generated method stub
		dao.Delete(vo);
	}

	@Override
	public List<MemberVO> listAll() {
		// TODO Auto-generated method stub
		return dao.listAll();
	}

	@Override
	public int authcheck(String userid) {
		// TODO Auto-generated method stub
		return dao.authcheck(userid);
	}

	@Override
	public int logincheck(MemberVO vo) {
		// TODO Auto-generated method stub
		return dao.logincheck(vo);
	}
	
	

}
