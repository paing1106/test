package bufs.bit.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import bufs.bit.dao_Interface.I_MapDao;
import bufs.bit.domain.ItemVO;
import bufs.bit.service_Interface.I_MapService;
@Service
public class MapService implements I_MapService {

	@Inject
	private I_MapDao mapDao;
	@Override
	public List<ItemVO> rAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return mapDao.rAround(vo);
	}

	@Override
	public List<ItemVO> sAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return mapDao.sAround(vo);
	}

	@Override
	public List<ItemVO> cAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return mapDao.cAround(vo);
	}

	@Override
	public List<ItemVO> vAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return mapDao.vAround(vo);
	}

	@Override
	public List<ItemVO> hAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return mapDao.hAround(vo);
	}

}
