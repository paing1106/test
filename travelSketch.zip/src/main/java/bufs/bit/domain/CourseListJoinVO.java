package bufs.bit.domain;

public class CourseListJoinVO {
	private String rname;
	private String vname;
	private String sname;
	private String cname;
	private String hname;
	private String latitude;
	private String longtitude;	
	private int course_no;
	private int cid;
	private int ritem_no;
	private int hitem_no;
	private int vitem_no;
	private int citem_no;
	private int sitem_no;
	private String mainimg;
	private String contents;
	private String addr;
	private String addr2;
	private String tel;
	
	
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getAddr2() {
		return addr2;
	}
	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}
	public String getMainimg() {
		return mainimg;
	}
	public void setMainimg(String mainimg) {
		this.mainimg = mainimg;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(String longtitude) {
		this.longtitude = longtitude;
	}
	public int getCourse_no() {
		return course_no;
	}
	public int getRitem_no() {
		return ritem_no;
	}
	public void setRitem_no(int ritem_no) {
		this.ritem_no = ritem_no;
	}
	public int getHitem_no() {
		return hitem_no;
	}
	public void setHitem_no(int hitem_no) {
		this.hitem_no = hitem_no;
	}
	public int getVitem_no() {
		return vitem_no;
	}
	public void setVitem_no(int vitem_no) {
		this.vitem_no = vitem_no;
	}
	public int getCitem_no() {
		return citem_no;
	}
	public void setCitem_no(int citem_no) {
		this.citem_no = citem_no;
	}
	public int getSitem_no() {
		return sitem_no;
	}
	public void setSitem_no(int sitem_no) {
		this.sitem_no = sitem_no;
	}
	public void setCourse_no(int course_no) {
		this.course_no = course_no;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}


}
