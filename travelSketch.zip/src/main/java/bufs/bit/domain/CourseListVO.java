package bufs.bit.domain;

public class CourseListVO {
	private int Course_no;
	private int rank;
	private int count;
	private int restaurant;
	private int hotel;
	private int shop;
	private int culture;
	private int viewpoint;
	public int getCourse_no() {
		return Course_no;
	}
	public void setCourse_no(int course_no) {
		Course_no = course_no;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(int restaurant) {
		this.restaurant = restaurant;
	}
	public int getHotel() {
		return hotel;
	}
	public void setHotel(int hotel) {
		this.hotel = hotel;
	}
	public int getShop() {
		return shop;
	}
	public void setShop(int shop) {
		this.shop = shop;
	}
	public int getCulture() {
		return culture;
	}
	public void setCulture(int culture) {
		this.culture = culture;
	}
	public int getViewpoint() {
		return viewpoint;
	}
	public void setViewpoint(int viewpoint) {
		this.viewpoint = viewpoint;
	}
	
	


}
