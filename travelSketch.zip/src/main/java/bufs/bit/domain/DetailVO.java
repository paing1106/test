package bufs.bit.domain;

public class DetailVO {
	private String dname;
	private String dcontent;
	private int item_no;

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDcontent() {
		return dcontent;
	}

	public void setDcontent(String dcontent) {
		this.dcontent = dcontent;
	}

	public int getItem_no() {
		return item_no;
	}

	public void setItem_no(int item_no) {
		this.item_no = item_no;
	}

	public DetailVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DetailVO(String dname, String dcontent, int item_no) {
		super();
		this.dname = dname;
		this.dcontent = dcontent;
		this.item_no = item_no;
	}

}
