package bufs.bit.domain;

public class NoteReplyVO {
	private int nreplyno;
	private int noteno;
	private String userid;
	private String contents;
	private String day;
	private int pageno;
	
	public int getPageno() {
		return pageno;
	}
	public void setPageno(int pageno) {
		this.pageno = pageno;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public int getNreplyno() {
		return nreplyno;
	}
	public void setNreplyno(int nreplyno) {
		this.nreplyno = nreplyno;
	}
	public int getNoteno() {
		return noteno;
	}
	public void setNoteno(int noteno) {
		this.noteno = noteno;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	
}
