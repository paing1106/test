package bufs.bit.domain;

public class visibleVO {
	private String vid;
	private String vname;
	private String category;
	private int cid;
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		
		this.cid = cid;
	      switch (cid) {
	      case 1:
	         this.category = "RESTAURANT";
	         break;
	      case 2:
	         this.category = "HOTEL";
	         break;
	      case 3:
	         this.category = "VIEWPOINT";
	         break;
	      case 4:
	         this.category = "CULTURE";
	         break;
	      case 5:
	         this.category = "SHOP";
	         break;
	      }
	}
	public String getVid() {
		return vid;
	}
	public void setVid(String vid) {
		this.vid = vid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	
	
}

