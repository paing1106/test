package bufs.bit.domain;

public class mapSrcVO {
	private String name;
	private double x;
	private double y;
	private String content;
	private String category;
	private String img;
	private int cid;
	private String tel;	
	private String addr;
	
	public mapSrcVO(String name, double x, double y, int cid) {
		super();
		this.name = name;
		this.x = x;
		this.y = y;
		this.cid = cid;
	}
	public mapSrcVO(String name, double x, double y) {
		super();
		this.name = name;
		this.x = x;
		this.y = y;
	}
	public mapSrcVO(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	public mapSrcVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	

	
}
