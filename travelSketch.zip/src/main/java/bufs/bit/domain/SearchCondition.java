package bufs.bit.domain;

public class SearchCondition {
	private String type;
	private String keyword;
	private int c_no;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getC_no() {
		return c_no;
	}

	public void setC_no(int c_no) {
		this.c_no = c_no;
	}

	public SearchCondition(String type, String keyword, int c_no) {
		super();
		this.type = type;
		this.keyword = keyword;
		this.c_no = c_no;
	}

	public SearchCondition() {
		super();
		// TODO Auto-generated constructor stub
	}

}
