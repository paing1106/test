package bufs.bit.domain;

public class MainCategoryVO {
	private String m_cno;
	private String m_cname;

	public MainCategoryVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MainCategoryVO(String m_cno, String m_cname) {
		super();
		this.m_cno = m_cno;
		this.m_cname = m_cname;
	}

}
