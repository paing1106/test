package bufs.bit.domain;

import java.util.Date;

public class T_NoteVO {
	private int note_no;
	private String title;
	private String userid;
	private String content;
	private int course_no;
	private Date regdate;
	
	private String[] files;
	

	public Date getRegdate() {
		return regdate;
	}

	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public String[] getFiles() {
		return files;
	}

	public void setFiles(String[] files) {
		this.files = files;
	}

	public T_NoteVO(int note_no, String title, String userid, String content, int course_no) {
		super();
		this.note_no = note_no;
		this.title = title;
		this.userid = userid;
		this.content = content;
		this.course_no = course_no;
	}

	public T_NoteVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getNote_no() {
		return note_no;
	}

	public void setNote_no(int note_no) {
		this.note_no = note_no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getCourse_no() {
		return course_no;
	}

	public void setCourse_no(int course_no) {
		this.course_no = course_no;
	}

}
