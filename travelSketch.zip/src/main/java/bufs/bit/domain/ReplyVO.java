package bufs.bit.domain;


public class ReplyVO {
	private int review_no;
	private String userid;	
	private String content;
	private int course_no;
	private int culture;
	private int hotel;
	private int shop;
	private int viewpoint;
	private int restaurant;
	private int cid;
	private String category;
	private int itemno;
	private String day;
	private int pageno; 
	
	
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getReview_no() {
		return review_no;
	}
	public void setReview_no(int review_no) {
		this.review_no = review_no;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getCourse_no() {
		return course_no;
	}
	public void setCourse_no(int course_no) {
		this.course_no = course_no;
	}
	public int getCulture() {
		return culture;
	}
	public void setCulture(int culture) {
		this.culture = culture;
	}
	public int getHotel() {
		return hotel;
	}
	public void setHotel(int hotel) {
		this.hotel = hotel;
	}
	public int getShop() {
		return shop;
	}
	public void setShop(int shop) {
		this.shop = shop;
	}
	public int getViewpoint() {
		return viewpoint;
	}
	public void setViewpoint(int viewpoint) {
		this.viewpoint = viewpoint;
	}
	public int getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(int restaurant) {
		this.restaurant = restaurant;
	}
	public ReplyVO(int review_no, String userid, String content, int course_no, int culture, int hotel, int shop,
			int viewpoint, int restaurant) {
		super();
		this.review_no = review_no;
		this.userid = userid;
		this.content = content;
		this.course_no = course_no;
		this.culture = culture;
		this.hotel = hotel;
		this.shop = shop;
		this.viewpoint = viewpoint;
		this.restaurant = restaurant;
	}
	public ReplyVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getItemno() {
		return itemno;
	}
	public void setItemno(int itemno) {
		this.itemno = itemno;
	}
	public int getPageno() {
		return pageno;
	}
	public void setPageno(int pageno) {
		this.pageno = pageno;
	}

	
}
