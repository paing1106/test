package bufs.bit.domain;

public class CourseVO {
	private int course_no;
	private String userid;
	private int T_info_no;
	private String coursename;
	public int getCourse_no() {
		return course_no;
	}
	public void setCourse_no(int course_no) {
		this.course_no = course_no;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getT_info_no() {
		return T_info_no;
	}
	public void setT_info_no(int t_info_no) {
		T_info_no = t_info_no;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	
}
