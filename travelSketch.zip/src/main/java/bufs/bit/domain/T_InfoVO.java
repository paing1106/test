package bufs.bit.domain;

public class T_InfoVO {
	private int t_info_no;
	private String userid;
	private int age;
	private String couple;
	private String transport;
	private String season;
	private String day;
	private int cid;

	public int getT_info_no() {
		return t_info_no;
	}

	public void setT_info_no(int t_info_no) {
		this.t_info_no = t_info_no;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getCouple() {
		return couple;
	}

	public void setCouple(String couple) {
		this.couple = couple;
	}

	public String getTransport() {
		return transport;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public T_InfoVO(int t_info_no, String userid, int age, String couple, String transport, String season, String day, int cid) {
		super();
		this.t_info_no = t_info_no;
		this.userid = userid;
		this.age = age;
		this.couple = couple;
		this.transport = transport;
		this.season = season;
		this.day = day;
		this.cid = cid;
	}

	public T_InfoVO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
