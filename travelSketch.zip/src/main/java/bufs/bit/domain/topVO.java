package bufs.bit.domain;

public class topVO {
	private int cid;
	private String cname;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
		switch (cid) {
		case 1:
			this.cname = "RESTAURANT";
			break;
		case 2:
			this.cname = "HOTEL";
			break;
		case 3:
			this.cname = "VIEWPOINT";
			break;
		case 4:
			this.cname = "CULTURE";
			break;
		case 5:
			this.cname = "SHOP";
			break;
		}
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	

}
