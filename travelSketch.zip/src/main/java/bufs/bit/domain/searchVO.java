package bufs.bit.domain;

public class searchVO {
	private int pageno;
	private int visible;
	private int cid;
	private String category; // table
	private String type; // colum
	private String key;

	public int getPageno() {
		return pageno;
	}

	public void setPageno(int pageno) {
		this.pageno = pageno;
	}

	public int getVisible() {
		return visible;
	}

	public void setVisible(int visible) {
		this.visible = visible;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
		switch (cid) {
		case 1:
			setCategory("restaurant");
			break;
		case 2:
			setCategory("hotel");
			break;
		case 3:
			setCategory("viewpoint");
			break;
		case 4:
			setCategory("culture");
			break;
		case 5:
			setCategory("shop");
			break;
		}
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getName() {
		return type;
	}

	public void setName(int cid) {
		switch (cid) {
		case 1:
			this.type = "rname";
			break;
		case 2:
			this.type = "hname";
			break;
		case 3:
			this.type = "vname";
			break;
		case 4:
			this.type = "cname";
			break;
		case 5:
			this.type = "sname";
			break;
		case 6:
			this.type = "addr||addr2";
			break;
		}		
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}


	
}
