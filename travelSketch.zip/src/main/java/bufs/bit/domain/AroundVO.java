package bufs.bit.domain;

public class AroundVO {
	private double latitude;
	private double longtitude;	
	private String category;
	private int type;
	private double coordi;
	
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongtitude() {
		return longtitude;
	}
	public void setLongtitude(double longtitude) {
		this.longtitude = longtitude;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
		switch(type){
		case 0: this.coordi = 0.010; break;  //디테일
		case 1: this.coordi = 0.005; break;	 //도보
		case 2: this.coordi = 0.008; break;	 //자전거5
		case 3: this.coordi = 0.010; break;  //버스10
		case 4: this.coordi = 0.015; break;  //자가용20
			
		}
	}
	public double getCoordi() {
		return coordi;
	}
	public void setCoordi(double coordi) {
		this.coordi = coordi;
	}
	

}
