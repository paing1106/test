package bufs.bit.domain;

public class tempMapVO {
	private String x;
	private String y;
	private String name;
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public tempMapVO(String x, String y, String name) {
		super();
		this.x = x;
		this.y = y;
		this.name = name;
	}
	
}
