package bufs.bit.domain;

public class SemiItemVO {
	private int no;
	private int cid;
	private String addr;
	private String homepage;
	private double latitude;
	private double longtitude;
	private String time;
	private String parking;
	private String tel;
	private String credit;
	private String t_and_m;
	private String m_and_p;
	private String name;
	private String contents;
	private String holiday;
	private String mainimg;
	private String mainimgdetail;
	private String img1;
	private String img1title;
	private String img2;
	private String img2title;
	private String img3;
	private String listimg;
	private String listimgdetail;
	private String ldgimg;
	private String ldgImgdetail;
	private String courseimg;
	private String courseimgdetail;
	private String trafin;
	private String trafout;
	private String sellItems;
	private String useGiftCerti;
	private String disest;
	private String expe;
	private String useest;
	private String mvTrrsrtNm;
	private String mvActors;
	private String around;
	private String etc;
	private String startDate;
	private String endDate;
	private String reservation;
	private String institution;
	private String touCourse;
	private String touProduct;
	private String touFood;
	private String touMapinfo;
	private String category;
	private int visible;
	private int pageno;
	private int viewcount;
	private String opt;
	
	
	
	public String getOpt() {
		return opt;
	}
	public void setOpt(String opt) {
		this.opt = opt;
	}
	public int getViewcount() {
		return viewcount;
	}

	public void setViewcount(int viewcount) {
		this.viewcount = viewcount;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(double longtitude) {
		this.longtitude = longtitude;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getParking() {
		return parking;
	}

	public void setParking(String parking) {
		this.parking = parking;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getCredit() {
		return credit;
	}

	public void setCredit(String credit) {
		this.credit = credit;
	}

	public String getT_and_m() {
		return t_and_m;
	}

	public void setT_and_m(String t_and_m) {
		this.t_and_m = t_and_m;
	}

	public String getM_and_p() {
		return m_and_p;
	}

	public void setM_and_p(String m_and_p) {
		this.m_and_p = m_and_p;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getHoliday() {
		return holiday;
	}

	public void setHoliday(String holiday) {
		this.holiday = holiday;
	}

	public String getMainimg() {
		return mainimg;
	}

	public void setMainimg(String mainimg) {
		this.mainimg = mainimg;
	}

	public String getMainimgdetail() {
		return mainimgdetail;
	}

	public void setMainimgdetail(String mainimgdetail) {
		this.mainimgdetail = mainimgdetail;
	}

	public String getImg1() {
		return img1;
	}

	public void setImg1(String img1) {
		this.img1 = img1;
	}

	public String getImg1title() {
		return img1title;
	}

	public void setImg1title(String img1title) {
		this.img1title = img1title;
	}

	public String getImg2() {
		return img2;
	}

	public void setImg2(String img2) {
		this.img2 = img2;
	}

	public String getImg2title() {
		return img2title;
	}

	public void setImg2title(String img2title) {
		this.img2title = img2title;
	}

	public String getImg3() {
		return img3;
	}

	public void setImg3(String img3) {
		this.img3 = img3;
	}

	public String getListimg() {
		return listimg;
	}

	public void setListimg(String listimg) {
		this.listimg = listimg;
	}

	public String getListimgdetail() {
		return listimgdetail;
	}

	public void setListimgdetail(String listimgdetail) {
		this.listimgdetail = listimgdetail;
	}

	public String getLdgimg() {
		return ldgimg;
	}

	public void setLdgimg(String ldgimg) {
		this.ldgimg = ldgimg;
	}

	public String getLdgImgdetail() {
		return ldgImgdetail;
	}

	public void setLdgImgdetail(String ldgImgdetail) {
		this.ldgImgdetail = ldgImgdetail;
	}

	public String getCourseimg() {
		return courseimg;
	}

	public void setCourseimg(String courseimg) {
		this.courseimg = courseimg;
	}

	public String getCourseimgdetail() {
		return courseimgdetail;
	}

	public void setCourseimgdetail(String courseimgdetail) {
		this.courseimgdetail = courseimgdetail;
	}

	public String getTrafin() {
		return trafin;
	}

	public void setTrafin(String trafin) {
		this.trafin = trafin;
	}

	public String getTrafout() {
		return trafout;
	}

	public void setTrafout(String trafout) {
		this.trafout = trafout;
	}

	public String getSellItems() {
		return sellItems;
	}

	public void setSellItems(String sellItems) {
		this.sellItems = sellItems;
	}

	public String getUseGiftCerti() {
		return useGiftCerti;
	}

	public void setUseGiftCerti(String useGiftCerti) {
		this.useGiftCerti = useGiftCerti;
	}

	public String getDisest() {
		return disest;
	}

	public void setDisest(String disest) {
		this.disest = disest;
	}

	public String getExpe() {
		return expe;
	}

	public void setExpe(String expe) {
		this.expe = expe;
	}

	public String getUseest() {
		return useest;
	}

	public void setUseest(String useest) {
		this.useest = useest;
	}

	public String getMvTrrsrtNm() {
		return mvTrrsrtNm;
	}

	public void setMvTrrsrtNm(String mvTrrsrtNm) {
		this.mvTrrsrtNm = mvTrrsrtNm;
	}

	public String getMvActors() {
		return mvActors;
	}

	public void setMvActors(String mvActors) {
		this.mvActors = mvActors;
	}

	public String getAround() {
		return around;
	}

	public void setAround(String around) {
		this.around = around;
	}

	public String getEtc() {
		return etc;
	}

	public void setEtc(String etc) {
		this.etc = etc;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getReservation() {
		return reservation;
	}

	public void setReservation(String reservation) {
		this.reservation = reservation;
	}

	public String getInstitution() {
		return institution;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public String getTouCourse() {
		return touCourse;
	}

	public void setTouCourse(String touCourse) {
		this.touCourse = touCourse;
	}

	public String getTouProduct() {
		return touProduct;
	}

	public void setTouProduct(String touProduct) {
		this.touProduct = touProduct;
	}

	public String getTouFood() {
		return touFood;
	}

	public void setTouFood(String touFood) {
		this.touFood = touFood;
	}

	public String getTouMapinfo() {
		return touMapinfo;
	}

	public void setTouMapinfo(String touMapinfo) {
		this.touMapinfo = touMapinfo;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getVisible() {
		return visible;
	}

	public void setVisible(int visible) {
		this.visible = visible;
	}

	public int getPageno() {
		return pageno;
	}

	public void setPageno(int pageno) {
		this.pageno = pageno;
	}

	public SemiItemVO(int no, int cid, String addr, String homepage, double latitude, double longtitude, String time,
			String parking, String tel, String credit, String t_and_m, String m_and_p, String name, String contents,
			String holiday, String mainimg, String mainimgdetail, String img1, String img1title, String img2,
			String img2title, String img3, String listimg, String listimgdetail, String ldgimg, String ldgImgdetail,
			String courseimg, String courseimgdetail, String trafin, String trafout, String sellItems,
			String useGiftCerti, String disest, String expe, String useest, String mvTrrsrtNm, String mvActors,
			String around, String etc, String startDate, String endDate, String reservation, String institution,
			String touCourse, String touProduct, String touFood, String touMapinfo, String category, int visible) {
		super();
		this.no = no;
		this.cid = cid;
		this.addr = addr;
		this.homepage = homepage;
		this.latitude = latitude;
		this.longtitude = longtitude;
		this.time = time;
		this.parking = parking;
		this.tel = tel;
		this.credit = credit;
		this.t_and_m = t_and_m;
		this.m_and_p = m_and_p;
		this.name = name;
		this.contents = contents;
		this.holiday = holiday;
		this.mainimg = mainimg;
		this.mainimgdetail = mainimgdetail;
		this.img1 = img1;
		this.img1title = img1title;
		this.img2 = img2;
		this.img2title = img2title;
		this.img3 = img3;
		this.listimg = listimg;
		this.listimgdetail = listimgdetail;
		this.ldgimg = ldgimg;
		this.ldgImgdetail = ldgImgdetail;
		this.courseimg = courseimg;
		this.courseimgdetail = courseimgdetail;
		this.trafin = trafin;
		this.trafout = trafout;
		this.sellItems = sellItems;
		this.useGiftCerti = useGiftCerti;
		this.disest = disest;
		this.expe = expe;
		this.useest = useest;
		this.mvTrrsrtNm = mvTrrsrtNm;
		this.mvActors = mvActors;
		this.around = around;
		this.etc = etc;
		this.startDate = startDate;
		this.endDate = endDate;
		this.reservation = reservation;
		this.institution = institution;
		this.touCourse = touCourse;
		this.touProduct = touProduct;
		this.touFood = touFood;
		this.touMapinfo = touMapinfo;
		this.category = category;
		this.visible = visible;

	}

	public SemiItemVO() {
		super();
		// TODO Auto-generated constructor stub
	}

}