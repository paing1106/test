package bufs.bit.controller;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.CategoryVO;
import bufs.bit.domain.FavoriteVO;
import bufs.bit.service_Interface.I_CategoryService;
import bufs.bit.service_Interface.I_FavoriteService;

@Controller
@RequestMapping(value = "/favorite/*")
public class FavoriteController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);
	
	@Inject
	private I_FavoriteService favoriteService;
	
	@Inject
	private I_CategoryService categoryService;
	
	@RequestMapping( value="/insertFavorite", method = RequestMethod.GET)
	public String insertFavoriteGET(FavoriteVO vo, Model model, HttpSession session){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		model.addAttribute("category", categoryService.listAll());
		log.info("[..... favorite controller insertFavoriteGET  .....]");
		return "favorite/addfavorite";
	}
	
	@RequestMapping(value="/insertFavorite", method = RequestMethod.POST)
	public String insertFavoritePost(FavoriteVO vo, Model model, HttpSession session){
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		favoriteService.create(vo);
		log.info("[..... favorite controller insertFavoritePost  .....]");
		return "redirect:/favorite/listAllFavorite";
	}
	
	@RequestMapping(value="/listAllFavorite", method = RequestMethod.GET)
	public String listAllFavoriteGET(Model model, HttpSession session, @RequestParam("id") String id){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		FavoriteVO vo= new FavoriteVO();
		vo.setUserid(id);
		ArrayList<String> cname = new ArrayList<String>();
		ArrayList<FavoriteVO> list = (ArrayList<FavoriteVO>)favoriteService.listAll(vo);
		for (int i = 0; i < list.size(); i++) {
			int cid = list.get(i).getCid();
			cname.add(categoryService.cname(cid));
		}
		model.addAttribute("cname", cname);
		model.addAttribute("id", vo.getUserid());
		log.info("[..... favorite controller listAllFavoriteGET  .....]");
		return "favorite/readfavorite";
		
	}
	
	@RequestMapping(value="/updateFavorite", method = RequestMethod.GET)
	public String updateFavoriteGET(Model model, HttpSession session,@RequestParam("cname") String key){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("category", categoryService.listAll());
		model.addAttribute("userid", userid);
		model.addAttribute("key", key);		
		log.info("[..... favorite controller updateFavoriteGET  .....]");
		return "favorite/updatefavorite";
	}
	
	@RequestMapping(value="/updateFavorite", method = RequestMethod.POST)
	public String updateFavoritePOST(FavoriteVO vo,Model model, HttpSession session){
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		favoriteService.update(vo);
		log.info("[..... favorite controller updateFavoritePOST  .....]");
		return "";
	}
	
	@RequestMapping(value="/deleteFavorite", method = RequestMethod.GET)
	public String deleteFavoriteGET(@RequestParam("cname") String cname, Model model, HttpSession session){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		ArrayList list = (ArrayList)categoryService.cid(cname);
		int cid = (int)list.get(0);
		FavoriteVO vo= new FavoriteVO();
		vo.setCid(cid);
		vo.setUserid(userid);
		favoriteService.delete(vo);
		log.info("[..... favorite controller deleteFavoriteGET  .....]");
		return "redirect:/favorite/listAllFavorite?id="+userid;
	}
	
	
	
}
