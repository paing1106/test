package bufs.bit.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sound.midi.SoundbankResource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.dao_Interface.I_TravelInfo;
import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseListVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.ItemVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.domain.T_InfoVO;
import bufs.bit.domain.mapSrcVO;
import bufs.bit.service.ItemService;
import bufs.bit.service_Interface.I_CategoryService;
import bufs.bit.service_Interface.I_CourseService;
import bufs.bit.service_Interface.I_ItemService;

@Controller
@RequestMapping(value = "/course/*")
public class CourseController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	private I_CourseService courseService;

	@Inject
	private I_ItemService itemService;

	@Inject
	private I_CategoryService categoryService;

	@Inject
	private I_TravelInfo infoService;

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public String addCourseGET(Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		log.info("[..... course controller addCourseGET  .....]");
		return "course/create";
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public String addCoursePOST(CourseVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		courseService.add1(vo);
		log.info("[..... course controller addCoursePOST  .....]");
		return "redirect:/item/list?page=1&cid=1";
	}

	@RequestMapping(value = "/additem", method = RequestMethod.GET)
	public String addItem(Model model, HttpSession session, @RequestParam("itemno") int itemno,
			@RequestParam("courseno") int courseno, @RequestParam("cid") int cid) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		session.setAttribute("userid", id);
		CourseListVO vo = new CourseListVO();
		vo.setCourse_no(courseno);
		switch (cid) {
		case 1: // rest
			vo.setRestaurant(itemno);
			courseService.addlistR(vo);
			break;
		case 2: // hotel
			vo.setHotel(itemno);
			courseService.addlistH(vo);
			break;
		case 3: // view
			vo.setViewpoint(itemno);
			courseService.addlistV(vo);
			break;
		case 4: // cul
			vo.setCulture(itemno);
			courseService.addlistC(vo);
			break;
		case 5: // shop
			vo.setShop(itemno);
			courseService.addlistS(vo);
			break;
		}
		log.info("[..... course controller addItem  .....]");
		return "redirect:/board/detail?cid=" + cid + "&no=" + itemno + "&rpage=1";

	}

	/*
	 * @RequestMapping(value = "/additem", method = RequestMethod.GET) public
	 * String addItem(Model model, HttpSession session, @RequestParam("cid") int
	 * cid, @RequestParam("no") int no){ CourseVO coursevo = new CourseVO();
	 * String id = (String) session.getAttribute("userid");
	 * model.addAttribute("userid", id); coursevo.setUserid(id); int courseno =
	 * courseService.add2(coursevo); CourseListVO vo = new CourseListVO();
	 * vo.setCourse_no(courseno); switch (cid) { case 1: //rest
	 * vo.setRestaurant(no); courseService.addlistR(vo); break; case 2: //hotel
	 * vo.setHotel(no); courseService.addlistH(vo); break; case 3: //view
	 * vo.setViewpoint(no); courseService.addlistV(vo); break; case 4: //cul
	 * vo.setCulture(no); courseService.addlistC(vo); break; case 5: //shop
	 * vo.setShop(no); courseService.addlistS(vo); break; } log.info(
	 * "[..... course controller addItem  .....]"); return
	 * "redirect:/board/detail?cid="+cid+"&no="+no+"&rpage=1"; }
	 */

	@RequestMapping(value = "/cancle", method = RequestMethod.GET)
	public String cancle(Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		CourseVO vo = new CourseVO();
		vo.setUserid(id);
		int courseno = courseService.add2(vo);
		courseService.delete(courseno);
		session.removeAttribute("courseno");
		log.info("[..... course controller cancle  .....]");
		return "redirect:/course/create";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(Model model, @RequestParam("no") int courseno, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		courseService.delete(courseno);
		log.info("[..... course controller delete  .....]");
		return "";
	}

	@RequestMapping(value = "/idlist", method = RequestMethod.GET)
	public String idList(Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("idlist", courseService.idlist(id));
		log.info("[.....   course controller idList  .....]");
		return "course/idlist";
	}

	String name;

	@RequestMapping(value = "/courselist", method = RequestMethod.GET)
	public String courselist(Model model, HttpSession session, @RequestParam("no") int courseno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();

		ArrayList<CourseListJoinVO> list = new ArrayList<CourseListJoinVO>();
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListR(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		list.addAll(courseService.courseListC(courseno));

		for (int i = 0; i < list.size(); i++) {
			try {
				if (list.get(i).getHname().length() > 1)
					name = list.get(i).getHname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getRname().length() > 1)
					name = list.get(i).getRname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getCname().length() > 1)
					name = list.get(i).getCname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getSname().length() > 1)
					name = list.get(i).getSname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getVname().length() > 1)
					name = list.get(i).getVname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}

			int cid = list.get(i).getCid() - 1;
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrcVO vo = new mapSrcVO(name, x, y, cid);
			mapSrc.add(vo);
		}

		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... course controller courselist  .....]");
		return "course/detail";
	}

	@RequestMapping(value = "/coordinateTemp", method = RequestMethod.GET)
	public String courseRead(Model model, @RequestParam("no") int courseno, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();
		ArrayList<CourseListJoinVO> list = (ArrayList<CourseListJoinVO>) courseService.courseListR(courseno);
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		list.addAll(courseService.courseListC(courseno));

		for (int i = 0; i < list.size(); i++) {
			try {
				if (list.get(i).getRname().length() > 1)
					name = list.get(i).getRname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getCname().length() > 1)
					name = list.get(i).getCname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getSname().length() > 1)
					name = list.get(i).getSname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getVname().length() > 1)
					name = list.get(i).getVname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getHname().length() > 1)
					name = list.get(i).getHname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			int cid = list.get(i).getCid();
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrc.add(new mapSrcVO(name, x, y, cid));
		}
		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... course controller courseRead  .....]");
		return "course/coordinateTemp";
	}

	@RequestMapping(value = "/courseAjax", method = RequestMethod.GET)
	public String courseAjax(Model model, HttpSession session, @RequestParam("no") int courseno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();

		ArrayList<CourseListJoinVO> list = new ArrayList<CourseListJoinVO>();
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListR(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		list.addAll(courseService.courseListC(courseno));

		for (int i = 0; i < list.size(); i++) {
			try {
				if (list.get(i).getHname().length() > 1)
					name = list.get(i).getHname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getRname().length() > 1)
					name = list.get(i).getRname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getCname().length() > 1)
					name = list.get(i).getCname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getSname().length() > 1)
					name = list.get(i).getSname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (list.get(i).getVname().length() > 1)
					name = list.get(i).getVname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}

			int cid = list.get(i).getCid() - 1;
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrcVO vo = new mapSrcVO(name, x, y, cid);
			mapSrc.add(vo);
		}
		model.addAttribute("courseno", courseno);
		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... course controller courseAjax  .....]");
		return "course/courseAjaxTemp";
	}

	@RequestMapping(value = "/goMarker", method = RequestMethod.GET)
	public String goMarker(Model model, HttpSession session, @RequestParam("no") int courseno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();

		ArrayList<CourseListJoinVO> list = new ArrayList<CourseListJoinVO>();
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListR(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		list.addAll(courseService.courseListC(courseno));

		for (int i = 0; i < list.size(); i++) {
			int cid = list.get(i).getCid();
			switch (cid) {
			case 1:
				name = list.get(i).getRname();
				break;
			case 2:
				name = list.get(i).getHname();
				break;
			case 3:
				name = list.get(i).getVname();
				break;
			case 4:
				name = list.get(i).getCname();
				break;
			case 5:
				name = list.get(i).getSname();
				break;
			}

			/*
			 * try { if (list.get(i).getHname().length() > 1) name =
			 * list.get(i).getHname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); } try { if (list.get(i).getRname().length()
			 * > 1) name = list.get(i).getRname(); } catch (NullPointerException
			 * e) { e.printStackTrace(); } try { if
			 * (list.get(i).getCname().length() > 1) name =
			 * list.get(i).getCname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); } try { if (list.get(i).getSname().length()
			 * > 1) name = list.get(i).getSname(); } catch (NullPointerException
			 * e) { e.printStackTrace(); } try { if
			 * (list.get(i).getVname().length() > 1) name =
			 * list.get(i).getVname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); }
			 */
			// int cid = list.get(i).getCid() - 1;
			cid = cid - 1;
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrcVO vo = new mapSrcVO(name, x, y, cid);
			vo.setContent(list.get(i).getContents());
			vo.setCategory(categoryService.cname(list.get(i).getCid()));
			String addr = list.get(i).getAddr();
			String addr2 = list.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			vo.setAddr(addr);
			vo.setTel(list.get(i).getTel());
			vo.setImg(list.get(i).getMainimg());
			mapSrc.add(vo);
		}

		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... course controller courseAjax Two  .....]");
		return "map/goMarker";
	}

	/*
	 * @RequestMapping(value = "/delCourse", method = RequestMethod.GET) public
	 * String delCourse(Model model, HttpSession session, @RequestParam("name")
	 * String name,
	 * 
	 * @RequestParam("courseno") int courseno, HttpServletRequest request) {
	 * String id = (String) session.getAttribute("userid");
	 * model.addAttribute("userid", id);
	 * 
	 * ArrayList<ItemVO> temp = new ArrayList<>();
	 * temp.addAll(itemService.rname(name));
	 * temp.addAll(itemService.hname(name));
	 * temp.addAll(itemService.vname(name));
	 * temp.addAll(itemService.cname(name));
	 * temp.addAll(itemService.sname(name));
	 * 
	 * CourseListVO courseListVO = new CourseListVO();
	 * courseListVO.setCourse_no(courseno); int cid = temp.get(0).getCid(); int
	 * itemno; switch (cid) { case 1: itemno = temp.get(0).getRitem_no();
	 * courseListVO.setRestaurant(itemno); break; case 2: itemno =
	 * temp.get(0).getHitem_no(); courseListVO.setHotel(itemno); break; case 3:
	 * itemno = temp.get(0).getVitem_no(); courseListVO.setViewpoint(itemno);
	 * break; case 4: itemno = temp.get(0).getCitem_no();
	 * courseListVO.setCourse_no(itemno); break; case 5: itemno =
	 * temp.get(0).getSitem_no(); courseListVO.setShop(itemno); break; }
	 * 
	 * /*
	 * 
	 * @RequestMapping(value = "/delCourse", method = RequestMethod.GET) public
	 * String delCourse(Model model, HttpSession session,@RequestParam("name")
	 * String name,@RequestParam("courseno") int courseno,HttpServletRequest
	 * request){ String id = (String) session.getAttribute("userid");
	 * model.addAttribute("userid", id);
	 * 
	 * ArrayList<ItemVO> temp = new ArrayList<>();
	 * temp.addAll(itemService.rname(name));
	 * temp.addAll(itemService.hname(name));
	 * temp.addAll(itemService.vname(name));
	 * temp.addAll(itemService.cname(name));
	 * temp.addAll(itemService.sname(name));
	 * 
	 * CourseListVO courseListVO = new CourseListVO();
	 * courseListVO.setCourse_no(courseno); int cid = temp.get(0).getCid(); int
	 * itemno; switch(cid){ case 1 : itemno = temp.get(0).getRitem_no();
	 * courseListVO.setRestaurant(itemno); break; case 2 : itemno =
	 * temp.get(0).getHitem_no(); courseListVO.setHotel(itemno); break; case 3 :
	 * itemno = temp.get(0).getVitem_no(); courseListVO.setViewpoint(itemno);
	 * break; case 4 : itemno = temp.get(0).getCitem_no();
	 * courseListVO.setCourse_no(itemno); break; case 5 : itemno =
	 * temp.get(0).getSitem_no(); courseListVO.setShop(itemno); break; }
	 * 
	 * courseService.deletOne(courseListVO); String referer =
	 * request.getHeader("Referer"); //return "redirect:"+ referer; return null;
	 * }
	 */
	@RequestMapping(value = "/delCourse", method = RequestMethod.GET)
	public String delCourse(HttpServletRequest request, HttpSession Session, @RequestParam("courseno") int courseno) {
		courseService.delete(courseno);
		String referer = request.getHeader("Referer");
		return "redirect:" + referer;
	}

	@RequestMapping(value = "/delOne", method = RequestMethod.GET)
	public String delOne(Model model, HttpSession session, @RequestParam("itemno") int itemno,
			@RequestParam("courseno") int courseno, @RequestParam("cid") int cid, HttpServletRequest request) {

		CourseListVO CourseListVO = new CourseListVO();
		CourseListVO.setCourse_no(courseno);
		switch (cid) {
		case 1:
			CourseListVO.setRestaurant(itemno);
			break;
		case 2:
			CourseListVO.setHotel(itemno);
			break;
		case 3:
			CourseListVO.setViewpoint(itemno);
			break;
		case 4:
			CourseListVO.setCulture(courseno);
			break;
		case 5:
			CourseListVO.setShop(itemno);
			break;
		}

		courseService.deletOne(CourseListVO, cid);
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		model.addAttribute("course", courseService.listAll(courseno));
		model.addAttribute("courseno", courseno);
		log.info("[..... course controller delOne .....]");
		return "course/randomlist";
	}

	@RequestMapping(value = "/idlistdelOne", method = RequestMethod.GET)
	public String idlistdelOne(Model model, HttpSession session, @RequestParam("itemno") int itemno,
			@RequestParam("courseno") int courseno, @RequestParam("cid") int cid, HttpServletRequest request) {

		CourseListVO CourseListVO = new CourseListVO();
		CourseListVO.setCourse_no(courseno);
		switch (cid) {
		case 1:
			CourseListVO.setRestaurant(itemno);
			break;
		case 2:
			CourseListVO.setHotel(itemno);
			break;
		case 3:
			CourseListVO.setViewpoint(itemno);
			break;
		case 4:
			CourseListVO.setCulture(courseno);
			break;
		case 5:
			CourseListVO.setShop(itemno);
			break;
		}

		courseService.deletOne(CourseListVO, cid);
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		model.addAttribute("course", courseService.listAll(courseno));
		model.addAttribute("courseno", courseno);
		log.info("[..... course controller idlistdelOne .....]");

		// String referer = request.getHeader("Referer");
		// return "redirect:" + referer;
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("idlist", courseService.idlist(id));
		return "course/idlist";
	}

	int no;

	@RequestMapping(value = "/courseAjax2", method = RequestMethod.GET)
	public String courseAjax2(Model model, HttpSession session, @RequestParam("no") int courseno) {
		String id = (String) session.getAttribute("userid");
		session.setAttribute("userid", id);
		model.addAttribute("userid", id);

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();

		ArrayList<CourseListJoinVO> list = new ArrayList<CourseListJoinVO>();
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListR(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		list.addAll(courseService.courseListC(courseno));

		ArrayList<SemiItemVO> item = new ArrayList<SemiItemVO>();

		for (int i = 0; i < list.size(); i++) {

			int cid = list.get(i).getCid();
			switch (cid) {
			case 1:
				no = list.get(i).getRitem_no();
				name = list.get(i).getRname();
				break;
			case 2:
				no = list.get(i).getHitem_no();
				name = list.get(i).getHname();
				break;
			case 3:
				no = list.get(i).getVitem_no();
				name = list.get(i).getVname();
				break;
			case 4:
				no = list.get(i).getCitem_no();
				name = list.get(i).getCname();
				break;
			case 5:
				no = list.get(i).getSitem_no();
				name = list.get(i).getSname();
				break;
			}
			String mainimg = list.get(i).getMainimg();
			String contents = list.get(i).getContents();
			String addr = list.get(i).getAddr();
			String addr2 = list.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			SemiItemVO vo = new SemiItemVO();
			vo.setNo(no);
			vo.setName(name);
			vo.setCid(cid);
			vo.setMainimg(mainimg);
			vo.setContents(contents);
			vo.setAddr(addr);

			item.add(vo);
		}

		model.addAttribute("mycourse", item);

		for (int i = 0; i < list.size(); i++) {
			int cid = list.get(i).getCid();
			switch (cid) {
			case 1:
				name = list.get(i).getRname();
				break;
			case 2:
				name = list.get(i).getHname();
				break;
			case 3:
				name = list.get(i).getVname();
				break;
			case 4:
				name = list.get(i).getCname();
				break;
			case 5:
				name = list.get(i).getSname();
				break;
			}
			/*
			 * try { if (list.get(i).getHname().length() > 1) name =
			 * list.get(i).getHname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); } try { if (list.get(i).getRname().length()
			 * > 1) name = list.get(i).getRname(); } catch (NullPointerException
			 * e) { e.printStackTrace(); } try { if
			 * (list.get(i).getCname().length() > 1) name =
			 * list.get(i).getCname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); } try { if (list.get(i).getSname().length()
			 * > 1) name = list.get(i).getSname(); } catch (NullPointerException
			 * e) { e.printStackTrace(); } try { if
			 * (list.get(i).getVname().length() > 1) name =
			 * list.get(i).getVname(); } catch (NullPointerException e) {
			 * e.printStackTrace(); }
			 */
			cid = cid - 1;
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrcVO vo = new mapSrcVO(name, x, y, cid);
			vo.setContent(list.get(i).getContents());
			vo.setCategory(categoryService.cname(list.get(i).getCid()));
			String addr = list.get(i).getAddr();
			String addr2 = list.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			vo.setAddr(addr);
			vo.setTel(list.get(i).getTel());
			vo.setImg(list.get(i).getMainimg());
			mapSrc.add(vo);
		}
		model.addAttribute("courseno", courseno);
		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... course controller courseAjax2  .....]");
		return "course/courseAjaxTemp2";
	}

	@RequestMapping(value = "/random", method = RequestMethod.GET)
	public String random(Model model, HttpSession session, HttpServletRequest request) {
		// infoService.create((T_InfoVO)request.getAttribute("infoVO"));
		String id = (String) session.getAttribute("userid");
		session.setAttribute("userid", id);
		model.addAttribute("userid", id);
		CourseVO courseVO = new CourseVO();
		courseVO.setUserid(id);
		courseVO.setCoursename("랜덤 코스 추천");
		courseVO.setT_info_no(infoService.selectOne(id).getT_info_no());
		courseService.add1(courseVO);
		T_InfoVO infoVO = infoService.selectOne(id);
		ArrayList<ItemVO> temp = new ArrayList<ItemVO>();
		temp.addAll(itemService.topten(infoVO.getCid()));
		ArrayList<SemiItemVO> favorite = new ArrayList<SemiItemVO>();
		ArrayList<mapSrcVO> mapsrc = new ArrayList<mapSrcVO>();
		for (int i = 0; i < temp.size(); i++) {
			mapSrcVO mapVO = new mapSrcVO();
			SemiItemVO itemVO = new SemiItemVO();
			mapVO.setX(temp.get(i).getLatitude());
			mapVO.setY(temp.get(i).getLongtitude());
			int cid = temp.get(i).getCid();
			switch (cid) {
			case 1:
				itemVO.setName(temp.get(i).getRname());
				itemVO.setNo(temp.get(i).getRitem_no());
				mapVO.setName(temp.get(i).getRname());
				break; // R
			case 2:
				itemVO.setName(temp.get(i).getHname());
				itemVO.setNo(temp.get(i).getHitem_no());
				mapVO.setName(temp.get(i).getHname());
				break; // H
			case 3:
				itemVO.setName(temp.get(i).getVname());
				itemVO.setNo(temp.get(i).getVitem_no());
				mapVO.setName(temp.get(i).getVname());
				break; // V
			case 4:
				itemVO.setName(temp.get(i).getCname());
				itemVO.setNo(temp.get(i).getCitem_no());
				mapVO.setName(temp.get(i).getCname());
				break; // C
			case 5:
				itemVO.setName(temp.get(i).getSname());
				itemVO.setNo(temp.get(i).getSitem_no());
				mapVO.setName(temp.get(i).getSname());
				break; // S
			}
			itemVO.setCid(cid);
			mapVO.setCid(cid);
			mapVO.setCategory(temp.get(i).getCategory());
			mapVO.setCategory(temp.get(i).getCategory());
			String addr = temp.get(i).getAddr();
			if (temp.get(i).getAddr2() != null) {
				addr = addr + temp.get(i).getAddr2();
			}
			itemVO.setAddr(addr);
			mapVO.setAddr(addr);
			itemVO.setTel(temp.get(i).getTel());
			mapVO.setTel(temp.get(i).getTel());
			itemVO.setContents(temp.get(i).getContents());
			mapVO.setContent(temp.get(i).getContents());
			itemVO.setMainimg(temp.get(i).getMainimg());
			mapVO.setImg(temp.get(i).getMainimg());
			itemVO.setLatitude(temp.get(i).getLatitude());
			itemVO.setLongtitude(temp.get(i).getLongtitude());
			favorite.add(itemVO);
			mapsrc.add(mapVO);
		}

		model.addAttribute("courseInfo", courseService.lastCourse(id));
		model.addAttribute("cname", categoryService.cname(infoVO.getCid()));
		model.addAttribute("cid", infoVO.getCid());
		model.addAttribute("favorite", favorite);
		model.addAttribute("mapsrc", mapsrc);
		session.setAttribute("mapsrc", mapsrc);
		log.info("[..... course controller random .....]");
		return "course/random";
	}

	// RHVCS
	/*
	 * int type;
	 * 
	 * @RequestMapping(value = "/recommend", method = RequestMethod.GET) public
	 * String random(Model model, HttpSession session, @RequestParam("itemno")
	 * int itemno,@RequestParam("cid") int cid ,@RequestParam("category") int
	 * category) { String id = (String) session.getAttribute("userid");
	 * session.setAttribute("userid", id); model.addAttribute("userid", id);
	 * 
	 * SemiItemVO semiItemVO = new SemiItemVO(); semiItemVO.setCid(cid);
	 * semiItemVO.setNo(itemno); T_InfoVO infoVO = infoService.selectOne(id);
	 * String trans = infoVO.getTransport(); switch (trans) { case "walking":
	 * type = 1; break; case "bicycle": type = 2; break; case "bus": type = 3;
	 * break; case "car": type = 4; break; } ArrayList<SemiItemVO> item = new
	 * ArrayList<>(); ArrayList<ItemVO> temp = new ArrayList<ItemVO>();
	 * temp.addAll(itemService.recommend(semiItemVO, type, category)); for (int
	 * i = 0; i < temp.size(); i++) { SemiItemVO itemVO = new SemiItemVO(); int
	 * key = temp.get(i).getCid(); switch(key){ case 1: //r
	 * itemVO.setNo(temp.get(i).getRitem_no());
	 * itemVO.setName(temp.get(i).getRname()); break; case 2: //h
	 * itemVO.setNo(temp.get(i).getHitem_no());
	 * itemVO.setName(temp.get(i).getHname()); break; case 3: //v
	 * itemVO.setNo(temp.get(i).getVitem_no());
	 * itemVO.setName(temp.get(i).getVname()); break; case 4: //c
	 * itemVO.setNo(temp.get(i).getCitem_no());
	 * itemVO.setName(temp.get(i).getCname()); break; case 5: //s
	 * itemVO.setNo(temp.get(i).getSitem_no());
	 * itemVO.setName(temp.get(i).getSname()); break; }
	 * 
	 * itemVO.setCategory(categoryService.cname(temp.get(i).getCid()));
	 * itemVO.setCid(key); String addr = temp.get(i).getAddr();
	 * if(temp.get(i).getAddr2() != null){ addr = addr + temp.get(i).getAddr2();
	 * } itemVO.setAddr(addr); itemVO.setTel(temp.get(i).getTel());
	 * itemVO.setContents(temp.get(i).getContents());
	 * itemVO.setMainimg(temp.get(i).getMainimg());
	 * 
	 * item.add(itemVO); }
	 * 
	 * log.info("[..... course controller recommend .....]");
	 * model.addAttribute("random", item) ; return "course/randomlist"; }
	 */

	@RequestMapping(value = "/addOne", method = RequestMethod.GET)
	public String addOne(Model model, HttpSession session, @RequestParam("courseno") int courseno,
			@RequestParam("itemno") int itemno, @RequestParam("cid") int cid) {
		String userid = session.getAttribute("userid").toString();
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		courseService.addOne(courseno, itemno, cid);
		model.addAttribute("course", courseService.listAll(courseno));
		model.addAttribute("courseno", courseno);
		log.info("[..... course controller addONE .....]");
		return "course/randomlist";
	}

	@RequestMapping(value = "/randomlsit")
	public String RandomList(Model model, HttpSession session, @RequestParam("courseno") int courseno) {
		String userid = session.getAttribute("userid").toString();
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		model.addAttribute("course", courseService.listAll(courseno));
		model.addAttribute("courseno", courseno);
		log.info("[..... course controller RandomList .....]");
		return "course/randomlist";
	}

	@RequestMapping(value = "/randomnext")
	public String RandomNext(Model model, HttpServletRequest request, HttpSession session,
			@RequestParam("courseno") int courseno) {
		String userid = session.getAttribute("userid").toString();
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		ArrayList<SemiItemVO> temp = new ArrayList<SemiItemVO>();
		temp.addAll(courseService.listAll(courseno));

		temp.get(temp.size() - 1).getLatitude();
		temp.get(temp.size() - 1).getLongtitude();

		model.addAttribute("course", courseService.listAll(courseno));
		model.addAttribute("info", infoService.selectOne(userid));
		model.addAttribute("courseinfo", courseService.lastCourse(userid));
		model.addAttribute("list", itemService.recommend(courseno, userid));
		log.info("[..... course controller RandomNext .....]");
		return "course/randomnext";
	}

}
