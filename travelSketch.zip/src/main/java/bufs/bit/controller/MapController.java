package bufs.bit.controller;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.ItemVO;
import bufs.bit.domain.mapSrcVO;
import bufs.bit.service_Interface.I_ItemService;
import bufs.bit.service_Interface.I_MapService;

@Controller
@RequestMapping(value = "/map/*")
public class MapController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	private I_MapService mapService;

	@Inject
	private I_ItemService itemServie;

	@RequestMapping(value = "/marker", method = RequestMethod.GET)
	public String List(Model model, HttpServletRequest request, HttpSession session) {
		log.info("[..... map controller List  .....]");
		return "map/marker";
	}

	@RequestMapping(value = "/circle", method = RequestMethod.GET)
	public String circle(Model model, HttpServletRequest request, HttpSession session) {
		log.info("[..... map controller circle  .....]");
		return "map/circle";
	}

	@RequestMapping(value = "/click", method = RequestMethod.GET)
	public String click(Model model, HttpServletRequest request, HttpSession session) {
		log.info("[..... map controller click  .....]");
		return "map/click";
	}
	
	@RequestMapping(value = "/goMarker", method = RequestMethod.GET)
	public String goMarker(Model model, HttpServletRequest request, HttpSession session) {
		log.info("[..... map controller goMarker  .....]");
		return "map/goMarker";
	}
	
	@RequestMapping(value = "/topten", method = RequestMethod.GET)
	public String topten(Model model, HttpServletRequest request, HttpSession session) {
		log.info("[..... map controller topten  .....]");
		return "map/topten";
	}

	String name;

	@RequestMapping(value = "/coordinateforward", method = RequestMethod.GET)
	public String around(@RequestParam("x") double x, @RequestParam("y") double y, Model model) {
		ItemVO itemVO = new ItemVO();
		itemVO.setLatitude(x);
		itemVO.setLongtitude(y);

		ArrayList<ItemVO> coordinate = new ArrayList<ItemVO>();

		coordinate.addAll((ArrayList<ItemVO>) mapService.rAround(itemVO));
		coordinate.addAll((ArrayList<ItemVO>) mapService.hAround(itemVO));
		coordinate.addAll((ArrayList<ItemVO>) mapService.vAround(itemVO));
		coordinate.addAll((ArrayList<ItemVO>) mapService.cAround(itemVO));
		coordinate.addAll((ArrayList<ItemVO>) mapService.sAround(itemVO));

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();
		for (int i = 0; i < coordinate.size(); i++) {
			try {
				if (!coordinate.get(i).getRname().isEmpty())
					name = coordinate.get(i).getRname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (!coordinate.get(i).getHname().isEmpty())
					name = coordinate.get(i).getHname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (!coordinate.get(i).getVname().isEmpty())
					name = coordinate.get(i).getVname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (!coordinate.get(i).getCname().isEmpty())
					name = coordinate.get(i).getCname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			try {
				if (!coordinate.get(i).getSname().isEmpty())
					name = coordinate.get(i).getSname();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
			double xkey = coordinate.get(i).getLatitude();
			double ykey = coordinate.get(i).getLongtitude();
			mapSrcVO mapSrcVO = new mapSrcVO(name, xkey, ykey);
			mapSrc.add(mapSrcVO);
		}

		for (int i = 0; i < coordinate.size(); i++) {
			System.out.println(mapSrc.get(i).getName());
		}

		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... map controller around  .....]");
		return "map/coordinateforward";
	}

	@RequestMapping(value = "/mapmarkone", method = RequestMethod.GET)
	public String mmo(@RequestParam("x") double x, @RequestParam("y") double y, Model model) {
		ArrayList<mapSrcVO> mapsrc = new ArrayList<mapSrcVO>();
		mapsrc.add(new mapSrcVO(x, y));
		model.addAttribute("mapsrc", mapsrc);
		
		log.info("[..... map controller mapmarkone  .....]");
		return "map/coordinateforward";

	}

}
