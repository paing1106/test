package bufs.bit.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.MemberVO;
import bufs.bit.service_Interface.I_MemberService;

@Controller
@RequestMapping( value = "/member/*" )
public class MemberController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	private I_MemberService MemberService;

	//로그인 페이지로 이동 하는 컨트롤러
	@RequestMapping( value = "/login" , method = RequestMethod.GET )
	public String login( Model model){
		log.info("[----- member controller login  -----]");
		return "redirect:../home";		
	}
	//로그인 페이지에서 id, pass 검사해서 세션 등록하고 로그인 시키는 컨트롤러
	@RequestMapping( value = "/login" , method = RequestMethod.POST )
	public String loginCheck(MemberVO vo,Model model,HttpServletRequest request){		
		String url="";
		if(MemberService.logincheck(vo)==1){
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", vo.getUserid());
			url="redirect:../home";
			String id = (String) session.getAttribute("userid");
			model.addAttribute("userid",id);
		}else{
			url="redirect:/login";
		}		
		log.info("[----- member controller loginCheck  -----]");		
		//return url;
		String referer = request.getHeader("Referer");
	    return "redirect:"+ referer;
	}
	
	@RequestMapping( value = "/logout" , method = RequestMethod.GET )
	public String logOUT(HttpSession session){
		session.removeAttribute("userid");		
		log.info("[..... member controller travelnotedetail  .....]");
		return "redirect:/member/login";
	}
	

	//join 페이지로 이동하는 컨트롤러
	@RequestMapping( value = "/join" , method = RequestMethod.GET )
	public String joinGet(Model model){
		log.info("[-----   member controller joinGET  -----]");
		return "member/join";
	}
	
	//join 아이디 중복 확인, 이메일 포맷 확인 등 필요
	@RequestMapping( value = "/checkid" , method = RequestMethod.GET )
	   public String checkId(@RequestParam("id") String id, Model model){      
	      MemberVO vo = new MemberVO();
	      vo.setUserid(id);
	      String state = "";
	      if(MemberService.logincheck(vo)==1){         
	         state="bad";         
	      }else if(id.equals("")){
	         state="null";   
	      }
	      else{
	         state="good";
	      }
	      model.addAttribute("id", id);
	      model.addAttribute("state", state);
	      log.info("[===== member controller checkId  =====]");
	      return "member/join";
	   }
	
	//가입 POST
	@RequestMapping( value = "/checkid" , method = RequestMethod.POST )
	public String checkIdPOST(@RequestParam("id") String id, Model model,MemberVO vo){		
		vo.setUserid(id);
		MemberService.adduser(vo);
		log.info("[===== member controller joinPost  =====]");
		//return "redirect:../item/list?page=1&cid=1";
		return "redirect:../";
	}
	
	//userdetail user가 가입했을때 입력했던 사항들 출력하는 페이지로 이동하는 컨트롤러, 유저 정보 확인 페이지
	@RequestMapping( value = "/userdetail" , method = RequestMethod.GET )
	public String userdetail(Model model,HttpSession session){
		String id = (String) session.getAttribute("userid");		
		MemberVO vo = new MemberVO();
		vo.setUserid(id);		
		model.addAttribute("userdetail", MemberService.selectuser(vo));
		log.info("[===== member controller userdetail  =====]");
		return "/member/userdetail";
	}
	
	//updateuser user 수정 페이지로 이동하는 컨트롤러
	@RequestMapping( value = "/userupdate" , method = RequestMethod.GET )
	public String userupdate(Model model,HttpSession session){
		String id = (String) session.getAttribute("userid");	
		model.addAttribute("userid", id);
		MemberVO vo = new MemberVO();
		vo.setUserid(id);		
		model.addAttribute("userdetail", MemberService.selectuser(vo));
		log.info("[===== member controller userupdateGET  =====]");
		return "/member/updateuser";
	}
	
	//updateuser user 수정 페이지에서 수정 후 저장하는 컨트롤러 리턴은 다시 정보 확인 페이지
	@RequestMapping( value = "/userupdate" , method = RequestMethod.POST )
	public String userupdate(MemberVO vo, Model model, HttpSession session){		
		String id = (String) session.getAttribute("userid");	
		model.addAttribute("userid", id);
		vo.setUserid(id);	
		MemberService.update(vo);
		log.info("[===== member controller userupdatePOST  =====]");
		return "redirect:/member/userdetail";
	}

}
