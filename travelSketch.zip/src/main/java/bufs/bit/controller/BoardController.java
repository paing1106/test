package bufs.bit.controller;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.ItemVO;
import bufs.bit.domain.MemberVO;
import bufs.bit.domain.NoteReplyVO;
import bufs.bit.domain.ReplyVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.domain.T_NoteVO;
import bufs.bit.domain.mapSrcVO;
import bufs.bit.service.MemberService;
import bufs.bit.service_Interface.I_BoardService;
import bufs.bit.service_Interface.I_CourseService;
import bufs.bit.service_Interface.I_ItemService;
import bufs.bit.service_Interface.I_MemberService;
import bufs.bit.service_Interface.I_TNoteService;

@Controller
@RequestMapping(value = "/board/*")
public class BoardController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	private I_BoardService boardService;

	@Inject
	private I_TNoteService NoteService;

	@Inject
	private I_CourseService courseService;

	@Inject
	private I_ItemService ItemService;
	
	@Inject
	private I_MemberService MemberService;
	
	
	
	/*
	@RequestMapping(value = "/detail", method = RequestMethod.POST)
	public String loginCheckDetail(MemberVO vo,Model model,HttpServletRequest request){
		String url="";				
		if(MemberService.logincheck(vo)==1){
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", vo.getUserid());
			url="redirect:/home";
			String id = (String) session.getAttribute("userid");
			model.addAttribute("userid",id);
		}else{
			url="redirect:/home";
		}				
		log.info("[..... item  controller loginCheckDetail POST .....]");
		return url;		
	}
	*/

	int Rno;
	//댓글작성
	@RequestMapping(value = "/detail", method = RequestMethod.POST)
	public String detailPOST(ReplyVO vo, Model model, HttpSession session, HttpServletRequest request) {
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		vo.setUserid(userid);
		int cid = vo.getCid();
		switch (cid) {
		case 1:
			Rno = vo.getRestaurant();
			boardService.insertRestReply(vo);
			break;
		case 2:
			Rno = vo.getHotel();
			boardService.insertHotelReply(vo);
			break;
		case 3:
			Rno = vo.getViewpoint();
			boardService.insertViewReply(vo);
			break;
		case 4:
			Rno = vo.getCulture();
			boardService.insertCulReply(vo);
			break;
		case 5:
			Rno = vo.getShop();
			boardService.insertShopReply(vo);
			break;
		}

		log.info("[..... board controller detail POST  .....]");
		return "redirect:/board/detail?no=" + Rno + "&cid=" + cid + "&rpage=1";
	}

	

	int no;
	String name;
	double latitude;
	double longtitude;	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public String detail(@RequestParam("no") int itemno, @RequestParam("cid") int cid, @RequestParam("rpage") int rpage,
			Model model, HttpSession session) {
		no = itemno;
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("idlist", courseService.idlist(id));		
		ItemVO tempVO = new ItemVO();		
		ArrayList<ItemVO> itemList = new ArrayList<ItemVO>();
		
		ArrayList<ReplyVO> replyList = new ArrayList<ReplyVO>();
		ReplyVO replyVO = new ReplyVO();
		replyVO.setCid(cid);
		replyVO.setPageno(rpage);
		
		switch (cid) {
		case 1:// r
			tempVO.setRitem_no(no);
			itemList.addAll((ArrayList<ItemVO>) ItemService.RestDetail(tempVO));
			replyVO.setRestaurant(no);
			replyList.addAll((ArrayList<ReplyVO>) boardService.ItemReply(replyVO));
			totalCount = boardService.restCount(replyVO);
			break;
		case 2:// h
			tempVO.setHitem_no(no);
			itemList.addAll((ArrayList<ItemVO>) ItemService.HotelDetail(tempVO));
			replyVO.setHotel(no);
			replyList.addAll((ArrayList<ReplyVO>) boardService.ItemReply(replyVO));
			totalCount = boardService.hotelCount(replyVO);
			break;
		case 3:// v
			tempVO.setVitem_no(no);
			itemList.addAll((ArrayList<ItemVO>) ItemService.ViewDetail(tempVO));
			replyVO.setViewpoint(no);
			replyList.addAll((ArrayList<ReplyVO>) boardService.ItemReply(replyVO));
			totalCount = boardService.viewCount(replyVO);
			break;
		case 4:// c
			tempVO.setCitem_no(no);
			itemList.addAll((ArrayList<ItemVO>) ItemService.CulDetail(tempVO));
			replyVO.setCulture(no);
			replyList.addAll((ArrayList<ReplyVO>) boardService.ItemReply(replyVO));
			totalCount = boardService.culCount(replyVO);
			break;
		case 5:// s
			tempVO.setSitem_no(no);
			itemList.addAll((ArrayList<ItemVO>) ItemService.ShopDetail(tempVO));
			replyVO.setShop(no);
			replyList.addAll((ArrayList<ReplyVO>) boardService.ItemReply(replyVO));
			totalCount = boardService.shopCount(replyVO);
			break;
		}

		for (int i = 0; i < itemList.size(); i++) {
			switch (cid) {
			case 1:
				no = itemList.get(i).getRitem_no();
				name = itemList.get(i).getRname();
				break;
			case 2:
				no = itemList.get(i).getHitem_no();
				name = itemList.get(i).getHname();
				break;
			case 3:
				no = itemList.get(i).getVitem_no();
				name = itemList.get(i).getVname();
				break;
			case 4:
				no = itemList.get(i).getCitem_no();
				name = itemList.get(i).getCname();
				break;
			case 5:
				no = itemList.get(i).getSitem_no();
				name = itemList.get(i).getSname();
				break;
			}

			String addr = itemList.get(i).getAddr();
			String addr2 = itemList.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			latitude = itemList.get(i).getLatitude();
			longtitude = itemList.get(i).getLongtitude();
			String homepage = itemList.get(i).getHomepage();
			String time = itemList.get(i).getTime();
			String parking = itemList.get(i).getParking();
			String tel = itemList.get(i).getTel();
			String credit = itemList.get(i).getCredit();
			String t_and_m = itemList.get(i).getT_and_m();
			String m_and_p = itemList.get(i).getM_and_p();
			String contents = itemList.get(i).getContents();
			String holiday = itemList.get(i).getHoliday();
			String mainimg = itemList.get(i).getMainimg();
			String mainimgdetail = itemList.get(i).getMainimg();
			String img1 = itemList.get(i).getImg1();
			String img1title = itemList.get(i).getImg1title();
			String img2 = itemList.get(i).getImg2();
			String img2title = itemList.get(i).getImg2();
			String img3 = itemList.get(i).getImg3();
			String listimg = itemList.get(i).getListimg();
			String listimgdetail = itemList.get(i).getListimgdetail();
			String ldgimg = itemList.get(i).getLdgimg();
			String ldgImgdetail = itemList.get(i).getLdgImgdetail();
			String courseimg = itemList.get(i).getCourseimg();
			String courseimgdetail = itemList.get(i).getCourseimgdetail();
			String trafin = itemList.get(i).getTrafin();
			String trafout = itemList.get(i).getTrafout();
			String sellItems = itemList.get(i).getSellItems();
			String useGiftCerti = itemList.get(i).getUseGiftCerti();
			String disest = itemList.get(i).getDisest();
			String expe = itemList.get(i).getExpe();
			String useest = itemList.get(i).getUseest();
			String mvTrrsrtNm = itemList.get(i).getMvTrrsrtNm();
			String mvActors = itemList.get(i).getMvActors();
			String around = itemList.get(i).getAround();
			String etc = itemList.get(i).getEtc();
			String startDate = itemList.get(i).getStartDate();
			String endDate = itemList.get(i).getEndDate();
			String reservation = itemList.get(i).getReservation();
			String institution = itemList.get(i).getInstitution();
			String touCourse = itemList.get(i).getTouCourse();
			String touProduct = itemList.get(i).getTouProduct();
			String touFood = itemList.get(i).getTouFood();
			String touMapinfo = itemList.get(i).getTouMapinfo();
			String category = itemList.get(i).getCategory();
			int visi = itemList.get(i).getVisible();

			SemiItemVO itemVO = new SemiItemVO(no, cid, addr, homepage, latitude, longtitude, time, parking, tel,
					credit, t_and_m, m_and_p, name, contents, holiday, mainimg, mainimgdetail, img1, img1title, img2,
					img2title, img3, listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail, trafin,
					trafout, sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around, etc,
					startDate, endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo, category,
					visi);

			model.addAttribute("detail", itemVO);
		}
		
		model.addAttribute("reply", replyList);
		
		
		SemiItemVO semiVO = new SemiItemVO();
		semiVO.setCid(cid);
		semiVO.setNo(no);		
		model.addAttribute("around", ItemService.Around(semiVO,0));

		ArrayList<mapSrcVO> mapList = new ArrayList<mapSrcVO>();
		mapList.add(new mapSrcVO(name, latitude, longtitude, cid));
		model.addAttribute("mapsrc", mapList);
		for (int j = 0; j < mapList.size(); j++) {
			session.setAttribute("lat", mapList.get(j).getX());
			model.addAttribute("lat", mapList.get(j).getX());
			session.setAttribute("lng", mapList.get(j).getY());
			model.addAttribute("lng", mapList.get(j).getY());
		}

		endPage = (int) (Math.ceil(rpage / (double) 10) * 10);
		startPage = (endPage - 10) + 1;
		tempEnd = (int) (Math.ceil(totalCount / (double) 10));
		if (endPage > tempEnd) {
			endPage = tempEnd;
		}
		if (startPage == 1) {
			prev = 1;
		} else {
			prev = startPage - 1;
		}
		if (endPage * 10 >= totalCount) {
			next = rpage;
		} else {
			next = endPage + 1;
		}
		
		model.addAttribute("total", totalCount);
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);
		model.addAttribute("cid", cid);
		log.info("[..... board controller detail GET .....]");
		return "item/detail";
	}

	// item 의 detail 에 대한 댓글 작성 페이지로 이동
	@RequestMapping(value = "/reply", method = RequestMethod.GET)
	public String replyGET(@RequestParam("itemno") int itemno, @RequestParam("cid") int cid, Model model,
			HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("itemno", itemno);
		model.addAttribute("cid", cid);
		log.info("[..... board controller replyGET  .....]");
		return "board/itemreply";
	}

	// ItemReply 입력한후 DB 에 저장
	@RequestMapping(value = "/reply", method = RequestMethod.POST)
	public String replyPOST(ReplyVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		boardService.addReply1(vo);
		vo.setReview_no(boardService.addReply2(vo));
		boardService.addReply3(vo);
		int no = vo.getCulture() + vo.getHotel() + vo.getRestaurant() + vo.getShop() + vo.getViewpoint();
		int cid = vo.getCid();
		log.info("[..... board controller replyPOST  .....]");
		return "redirect:/item/detail?no=" + no + "&cid=" + cid;
	}

	int totalCount;
	int startPage;
	int endPage;
	int prev;
	int next;
	int tempEnd;

	// travelnote list 페이지로 로 이동하는 컨트롤러
	@RequestMapping(value = "/travelnotelist", method = RequestMethod.GET)
	public String travelnotelist(@RequestParam("page") int page, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		session.setAttribute("userid", id);
		model.addAttribute("list", NoteService.NoteList(page));	

		totalCount = NoteService.pageCount();
		endPage = (int) (Math.ceil(page / (double) 10) * 10);
		startPage = (endPage - 10) + 1;
		tempEnd = (int) (Math.ceil(totalCount / (double) 10));
		if (endPage > tempEnd) {
			endPage = tempEnd;
		}
		if (startPage == 1) {
			prev = 1;
		} else {
			prev = startPage - 1;
		}
		if (endPage * 10 >= totalCount) {
			next = page;
		} else {
			next = endPage + 1;
		}
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);
		log.info("[..... board controller travelnotelist  .....]");
		return "/board/notelist";
	}

	@RequestMapping( value = "/travelnotelist" , method = RequestMethod.POST )
	public String loginCheck(MemberVO vo,Model model,HttpServletRequest request){
		String url="";				
		if(MemberService.logincheck(vo)==1){
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", vo.getUserid());
			url="redirect:/home";
			String id = (String) session.getAttribute("userid");
			model.addAttribute("userid",id);
		}else{
			url="redirect:/home";
		}				
		log.info("[..... board  controller loginCheck POST .....]");
		return url;		
	}

	// travelnote 작성 페이지로 로 이동하는 컨트롤러 id 에 저장되어있는 course 정보를 가져와야 한다
	@RequestMapping(value = "/travelnote", method = RequestMethod.GET)
	public String travelnoteGET(Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		ArrayList<CourseVO> list = new ArrayList<CourseVO>();
		list.addAll((ArrayList<CourseVO>)courseService.idlist(id));
		model.addAttribute("course", list);
		int courseno = list.get(0).getCourse_no();	
		model.addAttribute("idlist", courseService.idlist(id));		

		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();
		
		ArrayList<CourseListJoinVO> temp = (ArrayList<CourseListJoinVO>)courseService.courseListH(courseno);
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListR(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListV(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListS(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListC(courseno));

		for (int i = 0; i < temp.size(); i++) {
			try{ if(temp.get(i).getHname().length()>1)
				name = temp.get(i).getHname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(temp.get(i).getRname().length()>1)
				name = temp.get(i).getRname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(temp.get(i).getCname().length()>1)
				name = temp.get(i).getCname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(temp.get(i).getSname().length()>1)
				name = temp.get(i).getSname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(temp.get(i).getVname().length()>1)
				name = temp.get(i).getVname();}catch(NullPointerException e){e.printStackTrace();}
			
			int cid = temp.get(i).getCid()-1;
			double x = Double.parseDouble(temp.get(i).getLatitude()); 			
			double y = Double.parseDouble(temp.get(i).getLongtitude());			
			mapSrcVO vo = new mapSrcVO(name,x,y,cid);
			mapSrc.add(vo);			
		}		
		model.addAttribute("mapsrc", mapSrc);				
		log.info("[..... board controller travelnoteGET  .....]");
		return "board/travelnote";
	}

	@RequestMapping(value = "/travelnote2", method = RequestMethod.GET)
	public String travelnote2GET(Model model, HttpSession session, @RequestParam("courseno") int courseno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		ArrayList<CourseVO> list = new ArrayList<CourseVO>();
		list.addAll((ArrayList<CourseVO>)courseService.idlist(id));
		model.addAttribute("course", list);
		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();
		
		ArrayList<CourseListJoinVO> temp = (ArrayList<CourseListJoinVO>)courseService.courseListH(courseno);
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListR(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListV(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListS(courseno));
		temp.addAll((ArrayList<CourseListJoinVO>)courseService.courseListC(courseno));

		for (int i = 0; i < temp.size(); i++) {
			try{ if(temp.get(i).getHname().length()>1)
				name = temp.get(i).getHname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(temp.get(i).getRname().length()>1)
				name = temp.get(i).getRname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(temp.get(i).getCname().length()>1)
				name = temp.get(i).getCname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(temp.get(i).getSname().length()>1)
				name = temp.get(i).getSname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(temp.get(i).getVname().length()>1)
				name = temp.get(i).getVname();}catch(NullPointerException e){e.printStackTrace();}
			
			int cid = temp.get(i).getCid()-1;
			double x = Double.parseDouble(temp.get(i).getLatitude()); 			
			double y = Double.parseDouble(temp.get(i).getLongtitude());			
			mapSrcVO vo = new mapSrcVO(name,x,y,cid);
			mapSrc.add(vo);			
		}		
		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... board controller travelnote2GET  .....]");
		return "board/travelnote";
	}

	// travelnote 작성 하고 저장
	@RequestMapping(value = "/travelnote", method = RequestMethod.POST)
	public String travelnotePOST(T_NoteVO vo, Model model, HttpSession session, HttpServletRequest request) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		vo.setContent(request.getParameter("content"));
		try {
			NoteService.add(vo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.info("[..... board controller travelnotePOST  .....]");
		return "redirect:/board/travelnotelist?page=1";
	}

	// travelnote detail
	// no 를 받아서 코스 번호 알아내서 코스 번호 가지고 코스 리스트 가서 각 좌표를 얻어와야 함
	@RequestMapping(value = "/travelnotedetail", method = RequestMethod.GET)
	public String travelnotedetail(@RequestParam("noteno") int noteno, @RequestParam("rpage") int rpage, Model model,
			HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		session.setAttribute("userid", id);
		T_NoteVO NoteVO = NoteService.NoteDetail(noteno);
		model.addAttribute("detail", NoteVO);	
		
		int courseno = NoteVO.getCourse_no();		
		model.addAttribute("CourseInfo", courseService.nolist(courseno)); //코스 이름과 번호가 들어있어요
		
		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();		// list 에 있는걸 단순화 시켜서 mapSrc 에 담아 
		ArrayList<CourseListJoinVO> list = new ArrayList<CourseListJoinVO>() ; //각 지점의 이것 저것 들어있음
		list.addAll(courseService.courseListR(courseno));
		list.addAll(courseService.courseListH(courseno));
		list.addAll(courseService.courseListC(courseno));
		list.addAll(courseService.courseListV(courseno));
		list.addAll(courseService.courseListS(courseno));
		
		for (int i = 0; i < list.size(); i++) {
			try{ if(list.get(i).getHname().length()>1)
				name = list.get(i).getHname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(list.get(i).getRname().length()>1)
				name = list.get(i).getRname();}catch(NullPointerException e){e.printStackTrace();}
			try{if(list.get(i).getCname().length()>1)
				name = list.get(i).getCname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(list.get(i).getSname().length()>1)
				name = list.get(i).getSname();}catch(NullPointerException e){e.printStackTrace();}
			try{ if(list.get(i).getVname().length()>1)
				name = list.get(i).getVname();}catch(NullPointerException e){e.printStackTrace();}			
			
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			int cid = list.get(i).getCid();
			mapSrcVO mapSrcVO = new mapSrcVO(name, x, y, cid);
			mapSrc.add(mapSrcVO);
		}
		
		model.addAttribute("reply", NoteService.NoteReplyList(noteno));
		totalCount = NoteService.replyCount(noteno);
		model.addAttribute("mapsrc", mapSrc);
		session.setAttribute("list", mapSrc);

		endPage = (int) (Math.ceil(rpage / (double) 10) * 10);
		startPage = (endPage - 10) + 1;
		tempEnd = (int) (Math.ceil(totalCount / (double) 10));
		if (endPage > tempEnd) {
			endPage = tempEnd;
		}
		if (startPage == 1) {
			prev = 1;
		} else {
			prev = startPage - 1;
		}
		if (endPage * 10 >= totalCount) {
			next = rpage;
		} else {
			next = endPage + 1;
		}
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);

		log.info("[..... board controller travelnotedetail  .....]");
		//어디로 가서 marSrc 에 있는 좌표 정보들 세션 
		return "board/notedetail";
	}

	@RequestMapping(value = "/travelnotedetail", method = RequestMethod.POST)
	public String travelnotedetailPOST(NoteReplyVO vo, Model model, HttpSession session) {
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		vo.setUserid(userid);
		NoteService.NoteReply(vo);
		log.info("[..... board controller travelnotedetail POST  .....]");
		return "redirect:/board/travelnotedetail?noteno=" + vo.getNoteno() + "&rpage=1";
	}

	// travelnoteupdate 수정 페이지로 이동하는 컨트롤러
	@RequestMapping(value = "/travelnotemodify", method = RequestMethod.GET)
	public String travelnotemodify(@RequestParam("noteno") int noteno, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("detail", NoteService.NoteDetail(noteno));
		
		model.addAttribute("idlist", courseService.idlist(id));		
		
		int courseno = NoteService.NoteDetail(noteno).getCourse_no();
		model.addAttribute("course_no", courseno);
		model.addAttribute("course", courseService.nolist(courseno));
		ArrayList<mapSrcVO> mapSrc = new ArrayList<mapSrcVO>();
		ArrayList<CourseListJoinVO> list = (ArrayList<CourseListJoinVO>) courseService.courseListR(courseno);
		for (int i = 0; i < list.size(); i++) {
			String name = list.get(i).getRname();
			double x = Double.parseDouble(list.get(i).getLatitude());
			double y = Double.parseDouble(list.get(i).getLongtitude());
			mapSrcVO mapSrcVO = new mapSrcVO(name, x, y);
			mapSrc.add(mapSrcVO);
		}
		model.addAttribute("mapsrc", mapSrc);
		log.info("[..... board controller travelnotemodify  .....]");
		return "board/noteupdate";
	}

	// travelnote 수정 한 후 update 하는 컨트롤러
	@RequestMapping(value = "/travelnotemodify", method = RequestMethod.POST)
	public String travelnotemodifyPOST(T_NoteVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		NoteService.updateNote(vo);
		log.info("[..... board controller travelnotemodifyPOST  .....]");
		return "redirect:/board/travelnotedetail?noteno=" + vo.getNote_no()+"&rpage=1";
	}

	// travelnotereply 작성페이지로 이동하는 컨트롤러
	@RequestMapping(value = "/travelnotereply", method = RequestMethod.GET)
	public String travelnotereplyGET(Model model, HttpSession session, @RequestParam("noteno") int noteno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("noteno", noteno);
		log.info("[..... board controller travelnotereplyGET  .....]");
		return "board/travelnotereply";
	}

	// travelnotereply 작성 후 DB 에 저정하는 컨트롤러
	@RequestMapping(value = "/travelnotereply", method = RequestMethod.POST)
	public String travelnotereplyPOST(NoteReplyVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		vo.setUserid(id);
		NoteService.NoteReply(vo);
		log.info("[..... board controller travelnotereplyPOST  .....]");
		return "redirect:/board/travelnotedetail?noteno=" + vo.getNoteno();
	}

	// travelnotereply ListAll
	@RequestMapping(value = "/notereplylist", method = RequestMethod.GET)
	public String notereplylist(Model model, HttpSession session, @RequestParam("noteno") int noteno) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("NoteReplyList", NoteService.NoteReplyList(noteno));
		log.info("[..... board controller notereplylist  .....]");
		return "board/travelnotereply";
	}

	// travelnotereply 삭제
	@RequestMapping(value = "/delnotereply", method = RequestMethod.GET)
	public String DelNoteReply(Model model, @RequestParam("rno") int rno, @RequestParam("noteno") int noteno,
			HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		NoteService.DelNoteReply(noteno);
		log.info("[..... board controller DelNoteReply  .....]");
		return "redirect:/board/not";
	}

	@RequestMapping("/getAttach/{note_no}")
	@ResponseBody
	public List<String> getAttach(@PathVariable("note_no") int note_no) throws Exception{
		return NoteService.getAttach(note_no);
	}
	
	
	//--------------------------------------------------------------------------------------------------------------------------------------
	
	@RequestMapping(value="/setting", method=RequestMethod.GET)
	public String setting(HttpSession session, Model model) throws Exception{
		String id= (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		log.info("[..... board controller setting  .....]");
		return "/admin/setting";
	}
	
}
