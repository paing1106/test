package bufs.bit.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import bufs.bit.domain.T_InfoVO;
import bufs.bit.service.TInfoService;

@Controller
@RequestMapping(value= "/TravelInfo/*")
public class TravelInfoController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);	
	
	@Inject
	private TInfoService travelInfoService;

	@RequestMapping(value = "/insertTravelInfo", method = RequestMethod.GET)
	public String insertTravelInfoGET(Model model, HttpSession session){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);		
		log.info("[..... TravelInfo controller insertTravelInfoGET  .....]");
		return "/TravelInfo/insertTravelInfo";
	}
	
	@RequestMapping(value = "/insertTravelInfo", method = RequestMethod.POST)
	public String insertTravelInfoPost(T_InfoVO vo,Model model, HttpSession session, HttpServletRequest request){
		String userid=(String) session.getAttribute("userid");
		vo.setUserid(userid);
		model.addAttribute("userid", userid);
		model.addAttribute("vo", vo);
		
		request.setAttribute("infoVO", vo);
		travelInfoService.create(vo);
//		T_InfoVO a = travelInfoService.selectOne(userid);
//		model.addAttribute("a", a);	
		
		log.info("[..... TravelInfo controller insertTravelInfoPost  .....]");
		
		return "/TravelInfo/read";
	}
	
	@RequestMapping(value = "/updateTravelInfo", method = RequestMethod.GET)
	public String updateTravelInfoGET(Model model, HttpSession session){
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		log.info("[..... TravelInfo controller updateTravelInfoGET  .....]");
		return "/TravelInfo/update";
	}
	
	@RequestMapping(value = "/updateTravelInfo", method = RequestMethod.POST)
	public String updateTravelInfoPOST(T_InfoVO vo,Model model, HttpSession session){
		String userid = (String) session.getAttribute("userid");
		vo.setUserid(userid);
		model.addAttribute("userid", userid);
		travelInfoService.update(vo);
		log.info("[..... TravelInfo controller updateTravelInfoPOST  .....]");
		return "redirect:/TravelInfo/insertTravelInfo";
	}
	
	@RequestMapping(value = "/deleteTravelInfo", method = RequestMethod.GET)
	public String deleteTravelInfoGET(@RequestParam("T_Info_No") int t_info_no,Model model, HttpSession session){
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		T_InfoVO vo = new T_InfoVO();
		vo.setT_info_no(t_info_no);
		travelInfoService.delete(vo);
		log.info("[..... TravelInfo controller deleteTravelInfoGET  .....]");
		return "redirect:/TravelInfo/insertTravelInfo";
	}
	
	@RequestMapping(value = "/listAllTravelInfo", method = RequestMethod.GET)
	public String listAllTravelInfoGET(Model model, HttpSession session){
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		T_InfoVO vo = new T_InfoVO();
		model.addAttribute("TravelInfo",travelInfoService.listAll(vo));
		log.info("[..... TravelInfo controller listAllTravelInfoGET  .....]");
		return null;
	}
	
	@RequestMapping(value = "/listUserTravelInfo", method = RequestMethod.GET)
	public String listUserTravelInfoGET(HttpSession session, Model model,@RequestParam("id") String id){
		T_InfoVO vo = new T_InfoVO();
		String userid = (String) session.getAttribute("userid");
		vo.setUserid(id);
		model.addAttribute("info", travelInfoService.selectTravelInfo_user(vo));
		model.addAttribute("userid", userid);
		log.info("[..... TravelInfo controller listUserTravelInfoGET  .....]");
		model.addAttribute("vo", travelInfoService.selectOne(userid));
		return "/TravelInfo/read";
	}
	
	
}
