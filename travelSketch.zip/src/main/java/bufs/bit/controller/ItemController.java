package bufs.bit.controller;

import java.util.ArrayList;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.ItemVO;
import bufs.bit.domain.MemberVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.domain.mapVO;
import bufs.bit.domain.pageVO;
import bufs.bit.domain.searchVO;
import bufs.bit.domain.mapSrcVO;
import bufs.bit.service_Interface.I_CategoryService;
import bufs.bit.service_Interface.I_ItemService;
import bufs.bit.service_Interface.I_MemberService;

@Controller
@RequestMapping(value = "/item/*")
public class ItemController {
	static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	I_ItemService itemServie;

	@Inject
	I_CategoryService categoryService;

	@Inject
	I_MemberService memberService;
		

	// additem 페이지로 이동
	@RequestMapping(value = "/addItem", method = RequestMethod.GET)
	public String addItemGET(Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("category", categoryService.listAll());
		log.info("[..... item controller addItemGET  .....]");
		return "item/addItem";
	}

	String url = "";
	// additem 페이지에서 DB 에 저장, 관리자일 경우와 사용자일 경우가 입력이 다르도록 한다
	   @RequestMapping(value = "/addItem", method = RequestMethod.POST)
	   public String addItemPOST(Model model, HttpSession session, SemiItemVO vo, HttpServletRequest request) {
	      String userid = (String) session.getAttribute("userid");
	      vo.setContents(request.getParameter("content"));
	      model.addAttribute("userid", userid);
	      int auth = memberService.authcheck(userid);
	      ItemVO itemvo = new ItemVO();
	      if (auth == 1) { // 인증 넘버가 1 (관리자) 일 경우
	         url = "redirect:/item/list?page=1&cid="+vo.getCid();
	         itemvo.setVisible(1);
	      } else {
	         url = "redirect:/item/list?page=1&cid="+vo.getCid();
	         itemvo.setVisible(2);
	      }
	      int cid = vo.getCid();
	    
	      switch (cid) {
	      case 1:// r         
		         itemvo.setRitem_no(vo.getNo());
		         itemvo.setAddr(vo.getAddr());
		         itemvo.setCid(vo.getCid());
		         itemvo.setRname(vo.getName());
		         itemvo.setContents(vo.getContents());
		         itemvo.setTel(vo.getTel());
		         itemvo.setLatitude(vo.getLatitude());
		         itemvo.setLongtitude(vo.getLongtitude());
		         itemvo.setStartDate(vo.getStartDate());
		         itemvo.setEndDate(vo.getEndDate());
		         itemvo.setReservation(vo.getReservation());
		         itemvo.setExpe(vo.getExpe());
		         itemvo.setSellItems(vo.getSellItems());
		         itemvo.setM_and_p(vo.getM_and_p());
		         itemvo.setDisest(vo.getDisest());
		         itemvo.setTime(vo.getTime());
		         itemvo.setHoliday(vo.getHoliday());
		         itemvo.setCredit(vo.getCredit());
		         itemvo.setHomepage(vo.getHomepage());
		         itemvo.setTrafin(vo.getTrafin());
		         itemvo.setTrafout(vo.getTrafout());
		         itemvo.setParking(vo.getParking());
		         itemvo.setEtc(vo.getEtc());
		         
		         itemServie.addRest(itemvo);
		         break;
		      case 2:// h
		    	  itemvo.setHitem_no(vo.getNo());
			         itemvo.setAddr(vo.getAddr());
			         itemvo.setCid(vo.getCid());
			         itemvo.setHname(vo.getName());
			         itemvo.setContents(vo.getContents());
			         itemvo.setTel(vo.getTel());
			         itemvo.setLatitude(vo.getLatitude());
			         itemvo.setLongtitude(vo.getLongtitude());
			         itemvo.setStartDate(vo.getStartDate());
			         itemvo.setEndDate(vo.getEndDate());
			         itemvo.setReservation(vo.getReservation());
			         itemvo.setExpe(vo.getExpe());
			         itemvo.setSellItems(vo.getSellItems());
			         itemvo.setM_and_p(vo.getM_and_p());
			         itemvo.setDisest(vo.getDisest());
			         itemvo.setTime(vo.getTime());
			         itemvo.setHoliday(vo.getHoliday());
			         itemvo.setCredit(vo.getCredit());
			         itemvo.setHomepage(vo.getHomepage());
			         itemvo.setTrafin(vo.getTrafin());
			         itemvo.setTrafout(vo.getTrafout());
			         itemvo.setParking(vo.getParking());
			         itemvo.setEtc(vo.getEtc());
			         itemServie.addHotel(itemvo);
		         break;
		      case 3:// v
		    	  itemvo.setVitem_no(vo.getNo());
			         itemvo.setAddr(vo.getAddr());
			         itemvo.setCid(vo.getCid());
			         itemvo.setVname(vo.getName());
			         itemvo.setContents(vo.getContents());
			         itemvo.setTel(vo.getTel());
			         itemvo.setLatitude(vo.getLatitude());
			         itemvo.setLongtitude(vo.getLongtitude());
			         itemvo.setStartDate(vo.getStartDate());
			         itemvo.setEndDate(vo.getEndDate());
			         itemvo.setReservation(vo.getReservation());
			         itemvo.setExpe(vo.getExpe());
			         itemvo.setSellItems(vo.getSellItems());
			         itemvo.setM_and_p(vo.getM_and_p());
			         itemvo.setDisest(vo.getDisest());
			         itemvo.setTime(vo.getTime());
			         itemvo.setHoliday(vo.getHoliday());
			         itemvo.setCredit(vo.getCredit());
			         itemvo.setHomepage(vo.getHomepage());
			         itemvo.setTrafin(vo.getTrafin());
			         itemvo.setTrafout(vo.getTrafout());
			         itemvo.setParking(vo.getParking());
			         itemvo.setEtc(vo.getEtc());
			         
			         itemServie.addView(itemvo);
		         break;
		      case 4:// c
		    	  itemvo.setCitem_no(vo.getNo());
			         itemvo.setAddr(vo.getAddr());
			         itemvo.setCid(vo.getCid());
			         itemvo.setCname(vo.getName());
			         itemvo.setContents(vo.getContents());
			         itemvo.setTel(vo.getTel());
			         itemvo.setLatitude(vo.getLatitude());
			         itemvo.setLongtitude(vo.getLongtitude());
			         itemvo.setStartDate(vo.getStartDate());
			         itemvo.setEndDate(vo.getEndDate());
			         itemvo.setReservation(vo.getReservation());
			         itemvo.setExpe(vo.getExpe());
			         itemvo.setSellItems(vo.getSellItems());
			         itemvo.setM_and_p(vo.getM_and_p());
			         itemvo.setDisest(vo.getDisest());
			         itemvo.setTime(vo.getTime());
			         itemvo.setHoliday(vo.getHoliday());
			         itemvo.setCredit(vo.getCredit());
			         itemvo.setHomepage(vo.getHomepage());
			         itemvo.setTrafin(vo.getTrafin());
			         itemvo.setTrafout(vo.getTrafout());
			         itemvo.setParking(vo.getParking());
			         itemvo.setEtc(vo.getEtc());
			         
			         itemServie.addCul(itemvo);
		         break;
		      case 5:// s
		    	  itemvo.setSitem_no(vo.getNo());
			         itemvo.setAddr(vo.getAddr());
			         itemvo.setCid(vo.getCid());
			         itemvo.setSname(vo.getName());
			         itemvo.setContents(vo.getContents());
			         itemvo.setTel(vo.getTel());
			         itemvo.setLatitude(vo.getLatitude());
			         itemvo.setLongtitude(vo.getLongtitude());
			         itemvo.setStartDate(vo.getStartDate());
			         itemvo.setEndDate(vo.getEndDate());
			         itemvo.setReservation(vo.getReservation());
			         itemvo.setExpe(vo.getExpe());
			         itemvo.setSellItems(vo.getSellItems());
			         itemvo.setM_and_p(vo.getM_and_p());
			         itemvo.setDisest(vo.getDisest());
			         itemvo.setTime(vo.getTime());
			         itemvo.setHoliday(vo.getHoliday());
			         itemvo.setCredit(vo.getCredit());
			         itemvo.setHomepage(vo.getHomepage());
			         itemvo.setTrafin(vo.getTrafin());
			         itemvo.setTrafout(vo.getTrafout());
			         itemvo.setParking(vo.getParking());
			         itemvo.setEtc(vo.getEtc());
			         
			         itemServie.addShop(itemvo);
		         break;
	      }
	      log.info("[===== item controller addItemPOST  =====]");
	      return url;
	   }

	// 카테고리 선택
	@RequestMapping(value = "/selectcate", method = RequestMethod.GET)
	public String selectCate(@RequestParam("categorey") int cid, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		log.info("[===== item controller selectCate  =====]");
		return "redirect:item/list?page=1&cid=" + cid;
	}

	int totalCount;
	int startPage;
	int endPage;
	int tempEnd;
	int prev;
	int next;
	int no;
	String name;

	// 리스트 출력 - 관리자가 인증한 item 만 출력하도록 변경 (where visible = 1)
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String List(@RequestParam("page") int page, @RequestParam("cid") int cid, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		int visible = 1;
		pageVO vo = new pageVO();
		vo.setVisible(visible);
		vo.setPageno(page);		
		model.addAttribute("selectCategory", categoryService.listAll());
		ArrayList<ItemVO> list1 = new ArrayList<ItemVO>();
		switch (cid) {
		case 1:
			list1.addAll(itemServie.RestList(vo));
			totalCount = itemServie.RestCount(visible);
			break;
		case 2:
			list1.addAll(itemServie.HotelList(vo));
			totalCount = itemServie.HotelCount(visible);
			break;
		case 3:
			list1.addAll(itemServie.ViewList(vo));
			totalCount = itemServie.ViewCount(visible);
			break;
		case 4:
			list1.addAll(itemServie.CulList(vo));
			totalCount = itemServie.CulCount(visible);
			break;
		case 5:
			list1.addAll(itemServie.ShopList(vo));
			totalCount = itemServie.ShopCount(visible);
			break;
		}
		ArrayList<SemiItemVO> list2 = new ArrayList<SemiItemVO>();
		
		for (int i = 0; i < list1.size(); i++) {

			switch (cid) {
			case 1:
				no = list1.get(i).getRitem_no();
				name = list1.get(i).getRname();
				break;
			case 2:
				no = list1.get(i).getHitem_no();
				name = list1.get(i).getHname();
				break;
			case 3:
				no = list1.get(i).getVitem_no();
				name = list1.get(i).getVname();
				break;
			case 4:
				no = list1.get(i).getCitem_no();
				name = list1.get(i).getCname();
				break;
			case 5:
				no = list1.get(i).getSitem_no();
				name = list1.get(i).getSname();
				break;
			}

			String addr = list1.get(i).getAddr();
			String addr2 = list1.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			String homepage = list1.get(i).getHomepage();
			double latitude = list1.get(i).getLatitude();
			double longtitude = list1.get(i).getLongtitude();
			String time = list1.get(i).getTime();
			String parking = list1.get(i).getParking();
			String tel = list1.get(i).getTel();
			String credit = list1.get(i).getCredit();
			String t_and_m = list1.get(i).getT_and_m();
			String m_and_p = list1.get(i).getM_and_p();
			String contents = list1.get(i).getContents();
			String holiday = list1.get(i).getHoliday();
			String mainimg = list1.get(i).getMainimg();
			String mainimgdetail = list1.get(i).getMainimg();
			String img1 = list1.get(i).getImg1();
			String img1title = list1.get(i).getImg1title();
			String img2 = list1.get(i).getImg2();
			String img2title = list1.get(i).getImg2();
			String img3 = list1.get(i).getImg3();
			String listimg = list1.get(i).getListimg();
			String listimgdetail = list1.get(i).getListimgdetail();
			String ldgimg = list1.get(i).getLdgimg();
			String ldgImgdetail = list1.get(i).getLdgImgdetail();
			String courseimg = list1.get(i).getCourseimg();
			String courseimgdetail = list1.get(i).getCourseimgdetail();
			String trafin = list1.get(i).getTrafin();
			String trafout = list1.get(i).getTrafout();
			String sellItems = list1.get(i).getSellItems();
			String useGiftCerti = list1.get(i).getUseGiftCerti();
			String disest = list1.get(i).getDisest();
			String expe = list1.get(i).getExpe();
			String useest = list1.get(i).getUseest();
			String mvTrrsrtNm = list1.get(i).getMvTrrsrtNm();
			String mvActors = list1.get(i).getMvActors();
			String around = list1.get(i).getAround();
			String etc = list1.get(i).getEtc();
			String startDate = list1.get(i).getStartDate();
			String endDate = list1.get(i).getEndDate();
			String reservation = list1.get(i).getReservation();
			String institution = list1.get(i).getInstitution();
			String touCourse = list1.get(i).getTouCourse();
			String touProduct = list1.get(i).getTouProduct();
			String touFood = list1.get(i).getTouFood();
			String touMapinfo = list1.get(i).getTouMapinfo();
			String category = list1.get(i).getCategory();
			int visi = list1.get(i).getVisible();

			SemiItemVO itemVO = new SemiItemVO(no, cid, addr, homepage, latitude, longtitude, time, parking, tel,
					credit, t_and_m, m_and_p, name, contents, holiday, mainimg, mainimgdetail, img1, img1title, img2,
					img2title, img3, listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail, trafin,
					trafout, sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around, etc,
					startDate, endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo, category,
					visi);
			list2.add(itemVO);
		}

		endPage = (int) (Math.ceil(page / (double) 10) * 10);
		startPage = (endPage - 10) + 1;
		tempEnd = (int) (Math.ceil(totalCount / (double) 10));
		if (endPage > tempEnd) {
			endPage = tempEnd;
		}
		if (startPage == 1) {
			prev = 1;
		} else {
			prev = startPage - 1;
		}
		if (endPage * 10 >= totalCount) {
			next = page;
		} else {
			next = endPage + 1;
		}
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);
		model.addAttribute("list", list2);
		model.addAttribute("cid", cid);
		model.addAttribute("total", totalCount);
		log.info("[..... item controller List  .....]");
		return "item/list";
	}
	
	
	@RequestMapping( value = "/list" , method = RequestMethod.POST )
	public String loginCheck(MemberVO vo,Model model,HttpServletRequest request){
		String url="";				
		if(memberService.logincheck(vo)==1){
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", vo.getUserid());
			url="redirect:/home";
			String id = (String) session.getAttribute("userid");
			model.addAttribute("userid",id);
		}else{
			url="redirect:/home";
		}				
		log.info("[..... item  controller loginCheck POST .....]");
		return url;		
	}

	// updateitem item 수정 페이지로 이동하는 컨트롤러 - 수정은 어드민만 가능 jsp 페이지에서 세션 확인 해서 버튼
	// 보이거나 안보이도록
	@RequestMapping(value = "/updateitem", method = RequestMethod.GET)
	public String updateitemGET(@RequestParam("itemno") int no, @RequestParam("cid") int cid, Model model,
			HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		model.addAttribute("category", categoryService.listAll());
		model.addAttribute("visible", itemServie.visible());
		ItemVO itemVO = new ItemVO();
		switch (cid) {
		case 1:
			itemVO.setRitem_no(no);
			model.addAttribute("vstate", itemServie.checkVisibleRest(itemVO.getRitem_no()));
			model.addAttribute("detail", itemServie.RestDetail(itemVO));
			break;
		case 2:
			itemVO.setHitem_no(no);
			model.addAttribute("vstate", itemServie.checkVisibleHotel(itemVO.getHitem_no()));
			model.addAttribute("detail", itemServie.HotelDetail(itemVO));
			break;
		case 3:
			itemVO.setVitem_no(no);
			model.addAttribute("vstate", itemServie.checkVisibleView(itemVO.getVitem_no()));
			model.addAttribute("detail", itemServie.ViewDetail(itemVO));
			break;
		case 4:
			itemVO.setCitem_no(no);
			model.addAttribute("vstate", itemServie.checkVisibleCul(itemVO.getCitem_no()));
			model.addAttribute("detail", itemServie.CulDetail(itemVO));
			break;
		case 5:
			itemVO.setSitem_no(no);
			model.addAttribute("vstate", itemServie.checkVisibleShop(itemVO.getSitem_no()));
			model.addAttribute("detail", itemServie.ShopDetail(itemVO));
			break;
		}

		log.info("[..... item controller updateitemGET  .....]");
		return "수정페이지";
	}

	// updateitem item 수정 한 후 저장하는 컨트롤러 다시 리스트로 리턴
	@RequestMapping(value = "/updateitem", method = RequestMethod.POST)
	public String updateitemPOST(ItemVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		int cid = vo.getCid();
		StringBuilder sb = new StringBuilder();
		String url = "redirect:item/detail?no=";
		sb.append(url);
		switch (cid) {
		case 1:
			itemServie.updateRest(vo);
			sb.append(vo.getRitem_no());
			break;
		case 2:
			itemServie.updateHotel(vo);
			sb.append(vo.getHitem_no());
			break;
		case 3:
			itemServie.updateView(vo);
			sb.append(vo.getVitem_no());
			break;
		case 4:
			itemServie.updateCul(vo);
			sb.append(vo.getCitem_no());
			break;
		case 5:
			itemServie.updateShop(vo);
			sb.append(vo.getSitem_no());
			break;
		}
		sb.append("&cid=" + cid);
		url = sb.toString();
		log.info("[..... item controller updateitemPOST  .....]");
		return url;
	}

	// (관리자 페이지) 로 이동 - item 에서 관리자가 인증하지 않은 아이템 출력 - 리스트, visible 네임,
	@RequestMapping(value = "/admincheck", method = RequestMethod.GET)
	public String admincheckGET(@RequestParam("page") int page, @RequestParam("cid") int cid, Model model,
			HttpSession session) {
		String userid = (String) session.getAttribute("userid");
		int auth = memberService.authcheck(userid);
		if (auth == 1) {
			int visible = 2;
			pageVO vo = new pageVO();
			vo.setVisible(visible);
			vo.setPageno(page);

			ArrayList<ItemVO> list1 = new ArrayList<ItemVO>();
			switch (cid) {
			case 1:
				list1.addAll(itemServie.RestList(vo));
				totalCount = itemServie.RestCount(visible);
				break;
			case 2:
				list1.addAll(itemServie.HotelList(vo));
				totalCount = itemServie.HotelCount(visible);
				break;
			case 3:
				list1.addAll(itemServie.ViewList(vo));
				totalCount = itemServie.ViewCount(visible);
				break;
			case 4:
				list1.addAll(itemServie.CulList(vo));
				totalCount = itemServie.CulCount(visible);
				break;
			case 5:
				list1.addAll(itemServie.ShopList(vo));
				totalCount = itemServie.ShopCount(visible);
				break;
			}
			ArrayList<SemiItemVO> list2 = new ArrayList<SemiItemVO>();
			for (int i = 0; i < list1.size(); i++) {

				switch (cid) {
				case 1:
					no = list1.get(i).getRitem_no();
					name = list1.get(i).getRname();
					break;
				case 2:
					no = list1.get(i).getHitem_no();
					name = list1.get(i).getHname();
					break;
				case 3:
					no = list1.get(i).getVitem_no();
					name = list1.get(i).getVname();
					break;
				case 4:
					no = list1.get(i).getCitem_no();
					name = list1.get(i).getCname();
					break;
				case 5:
					no = list1.get(i).getSitem_no();
					name = list1.get(i).getSname();
					break;
				}

				String addr = list1.get(i).getAddr();
				String addr2 = list1.get(i).getAddr2();
				if (addr2 != null) {
					addr = addr + addr2;
				}
				String homepage = list1.get(i).getHomepage();
				double latitude = list1.get(i).getLatitude();
				double longtitude = list1.get(i).getLongtitude();
				String time = list1.get(i).getTime();
				String parking = list1.get(i).getParking();
				String tel = list1.get(i).getTel();
				String credit = list1.get(i).getCredit();
				String t_and_m = list1.get(i).getT_and_m();
				String m_and_p = list1.get(i).getM_and_p();
				String contents = list1.get(i).getContents();
				String holiday = list1.get(i).getHoliday();
				String mainimg = list1.get(i).getMainimg();
				String mainimgdetail = list1.get(i).getMainimg();
				String img1 = list1.get(i).getImg1();
				String img1title = list1.get(i).getImg1title();
				String img2 = list1.get(i).getImg2();
				String img2title = list1.get(i).getImg2();
				String img3 = list1.get(i).getImg3();
				String listimg = list1.get(i).getListimg();
				String listimgdetail = list1.get(i).getListimgdetail();
				String ldgimg = list1.get(i).getLdgimg();
				String ldgImgdetail = list1.get(i).getLdgImgdetail();
				String courseimg = list1.get(i).getCourseimg();
				String courseimgdetail = list1.get(i).getCourseimgdetail();
				String trafin = list1.get(i).getTrafin();
				String trafout = list1.get(i).getTrafout();
				String sellItems = list1.get(i).getSellItems();
				String useGiftCerti = list1.get(i).getUseGiftCerti();
				String disest = list1.get(i).getDisest();
				String expe = list1.get(i).getExpe();
				String useest = list1.get(i).getUseest();
				String mvTrrsrtNm = list1.get(i).getMvTrrsrtNm();
				String mvActors = list1.get(i).getMvActors();
				String around = list1.get(i).getAround();
				String etc = list1.get(i).getEtc();
				String startDate = list1.get(i).getStartDate();
				String endDate = list1.get(i).getEndDate();
				String reservation = list1.get(i).getReservation();
				String institution = list1.get(i).getInstitution();
				String touCourse = list1.get(i).getTouCourse();
				String touProduct = list1.get(i).getTouProduct();
				String touFood = list1.get(i).getTouFood();
				String touMapinfo = list1.get(i).getTouMapinfo();
				String category = list1.get(i).getCategory();
				int visi = list1.get(i).getVisible();

				SemiItemVO itemVO = new SemiItemVO(no, cid, addr, homepage, latitude, longtitude, time, parking, tel,
						credit, t_and_m, m_and_p, name, contents, holiday, mainimg, mainimgdetail, img1, img1title,
						img2, img2title, img3, listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail,
						trafin, trafout, sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around,
						etc, startDate, endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo,
						category, visi);
				list2.add(itemVO);
			}

			endPage = (int) (Math.ceil(page / (double) 10) * 10);
			startPage = (endPage - 10) + 1;
			tempEnd = (int) (Math.ceil(totalCount / (double) 10));
			if (endPage > tempEnd) {
				endPage = tempEnd;
			}
			if (startPage == 1) {
				prev = 1;
			} else {
				prev = startPage - 1;
			}
			if (endPage * 10 >= totalCount) {
				next = page;
			} else {
				next = endPage + 1;
			}
			model.addAttribute("startPage", startPage);
			model.addAttribute("endPage", endPage);
			model.addAttribute("prev", prev);
			model.addAttribute("next", next);
			model.addAttribute("list", list2);
			model.addAttribute("cid", cid);
			log.info("[.....  admincheckGET if  .....]");
			return "admin/adminitemcheck";
		} else {
			log.info("[..... item controller admincheckGET else  .....]");
			return "redirect:/home";
		}
	}

	// admincheck 에서 관리자가 인증 상태를 변경하고 변경사항이 DB 에 update
	@RequestMapping(value = "/admincheck", method = RequestMethod.POST)
	public String admincheckPOST(SemiItemVO vo, Model model, HttpSession session) {
		String id = (String) session.getAttribute("userid");
		model.addAttribute("userid", id);
		ItemVO itemvo = new ItemVO();
	
		if(	vo.getOpt().equals("additem")){
			itemvo.setVisible(1);
		}
	      int cid = vo.getCid();
	      switch (cid) {
	      case 1:// r         
	         itemvo.setRitem_no(vo.getNo());
	         itemvo.setAddr(vo.getAddr());
	         itemvo.setCid(vo.getCid());
	         itemvo.setRname(vo.getName());
	         itemvo.setContents(vo.getContents());
	         itemvo.setTel(vo.getTel());
	         itemvo.setLatitude(vo.getLatitude());
	         itemvo.setLongtitude(vo.getLongtitude());
	         itemvo.setStartDate(vo.getStartDate());
	         itemvo.setEndDate(vo.getEndDate());
	         itemvo.setReservation(vo.getReservation());
	         itemvo.setExpe(vo.getExpe());
	         itemvo.setSellItems(vo.getSellItems());
	         itemvo.setM_and_p(vo.getM_and_p());
	         itemvo.setDisest(vo.getDisest());
	         itemvo.setTime(vo.getTime());
	         itemvo.setHoliday(vo.getHoliday());
	         itemvo.setCredit(vo.getCredit());
	         itemvo.setHomepage(vo.getHomepage());
	         itemvo.setTrafin(vo.getTrafin());
	         itemvo.setTrafout(vo.getTrafout());
	         itemvo.setParking(vo.getParking());
	         itemvo.setEtc(vo.getEtc());
	         break;
	      case 2:// h
	    	  itemvo.setHitem_no(vo.getNo());
		         itemvo.setAddr(vo.getAddr());
		         itemvo.setCid(vo.getCid());
		         itemvo.setHname(vo.getName());
		         itemvo.setContents(vo.getContents());
		         itemvo.setTel(vo.getTel());
		         itemvo.setLatitude(vo.getLatitude());
		         itemvo.setLongtitude(vo.getLongtitude());
		         itemvo.setStartDate(vo.getStartDate());
		         itemvo.setEndDate(vo.getEndDate());
		         itemvo.setReservation(vo.getReservation());
		         itemvo.setExpe(vo.getExpe());
		         itemvo.setSellItems(vo.getSellItems());
		         itemvo.setM_and_p(vo.getM_and_p());
		         itemvo.setDisest(vo.getDisest());
		         itemvo.setTime(vo.getTime());
		         itemvo.setHoliday(vo.getHoliday());
		         itemvo.setCredit(vo.getCredit());
		         itemvo.setHomepage(vo.getHomepage());
		         itemvo.setTrafin(vo.getTrafin());
		         itemvo.setTrafout(vo.getTrafout());
		         itemvo.setParking(vo.getParking());
		         itemvo.setEtc(vo.getEtc());
	         break;
	      case 3:// v
	    	  itemvo.setVitem_no(vo.getNo());
		         itemvo.setAddr(vo.getAddr());
		         itemvo.setCid(vo.getCid());
		         itemvo.setVname(vo.getName());
		         itemvo.setContents(vo.getContents());
		         itemvo.setTel(vo.getTel());
		         itemvo.setLatitude(vo.getLatitude());
		         itemvo.setLongtitude(vo.getLongtitude());
		         itemvo.setStartDate(vo.getStartDate());
		         itemvo.setEndDate(vo.getEndDate());
		         itemvo.setReservation(vo.getReservation());
		         itemvo.setExpe(vo.getExpe());
		         itemvo.setSellItems(vo.getSellItems());
		         itemvo.setM_and_p(vo.getM_and_p());
		         itemvo.setDisest(vo.getDisest());
		         itemvo.setTime(vo.getTime());
		         itemvo.setHoliday(vo.getHoliday());
		         itemvo.setCredit(vo.getCredit());
		         itemvo.setHomepage(vo.getHomepage());
		         itemvo.setTrafin(vo.getTrafin());
		         itemvo.setTrafout(vo.getTrafout());
		         itemvo.setParking(vo.getParking());
		         itemvo.setEtc(vo.getEtc());
	         break;
	      case 4:// c
	    	  itemvo.setCitem_no(vo.getNo());
		         itemvo.setAddr(vo.getAddr());
		         itemvo.setCid(vo.getCid());
		         itemvo.setCname(vo.getName());
		         itemvo.setContents(vo.getContents());
		         itemvo.setTel(vo.getTel());
		         itemvo.setLatitude(vo.getLatitude());
		         itemvo.setLongtitude(vo.getLongtitude());
		         itemvo.setStartDate(vo.getStartDate());
		         itemvo.setEndDate(vo.getEndDate());
		         itemvo.setReservation(vo.getReservation());
		         itemvo.setExpe(vo.getExpe());
		         itemvo.setSellItems(vo.getSellItems());
		         itemvo.setM_and_p(vo.getM_and_p());
		         itemvo.setDisest(vo.getDisest());
		         itemvo.setTime(vo.getTime());
		         itemvo.setHoliday(vo.getHoliday());
		         itemvo.setCredit(vo.getCredit());
		         itemvo.setHomepage(vo.getHomepage());
		         itemvo.setTrafin(vo.getTrafin());
		         itemvo.setTrafout(vo.getTrafout());
		         itemvo.setParking(vo.getParking());
		         itemvo.setEtc(vo.getEtc());
	         break;
	      case 5:// s
	    	  itemvo.setSitem_no(vo.getNo());
		         itemvo.setAddr(vo.getAddr());
		         itemvo.setCid(vo.getCid());
		         itemvo.setSname(vo.getName());
		         itemvo.setContents(vo.getContents());
		         itemvo.setTel(vo.getTel());
		         itemvo.setLatitude(vo.getLatitude());
		         itemvo.setLongtitude(vo.getLongtitude());
		         itemvo.setStartDate(vo.getStartDate());
		         itemvo.setEndDate(vo.getEndDate());
		         itemvo.setReservation(vo.getReservation());
		         itemvo.setExpe(vo.getExpe());
		         itemvo.setSellItems(vo.getSellItems());
		         itemvo.setM_and_p(vo.getM_and_p());
		         itemvo.setDisest(vo.getDisest());
		         itemvo.setTime(vo.getTime());
		         itemvo.setHoliday(vo.getHoliday());
		         itemvo.setCredit(vo.getCredit());
		         itemvo.setHomepage(vo.getHomepage());
		         itemvo.setTrafin(vo.getTrafin());
		         itemvo.setTrafout(vo.getTrafout());
		         itemvo.setParking(vo.getParking());
		         itemvo.setEtc(vo.getEtc());
	         break;
	      }
	      
	      
	      
	      
	      
	      
	      switch (cid) {
	      case 1:// r         
	         itemServie.updateRest(itemvo);
	         break;
	      case 2:// h
	         itemServie.updateHotel(itemvo);
	         break;
	      case 3:// v
	         itemServie.updateView(itemvo);
	         break;
	      case 4:// c
	         itemServie.updateCul(itemvo);
	         break;
	      case 5:// s
	         itemServie.updateShop(itemvo);
	         break;
	      }
	      log.info("[===== item controller addItemPOST  =====]");
	      return "/item/admincheck?page=1&cid=1";
	   }

	
	
	
	
	
	
	
	double latitude;
	double longtitude;
	
	@RequestMapping(value = "/namecheck", method = RequestMethod.GET)
	public String admincheckPOST(@RequestParam("name") String name, Model model, HttpSession session) {
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		
		ArrayList<ItemVO> list = new ArrayList<ItemVO>();		
		list.addAll((ArrayList<ItemVO>) itemServie.rname(name));
		list.addAll((ArrayList<ItemVO>) itemServie.hname(name));
		list.addAll((ArrayList<ItemVO>) itemServie.sname(name));
		list.addAll((ArrayList<ItemVO>) itemServie.cname(name));
		list.addAll((ArrayList<ItemVO>) itemServie.vname(name));
		int cid = list.get(0).getCid();
		switch (cid) {
		case 1:	no = list.get(0).getRitem_no(); break;
		case 2:	no = list.get(0).getHitem_no(); break;
		case 3:	no = list.get(0).getVitem_no(); break;
		case 4:	no = list.get(0).getCitem_no(); break;
		case 5:	no = list.get(0).getSitem_no(); break;
		}
		
		log.info("[..... item controller admincheckPOST  .....]");
		return "redirect:/board/detail?no="+no+"&cid="+cid+"&rpage=1";
	}
	
	
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(@RequestParam("page") int page ,@RequestParam("cate") int cate , @RequestParam("type") String type ,@RequestParam("key") String key ,Model model, HttpSession session) {
		String userid = (String) session.getAttribute("userid");
		model.addAttribute("userid", userid);
		session.setAttribute("userid", userid);
		
		ArrayList<ItemVO> list1;
		searchVO searchVO = new searchVO();		
		searchVO.setPageno(page);
		searchVO.setVisible(1);		
		searchVO.setKey(key);
		
		if(cate<6){
		searchVO.setCid(cate);		
		if(type.equals("name")){searchVO.setName(cate);}
		else if(type.equals("addr")){searchVO.setName(6);}		
		
		list1 = (ArrayList<ItemVO>) itemServie.search(searchVO);
		totalCount = list1.size();}
		
		else
		{list1=new ArrayList<ItemVO>();
			for (int i = 1; i < cate; i++) {
				searchVO.setCid(i);				
				if(type.equals("name")){searchVO.setName(i);}
				else if(type.equals("addr")){searchVO.setName(6);}
				list1.addAll(itemServie.search(searchVO));				
			}
		}		
		
		ArrayList<SemiItemVO> list2 = new ArrayList<SemiItemVO>();
		for (int i = 0; i < list1.size(); i++) {		
			switch (cate) {
			case 1:
				no = list1.get(i).getRitem_no();
				name = list1.get(i).getRname();
				break;
			case 2:
				no = list1.get(i).getHitem_no();
				name = list1.get(i).getHname();
				break;
			case 3:
				no = list1.get(i).getVitem_no();
				name = list1.get(i).getVname();
				break;
			case 4:
				no = list1.get(i).getCitem_no();
				name = list1.get(i).getCname();
				break;
			case 5:
				no = list1.get(i).getSitem_no();
				name = list1.get(i).getSname();
				break;
			}
			String addr = list1.get(i).getAddr();
			String addr2 = list1.get(i).getAddr2();
			if (addr2 != null) {
				addr = addr + addr2;
			}
			String homepage = list1.get(i).getHomepage();
			double latitude = list1.get(i).getLatitude();
			double longtitude = list1.get(i).getLongtitude();
			String time = list1.get(i).getTime();
			String parking = list1.get(i).getParking();
			String tel = list1.get(i).getTel();
			String credit = list1.get(i).getCredit();
			String t_and_m = list1.get(i).getT_and_m();
			String m_and_p = list1.get(i).getM_and_p();
			String contents = list1.get(i).getContents();
			String holiday = list1.get(i).getHoliday();
			String mainimg = list1.get(i).getMainimg();
			String mainimgdetail = list1.get(i).getMainimg();
			String img1 = list1.get(i).getImg1();
			String img1title = list1.get(i).getImg1title();
			String img2 = list1.get(i).getImg2();
			String img2title = list1.get(i).getImg2();
			String img3 = list1.get(i).getImg3();
			String listimg = list1.get(i).getListimg();
			String listimgdetail = list1.get(i).getListimgdetail();
			String ldgimg = list1.get(i).getLdgimg();
			String ldgImgdetail = list1.get(i).getLdgImgdetail();
			String courseimg = list1.get(i).getCourseimg();
			String courseimgdetail = list1.get(i).getCourseimgdetail();
			String trafin = list1.get(i).getTrafin();
			String trafout = list1.get(i).getTrafout();
			String sellItems = list1.get(i).getSellItems();
			String useGiftCerti = list1.get(i).getUseGiftCerti();
			String disest = list1.get(i).getDisest();
			String expe = list1.get(i).getExpe();
			String useest = list1.get(i).getUseest();
			String mvTrrsrtNm = list1.get(i).getMvTrrsrtNm();
			String mvActors = list1.get(i).getMvActors();
			String around = list1.get(i).getAround();
			String etc = list1.get(i).getEtc();
			String startDate = list1.get(i).getStartDate();
			String endDate = list1.get(i).getEndDate();
			String reservation = list1.get(i).getReservation();
			String institution = list1.get(i).getInstitution();
			String touCourse = list1.get(i).getTouCourse();
			String touProduct = list1.get(i).getTouProduct();
			String touFood = list1.get(i).getTouFood();
			String touMapinfo = list1.get(i).getTouMapinfo();
			String category = list1.get(i).getCategory();
			int visi = list1.get(i).getVisible();

			SemiItemVO itemVO = new SemiItemVO(no, cate, addr, homepage, latitude, longtitude, time, parking, tel,
					credit, t_and_m, m_and_p, name, contents, holiday, mainimg, mainimgdetail, img1, img1title, img2,
					img2title, img3, listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail, trafin,
					trafout, sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around, etc,
					startDate, endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo, category,
					visi);
			list2.add(itemVO);
		}

		endPage = (int) (Math.ceil(page / (double) 10) * 10);
		startPage = (endPage - 10) + 1;
		tempEnd = (int) (Math.ceil(totalCount / (double) 10));
		if (endPage > tempEnd) {
			endPage = tempEnd;
		}
		if (startPage == 1) {
			prev = 1;
		} else {
			prev = startPage - 1;
		}
		if (endPage * 10 >= totalCount) {
			next = page;
		} else {
			next = endPage + 1;
		}
		model.addAttribute("selectCategory", categoryService.listAll());
		model.addAttribute("startPage", startPage);
		model.addAttribute("endPage", endPage);
		model.addAttribute("prev", prev);
		model.addAttribute("next", next);
		model.addAttribute("list", list2);
		model.addAttribute("cid", cate);
		log.info("[..... item controller List  .....]");
		return "item/list";	
	}
	
	
	@RequestMapping(value="/topten", method = RequestMethod.GET)
	public String topten (HttpServletRequest request, HttpSession session,Model model ,int cid){
		ArrayList<ItemVO> temp = (ArrayList<ItemVO>) itemServie.topten(cid);
		ArrayList<mapSrcVO> mapsrc = new ArrayList<mapSrcVO>();
		for (int i = 0; i < temp.size(); i++) {
			mapSrcVO vo = new mapSrcVO();
			vo.setX(temp.get(i).getLatitude());
			vo.setY(temp.get(i).getLongtitude());
			vo.setCid(cid);
			switch(cid){
			case 1 :  vo.setName(temp.get(i).getRname());  break;
			case 2 :  vo.setName(temp.get(i).getHname());  break;
			case 3 :  vo.setName(temp.get(i).getVname());  break;
			case 4 :  vo.setName(temp.get(i).getCname());  break;
			case 5 :  vo.setName(temp.get(i).getSname());  break;
			}
			vo.setContent(temp.get(i).getContents());
			vo.setCategory(categoryService.cname(temp.get(i).getCid()));			
			String addr = temp.get(i).getAddr();
			String addr2 = temp.get(i).getAddr2();
			if(addr2 != null){
				addr = addr + addr2;
			}			
			vo.setAddr(addr);
			vo.setTel(temp.get(i).getTel());
			vo.setImg(temp.get(i).getMainimg());
			mapsrc.add(vo);
		}
		model.addAttribute("topten", mapsrc);
		session.setAttribute("topten", mapsrc);
		log.info("[..... item controller topten  .....]");
		return "/map/toptenForward";
	}
	
	@RequestMapping(value="/toptenlist", method = RequestMethod.GET)
	public String toptenlist (HttpServletRequest request, HttpSession session,Model model ,int cid){
		ArrayList<ItemVO> temp = (ArrayList<ItemVO>) itemServie.topten(cid);
		ArrayList<mapSrcVO> mapsrc = new ArrayList<mapSrcVO>();
		for (int i = 0; i < temp.size(); i++) {
			mapSrcVO vo = new mapSrcVO();
			vo.setX(temp.get(i).getLatitude());
			vo.setY(temp.get(i).getLongtitude());
			vo.setCid(cid);
			switch(cid){
			case 1 :  vo.setName(temp.get(i).getRname());  break;
			case 2 :  vo.setName(temp.get(i).getHname());  break;
			case 3 :  vo.setName(temp.get(i).getVname());  break;
			case 4 :  vo.setName(temp.get(i).getCname());  break;
			case 5 :  vo.setName(temp.get(i).getSname());  break;
			}
			vo.setContent(temp.get(i).getContents());
			vo.setCategory(categoryService.cname(temp.get(i).getCid()));			
			String addr = temp.get(i).getAddr();
			String addr2 = temp.get(i).getAddr2();
			if(addr2 != null){
				addr = addr + addr2;
			}			
			vo.setAddr(addr);
			vo.setTel(temp.get(i).getTel());
			vo.setImg(temp.get(i).getMainimg());
			mapsrc.add(vo);
		}
		model.addAttribute("topten", mapsrc);
		session.setAttribute("topten", mapsrc);
		log.info("[..... item controller toptenlist  .....]");
		return "/item/toptenlist";
	}
	

	
	
}