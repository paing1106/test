package bufs.bit.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import bufs.bit.domain.MemberVO;
import bufs.bit.service_Interface.I_MemberService;

@Controller
@RequestMapping(value = "/*")
public class HomeController {
	private static final Logger log = LoggerFactory.getLogger(LogController.class);

	@Inject
	private I_MemberService MemberService;
	
	@RequestMapping(value ="", method = RequestMethod.GET)
	public String home(HttpSession session, Model model){
		String userid = (String)session.getAttribute("userid");
		session.setAttribute("userid", userid);
		model.addAttribute("userid", userid);
		log.info("[..... homecontroller noname GET .....]");		
		return "home";
	}
	
	@RequestMapping(value ="/main", method = RequestMethod.GET)
	public String main(HttpSession session, Model model){
		String userid = (String)session.getAttribute("userid");
		session.setAttribute("userid", userid);
		model.addAttribute("userid", userid);
		log.info("[..... homecontroller main GET .....]");	
	
		return "home";
	}
	
	@RequestMapping( value = "" , method = RequestMethod.POST )
	public String loginCheck(MemberVO vo,Model model,HttpServletRequest request){
		String url="";				
		if(MemberService.logincheck(vo)==1){
			HttpSession session = request.getSession(true);
			session.setAttribute("userid", vo.getUserid());
			url="home";
			String id = (String) session.getAttribute("userid");
			model.addAttribute("userid",id);
		}else{
			url="home";
		}				
		log.info("[..... homecontroller noname POST .....]");
		return url;		
	}
	
	@RequestMapping( value = "/test" , method = RequestMethod.GET )
	public String test(Model model,HttpServletRequest request){
		return "test";
	}
	
}
