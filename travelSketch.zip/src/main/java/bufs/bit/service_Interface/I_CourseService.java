package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseListVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.SemiItemVO;

public interface I_CourseService {
	void add1(CourseVO vo);
	int add2 (CourseVO vo);
	
	void addlistR(CourseListVO vo);
	void addlistH(CourseListVO vo);
	void addlistV(CourseListVO vo);
	void addlistC(CourseListVO vo);
	void addlistS(CourseListVO vo);
	
	List<CourseVO> idlist(String userid);
	List<CourseVO> nolist(int course_no);
	List<CourseListJoinVO> courseListR(int course_no);
	List<CourseListJoinVO> courseListH(int course_no);
	List<CourseListJoinVO> courseListV(int course_no);
	List<CourseListJoinVO> courseListC(int course_no);
	List<CourseListJoinVO> courseListS(int course_no);
	
	void delete(int course_no);
	
	int count(int course_no);
	
	void deletOne(CourseListVO vo,int cid);
	
	CourseVO lastCourse(String userid);
	
	void addOne(int courseno,int itemno,int cid);
	
	List<SemiItemVO> listAll (int courseno);
}
