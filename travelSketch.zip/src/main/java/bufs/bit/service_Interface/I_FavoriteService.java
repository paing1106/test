package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.FavoriteVO;

public interface I_FavoriteService {
	void create(FavoriteVO vo);
	void update(FavoriteVO vo);
	void delete(FavoriteVO vo);
	FavoriteVO selectFavorite (FavoriteVO vo);
	List<FavoriteVO> listAll(FavoriteVO vo);
}
