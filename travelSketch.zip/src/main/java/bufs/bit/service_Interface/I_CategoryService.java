package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.CategoryVO;

public interface I_CategoryService {
	public void register(CategoryVO category);
	public CategoryVO read(CategoryVO category);
	public void modify(CategoryVO category);
	public void remove(CategoryVO category);
	
	public List<CategoryVO> listAll();
	String cname(int cid);
	List cid(String cname);
}
