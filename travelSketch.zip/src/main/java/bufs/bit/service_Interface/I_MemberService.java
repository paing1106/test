package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.MemberVO;

public interface I_MemberService {
	public void adduser(MemberVO vo);
	public MemberVO selectuser(MemberVO vo);
	public void update(MemberVO vo);
	public void remove(MemberVO vo);
	public List<MemberVO> listAll();
	
	int authcheck(String userid);
	int logincheck(MemberVO vo);
}
