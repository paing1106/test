package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.ItemVO;

public interface I_MapService {
	List<ItemVO> rAround (ItemVO vo);
	List<ItemVO> sAround (ItemVO vo);
	List<ItemVO> cAround (ItemVO vo);
	List<ItemVO> vAround (ItemVO vo);
	List<ItemVO> hAround (ItemVO vo);
}
