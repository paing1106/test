package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.ReplyVO;

public interface I_BoardService {
	void insertCulReply(ReplyVO vo);
	void insertViewReply(ReplyVO vo);
	void insertRestReply(ReplyVO vo);
	void insertShopReply(ReplyVO vo);
	void insertHotelReply(ReplyVO vo);
	
	void addReply1(ReplyVO vo);
	int addReply2(ReplyVO vo);
	void addReply3(ReplyVO vo);
	List<ReplyVO> culReply (ReplyVO vo);
	List<ReplyVO> viewReply (ReplyVO vo);
	List<ReplyVO> restReply (ReplyVO vo);
	List<ReplyVO> shopReply (ReplyVO vo);
	List<ReplyVO> hotelReply (ReplyVO vo);
	
	int culCount(ReplyVO vo);
	int viewCount(ReplyVO vo);
	int restCount(ReplyVO vo);
	int shopCount(ReplyVO vo);
	int hotelCount(ReplyVO vo);
	
	List<ReplyVO> ItemReply(ReplyVO vo);
}
