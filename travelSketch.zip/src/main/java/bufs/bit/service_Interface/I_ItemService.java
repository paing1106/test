package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.ItemVO;
import bufs.bit.domain.SemiItemVO;
import bufs.bit.domain.pageVO;
import bufs.bit.domain.searchVO;
import bufs.bit.domain.visibleVO;

public interface I_ItemService {
	List<ItemVO> ShopList(pageVO vo);
	List<ItemVO> RestList(pageVO vo);
	List<ItemVO> ViewList(pageVO vo);
	List<ItemVO> CulList(pageVO vo);
	List<ItemVO> HotelList(pageVO vo);
	
	List<ItemVO> ShopDetail(ItemVO vo);
	List<ItemVO> RestDetail(ItemVO vo);
	List<ItemVO> ViewDetail(ItemVO vo);
	List<ItemVO> CulDetail(ItemVO vo);
	List<ItemVO> HotelDetail(ItemVO vo);
	
	int ShopCount(int visible);
	int RestCount(int visible);
	int ViewCount(int visible);
	int CulCount(int visible);
	int HotelCount(int visible);
	
	void addShop(ItemVO vo);
	void addRest(ItemVO vo);
	void addView(ItemVO vo);
	void addCul(ItemVO vo);
	void addHotel(ItemVO vo);
	
	void updateShop(ItemVO vo);
	void updateRest(ItemVO vo);
	void updateView(ItemVO vo);
	void updateCul(ItemVO vo);
	void updateHotel(ItemVO vo);

	List<visibleVO> visible();
	
	String checkVisibleShop(int no);
	String checkVisibleRest(int no);
	String checkVisibleView(int no);
	String checkVisibleCul(int no);
	String checkVisibleHotel(int no);
	
	List<ItemVO> sname(String sname);
	List<ItemVO> rname(String rname);
	List<ItemVO> vname(String vname);
	List<ItemVO> cname(String cname);
	List<ItemVO> hname(String hname);
	
	List<ItemVO> search(searchVO vo);
	
	List<ItemVO> Around (SemiItemVO vo,int type);
	
	List<ItemVO> topten (int cid);
	
	List<ItemVO> recommend (int courseno, String userid);
	
}
