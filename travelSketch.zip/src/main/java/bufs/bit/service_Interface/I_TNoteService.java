package bufs.bit.service_Interface;

import java.util.List;

import bufs.bit.domain.NoteReplyVO;
import bufs.bit.domain.T_NoteVO;

public interface I_TNoteService {
	void add(T_NoteVO vo) throws Exception;
	List<T_NoteVO> NoteList(int pageno);
	int pageCount();
	T_NoteVO NoteDetail(int note_no);
	void updateNote (T_NoteVO vo);
	void delNote(int note_no);
	
	void NoteReply(NoteReplyVO vo);
	List<NoteReplyVO> NoteReplyList(int note_no);
	void DelNoteReply(int nrepyno);
	int replyCount(int noteno);
	
	List<String> getAttach(int note_no) throws Exception;
}
