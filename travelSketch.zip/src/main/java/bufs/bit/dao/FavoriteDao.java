package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_FavoriteDao;
import bufs.bit.domain.FavoriteVO;

@Repository
public class FavoriteDao implements I_FavoriteDao{

	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.FavoriteMapper.";
	
	@Override
	public void create(FavoriteVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"create", vo);
	}

	@Override
	public void update(FavoriteVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"update", vo);
	}

	@Override
	public void delete(FavoriteVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delete", vo);
	}

	@Override
	public FavoriteVO selectFavorite(FavoriteVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"select", vo);
	}

	@Override
	public List<FavoriteVO> listAll(FavoriteVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"listAll", vo);
	}

}
