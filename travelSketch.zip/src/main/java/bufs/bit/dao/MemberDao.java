package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_MemberDao;
import bufs.bit.domain.MemberVO;

@Repository
public class MemberDao implements I_MemberDao{
	
	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.MemberMapper.";
	
	@Override
	public void adduser(MemberVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"adduser", vo);
	}

	@Override
	public MemberVO selectuser(MemberVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"selectuser", vo);
	}

	@Override
	public void Update(MemberVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"update", vo);
	}

	@Override
	public void Delete(MemberVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"Delete", vo);
	}

	@Override
	public List<MemberVO> listAll() {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"ListAll");
	}
	
	@Override
	public int authcheck(String userid) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"authcheck", userid);	
	}

	
	@Override
	public int logincheck(MemberVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"logincheck",vo);
	}
}
