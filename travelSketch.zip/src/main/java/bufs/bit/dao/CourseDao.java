package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_CourseDao;
import bufs.bit.domain.CourseListJoinVO;
import bufs.bit.domain.CourseListVO;
import bufs.bit.domain.CourseVO;
import bufs.bit.domain.T_NoteVO;


@Repository
public class CourseDao implements I_CourseDao {

	@Inject
	private SqlSession session;
	final String NAMESPACE = "bufs.bit.mapper.CourseMapper.";
	
	@Override
	public void add1(CourseVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"add1",vo);
	}

	@Override
	public int add2(CourseVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"add2",vo);
	}

	@Override
	public void addlistR(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addlistr",vo);
	}
	@Override
	public void addlistH(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addlisth",vo);
	}
	@Override
	public void addlistV(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addlistv",vo);
	}
	@Override
	public void addlistC(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addlistc",vo);
	}
	@Override
	public void addlistS(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addlists",vo);
	}

	@Override
	public List<CourseVO> idlist(String userid) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"idlist", userid);
	}
	@Override
	public List<CourseVO> nolist(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"nolist", course_no);
	}


	@Override
	public void delete1(int course_no) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delete1", course_no);
	}

	@Override
	public void delete2(int course_no) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delete2", course_no);
	}

	@Override
	public int count(int course_no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"count", course_no);
	}

	
	
	
	@Override
	public List<CourseListJoinVO> courseListR(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"courseListR",course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListH(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"courseListH",course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListV(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"courseListV",course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListC(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"courseListC",course_no);
	}

	@Override
	public List<CourseListJoinVO> courseListS(int course_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"courseListS",course_no);
	}

	@Override
	public void deletOne(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"deletOne",vo);
	}

	@Override
	public CourseVO lastCourse(String userid) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"lastCourse",userid);
	}

	@Override
	public void delRest(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delRest",vo);
	}

	@Override
	public void delHotel(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delHotel",vo);
	}

	@Override
	public void delView(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delView",vo);
	}

	@Override
	public void delCulture(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delCulture",vo);
	}

	@Override
	public void delShop(CourseListVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delShop",vo);
	}




	
}
