package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_TNoteDao;
import bufs.bit.domain.NoteReplyVO;
import bufs.bit.domain.T_NoteVO;
import bufs.bit.domain.fileVO;
import bufs.bit.domain.pageVO;

@Repository
public class TNoteDao implements I_TNoteDao {
	
	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.TravelNoteMapper.";
	
	@Override
	public void add(T_NoteVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"add",vo);	
	}

	@Override
	public List<T_NoteVO> NoteList(int pageno) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"listAll",pageno);
	}
	
	@Override
	public int pageCount() {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"count");
	}

	@Override
	public T_NoteVO NoteDetail(int note_no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"detail",note_no);
	}

	@Override
	public void updateNote(T_NoteVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"update",vo);
	}

	@Override
	public void delNote(int note_no) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"remove",note_no);
	}

	@Override
	public void NoteReply(NoteReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"reply",vo);
	}

	@Override
	public List<NoteReplyVO> NoteReplyList(int note_no) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"readreply",note_no);
	}

	@Override
	public void DelNoteReply(int nrepyno) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delreply",nrepyno);
	}

	@Override
	public int replyCount(int noteno) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"replycount", noteno);
	}

	@Override
	public void addAttach(fileVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addAttach",vo);
	}

	@Override
	public List<String> getAttach(int note_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"getAttach",note_no);
	}

	@Override
	public Integer lastNo() {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"lastNo");
	}

}
