package bufs.bit.dao;


import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_BoardDao;
import bufs.bit.domain.ReplyVO;

@Repository
public class BoardDAO implements I_BoardDao{

	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.BoardMapper.";
	@Override
	public void addReply1(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addreply1",vo);
	}
	@Override
	public int addReply2(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"addreply2",vo);
	}
	@Override
	public void addReply3(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"addreply3",vo);
	}
	@Override
	public List<ReplyVO> culReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"culReply",vo);		
	}
	@Override
	public List<ReplyVO> viewReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"viewReply",vo);
	}
	@Override
	public List<ReplyVO> restReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"restReply",vo);
	}
	@Override
	public List<ReplyVO> shopReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"shopReply",vo);
	}
	@Override
	public List<ReplyVO> hotelReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"hotelReply",vo);
	}
	@Override
	public void insertCulReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"insertCultureReply",vo);
	}
	@Override
	public void insertViewReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"insertViewReply",vo);
	}
	@Override
	public void insertRestReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"insertRestReply",vo);
	}
	@Override
	public void insertShopReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"insertShopReply",vo);
	}
	@Override
	public void insertHotelReply(ReplyVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"insertHotelReply",vo);
	}
	@Override
	public int culCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"cultureCount",vo);
	}
	@Override
	public int viewCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"viewCount",vo);
	}
	@Override
	public int restCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"restCount",vo);
	}
	@Override
	public int shopCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"shopCount",vo);
	}
	@Override
	public int hotelCount(ReplyVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"hotelCount",vo);
	}
	
	@Override
	public List<ReplyVO> ItemReply(ReplyVO vo) {
		// TODO Auto-generated method stub		
		return session.selectList(NAMESPACE+"ItemReply",vo);
	}
	
	
	
	
}
