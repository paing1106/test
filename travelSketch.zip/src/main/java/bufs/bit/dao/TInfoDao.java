package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_TravelInfo;
import bufs.bit.domain.T_InfoVO;

@Repository
public class TInfoDao implements I_TravelInfo {
	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.TravelInfoMapper.";
	@Override
	public void create(T_InfoVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"create", vo);
	}

	@Override
	public void update(T_InfoVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"update", vo);
	}

	@Override
	public void delete(T_InfoVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"delete", vo);
	}

	@Override
	public T_InfoVO selectTravelInfo_user(T_InfoVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"listUser", vo);
	}

	@Override
	public List<T_InfoVO> listAll(T_InfoVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"listAll", vo);
	}

	@Override
	public T_InfoVO selectOne(String userid) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"lastone", userid);
	}

		
}
