package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_ItemDao;
import bufs.bit.domain.AroundVO;
import bufs.bit.domain.ItemVO;
import bufs.bit.domain.pageVO;
import bufs.bit.domain.searchVO;
import bufs.bit.domain.topVO;
import bufs.bit.domain.visibleVO;

@Repository
public class ItemDao implements I_ItemDao {
	
	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.ItemMapper.";
	
	
	//리스트
	@Override
	public List<ItemVO> ShopList(pageVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"shoplist",vo);
	}
	@Override
	public List<ItemVO> RestList(pageVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"restlist",vo);
	}
	@Override
	public List<ItemVO> ViewList(pageVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"viewlist",vo);
	}
	@Override
	public List<ItemVO> CulList(pageVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"cullist",vo);
	}
	@Override
	public List<ItemVO> HotelList(pageVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"hotellist",vo);
	}
	
	
	//디테일
	@Override
	public List<ItemVO> ShopDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"shopdetail",vo);
	}
	@Override
	public List<ItemVO> RestDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"restdetail",vo);
	}
	@Override
	public List<ItemVO> ViewDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"viewdetail",vo);
	}
	@Override
	public List<ItemVO> CulDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"culdetail",vo);
	}
	@Override
	public List<ItemVO> HotelDetail(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"hoteldetail",vo);
	}
	
	
	//카운트
	@Override
	public int ShopCount(int visible) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"shopcount",visible);
	}
	@Override
	public int RestCount(int visible) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"restcount",visible);
	}
	@Override
	public int ViewCount(int visible) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"viewcount",visible);
	}
	@Override
	public int CulCount(int visible) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"culcount",visible);
	}
	@Override
	public int HotelCount(int visible) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"hotelcount",visible);
	}
	
	
	
	@Override
	public void addShop(ItemVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addshop",vo);	
	}
	@Override
	public void addRest(ItemVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addrest",vo);
	}
	@Override
	public void addView(ItemVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addview",vo);
	}
	@Override
	public void addCul(ItemVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addcul",vo);
	}
	@Override
	public void addHotel(ItemVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"addhotel",vo);
	}
	
	
	
	
	@Override
	public void updateShop(ItemVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"updateshop",vo);
	}
	@Override
	public void updateRest(ItemVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"updaterest",vo);
	}
	@Override
	public void updateView(ItemVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"updateview",vo);
	}
	@Override
	public void updateCul(ItemVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"updatecul",vo);
	}
	@Override
	public void updateHotel(ItemVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"updatehotel",vo);
	}

	@Override
	public String checkVisibleShop(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"checkshop",no);
	}
	@Override
	public String checkVisibleRest(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"checkrest",no);
	}
	@Override
	public String checkVisibleView(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"checkview",no);
	}
	@Override
	public String checkVisibleCul(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"checkcul",no);
	}
	@Override
	public String checkVisibleHotel(int no) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"checkhotel",no);
	}
	
	@Override
	public List<visibleVO> visible() {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"visible");
	}
	@Override
	public List<ItemVO> sname(String sname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"sname",sname);
	}
	@Override
	public List<ItemVO> rname(String rname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"rname",rname);
	}
	@Override
	public List<ItemVO> vname(String vname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"vname",vname);
	}
	@Override
	public List<ItemVO> cname(String cname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"cname",cname);
	}
	@Override
	public List<ItemVO> hname(String hname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"hname",hname);
	}
	@Override
	public List<ItemVO> search(searchVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"search",vo);
	}
	@Override
	public List<ItemVO> Around(AroundVO vo,int type) {
		// TODO Auto-generated method stub
		vo.setType(type);
		return session.selectList(NAMESPACE+"Around",vo);
	}
	@Override
	public List<ItemVO> topten(topVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"topten",vo);
	}
	@Override
	public List<ItemVO> recommend(AroundVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"recommend",vo);
	}
	
	


}
