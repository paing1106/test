package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_MapDao;
import bufs.bit.domain.ItemVO;
@Repository
public class MapDao implements I_MapDao {
	
	@Inject
	private SqlSession session;
	final String NAMESPACE = "bufs.bit.mapper.MapMapper."; 
	
	@Override
	public List<ItemVO> rAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"raround",vo);
	}

	@Override
	public List<ItemVO> sAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"saround",vo);
	}

	@Override
	public List<ItemVO> cAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"caround",vo);
	}

	@Override
	public List<ItemVO> vAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"varound",vo);
	}

	@Override
	public List<ItemVO> hAround(ItemVO vo) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"haround",vo);
	}

}
