package bufs.bit.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import bufs.bit.dao_Interface.I_CategoryDao;
import bufs.bit.domain.CategoryVO;

@Repository
public class CategoryDao implements I_CategoryDao{

	@Inject
	private SqlSession session;
	private static final String NAMESPACE = "bufs.bit.mapper.CategoryMapper.";
	
	@Override
	public void Create(CategoryVO vo) {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+"Create", vo);
	}

	@Override
	public CategoryVO Read(CategoryVO vo) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"Read", vo);
	}

	@Override
	public void Update(CategoryVO vo) {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+"Update", vo);
	}

	@Override
	public void Delete(CategoryVO vo) {
		// TODO Auto-generated method stub
		session.delete(NAMESPACE+"Delete", vo);
	}

	@Override
	public List<CategoryVO> listAll() {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"ListAll");
	}

	@Override
	public String cname(int cid) {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+"cname",cid);
	}

	@Override
	public List cid(String cname) {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+"cid",cname);
	}
		
}
