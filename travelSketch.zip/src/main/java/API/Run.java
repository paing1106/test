package API;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Run {
	static ArrayList<String> dataSid = new ArrayList<String>();

	public static void main(String argv[]) {
		try{
			B b = new B();
			C1 c1 = new C1();
			C2 c2 = new C2();
			C3 c3 = new C3();
			C4 c4 = new C4();
			C5 c5 = new C5();
			C6 c6 = new C6();
			C7 c7 = new C7();
			C8 c8 = new C8();
			C9 c9 = new C9();
			C10 c10 = new C10();
			D d = new D();
			D2 d2 = new D2();
			D3 d3 = new D3();
			D4 d4 = new D4();
			D5 d5 = new D5();			
			E e = new E();
			G g = new G();
			H_1 h1 = new H_1();		
			H_2 h2 = new H_2();		
			H_3 h3 = new H_3();		
			H_4 h4 = new H_4();
			H_5 h5 = new H_5();
			H_6 h6 = new H_6();	
			H_7 h7 = new H_7();
			H_8 h8 = new H_8();

			Xml_parser parser = new Xml_parser();

			String ServiceKey = "=UacjSK4evQPG0r2wiHPEHdsmKQumjLqjLqTRmWQvOD%2Fk%2BLEOhREsaWIDYYMhXOF5Qhq80ZnNEwegsacwJBoByg%3D%3D";
			//String ServiceKey = "=FUbSMEYt8oDlYuoAHZs89VQZIkh7T3JMUrLevnQWRJUbhgzJNcpIF97JLk4sKfzqqe%2B3bpaKycj4vQmvqBgtyw%3D%3D";
			//String ServiceKey = "=MkWuyTiVG6acg%2FQ56VjWILiuekDwlj%2BIoUQXfdNBqqquYJnOXMQnXEA5PuYKtrs8OLFVYDVa9ae0gJFJPpoPCQ%3D%3D";
			
			//rest
			c2.list(ServiceKey); //맛집 (ok)
			c2.detail(ServiceKey);
			d4.list(ServiceKey);
			e.list(ServiceKey); //(ok) 부산 착한 가격 업소
			e.detail(ServiceKey);

			//view
			b.list(ServiceKey); //전통시장
			b.detail(ServiceKey);
			c5.list(ServiceKey); //테마별 관광명소 (ok)
			c5.detail(ServiceKey);
			c6.list(ServiceKey);  //도보여행 (ok)
			c6.detail(ServiceKey);
			c7.list(ServiceKey); //체험여행 (ok)
			c7.detail(ServiceKey);
			c8.list(ServiceKey);  //테마여행  (ok)
			c8.detail(ServiceKey);
			d2.list(ServiceKey);			
			c9.list(ServiceKey);  //명품관광 (?)
			c9.detail(ServiceKey);

			//hotel
			c1.list(ServiceKey); //숙박 (ok)
			c1.detail(ServiceKey);
			d5.list(ServiceKey);	

			//shop
			c4.list(ServiceKey); //테마별 쇼핑명소(ok)
			c4.detail(ServiceKey);
			d3.list(ServiceKey);

			//cul
			c3.list(ServiceKey); //스포츠/레저 (ok)
			c3.detail(ServiceKey);
			d.list(ServiceKey); //(ok) 
			g.list(ServiceKey); //(ok) 부산 광역시 문화 축제 정보
			g.detail(ServiceKey);	
			h1.h_1(ServiceKey);	//(ok)	
			h2.list(ServiceKey); //?
			h2.detail(ServiceKey);
			h3.list(ServiceKey); //?
			h3.detail(ServiceKey);
			h4.list(ServiceKey); //?
			h4.detail(ServiceKey);
			h5.list(ServiceKey); //?
			h5.detail(ServiceKey);
			h6.list(ServiceKey); //?
			h6.detail(ServiceKey);
			h7.list(ServiceKey); //?
			h7.detail(ServiceKey);
			h8.list(ServiceKey); //?
			h8.detail(ServiceKey);

			File rest = new File("c:/rest.xml");		
			FileOutputStream output = new FileOutputStream("c:/restAPI.xml");
			PrintWriter print = new PrintWriter(output);
			print.write(parser.parser(rest));

			File hotel = new File("c:/hotel.xml");		
			FileOutputStream output2 = new FileOutputStream("c:/hotelAPI.xml");
			PrintWriter print2 = new PrintWriter(output2);
			print2.write(parser.parser(hotel));

			File view = new File("c:/view.xml");		
			FileOutputStream output3 = new FileOutputStream("c:/viewAPI.xml");
			PrintWriter print3 = new PrintWriter(output3);
			print3.write(parser.parser(view));

			File cul = new File("c:/cul.xml");		
			FileOutputStream output4 = new FileOutputStream("c:/culAPI.xml");
			PrintWriter print4 = new PrintWriter(output4);
			print4.write(parser.parser(cul));

			File shop = new File("c:/shop.xml");		
			FileOutputStream output5 = new FileOutputStream("c:/shopAPI.xml");
			PrintWriter print5 = new PrintWriter(output5);
			print5.write(parser.parser(shop));		


			print.close();
			output.close();
			print2.close();
			output2.close();
			print3.close();
			output3.close();
			print4.close();
			output4.close();
			print5.close();
			output5.close();


		}catch(Exception e){e.printStackTrace();}
	}

}