package API;


import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;

public class D4{
	public void list (String ServiceKey){
		try{
			ArrayList<String> list = new ArrayList<String>(); 

			
			//문화체험 cul
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/tourresort/getAquaticLeportsInfo"); //D-해운대 해양 스포츠 정보 조회
			
			//view
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/tourresort/getTrrsrtInfo");//D-관광지 정보 조회
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/tourresort/getTrrsrtMovieInfo"); //D-영화속 해운대 명소 정보 조회
//			list.add("http://openapi.yeongdo.go.kr:8081/openapi-data/service/rest/tour/list");//관광지 목록 조회
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/park/getParkList");//공원 목록 조회
			
			//shop
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/shoppingmall/getShoppingMallList"); // 쇼핑상점 목록 조회
			
			//rest
			list.add("http://openapi.yeongdo.go.kr:8081/openapi-data/service/rest/restaurant/list"); //음식점 목록 조회
			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/goodpricestore/getGoodPriceStoreList"); //J - 착한가격업소 목록 조회
			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/goodpricestore/getGoodPriceStoreDetailInfo"); //J - 착한가격업소 상세정보 조회
			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/rstrt/getRstrtList"); //모범음식점 목록 조회
			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/famousrstrt/getFamousRstrtList");//맛집거리 목록 조회
			
			//hotel
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/stayng/getForeignStayingList");//외국인 도시민박업 목록 조회
//			list.add("http://openapi.haeundae.go.kr/openapi-data/service/rest/stayng/getStayingList");//숙박지정보 목록 조회
//			list.add("http://openapi.yeongdo.go.kr:8081/openapi-data/service/rest/lodging/list");

			for (String string : list) {
				//String ServiceKey = "=UacjSK4evQPG0r2wiHPEHdsmKQumjLqjLqTRmWQvOD%2Fk%2BLEOhREsaWIDYYMhXOF5Qhq80ZnNEwegsacwJBoByg%3D%3D";    
				StringBuilder urlBuilder = new StringBuilder(string); /*URL*/
				urlBuilder.append("?" + URLEncoder.encode("ServiceKey","UTF-8") +ServiceKey); /*Service Key*/
				urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("999", "UTF-8")); /*�˻��Ǽ�*/
				urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*������ ��ȣ*/
				URL url = new URL(urlBuilder.toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();
				conn.setRequestMethod("GET");
				conn.setRequestProperty("Content-type", "application/json");
				System.out.println("Response code: " + conn.getResponseCode());
				BufferedReader rd;
				if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
					rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				} else {
					rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
				}
				StringBuilder sb = new StringBuilder();
				String line;
				while ((line = rd.readLine()) != null) {
					sb.append(line);
				}
				rd.close();
				conn.disconnect();

				FileOutputStream output = new FileOutputStream("c:/rest.xml", true);
				PrintWriter print = new PrintWriter(output);
				print.println(sb);

				print.close();
				output.close();
			}		
		}catch(Exception e){e.printStackTrace();}
	}
}