package API;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class Xml_parser {

   //public static void main(String[] args) throws Exception {
   public String parser(File file) throws IOException{

      FileInputStream input = new FileInputStream(file);
      BufferedReader br = new BufferedReader(new FileReader(file));

      StringBuilder builder = new StringBuilder();
      String str ;
      while((str=br.readLine()) != null){         
         builder.append(str);         
      }

      String stt = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?> <response>";

      String s = builder.toString();

      s = s.replaceAll("<response><header><resultCode>00</resultCode><resultMsg>NORMAL SERVICE.</resultMsg></header>", ""); // 필요없는 태그 제거
      s = s.replaceAll("lt;!--startfragment-- style=LINE-HEIGHT: 130%; LAYOUT-GRID-MODE: char class=바탕글 lt;span style=FONT-FAMILY: HCI Poppy; mso-fareast-font-family: 휴먼명조; mso-hansi-font-family: HCI Poppy lang=EN-US ", "").replaceAll("lt;/span lt;span style=FONT-FAMILY: 휴먼명조; FONT-WEIGHT: bold; mso-hansi-font-family: HCI Poppy; mso-ascii-font-family: HCI Poppy", "").replaceAll("lt;/span", "");
      s = s.replaceAll("lt;/span lt;span style=FONT-FAMILY: HCI Poppy; mso-fareast-font-family: 휴먼명조; mso-hansi-font-family: HCI Poppy lang=EN-US", "").replaceAll("lt;/span lt;span style=FONT-FAMILY: 휴먼명조; mso-hansi-font-family: HCI Poppy; mso-ascii-font-family: HCI Poppy", "").replaceAll("lt;/span lt;span style=FONT-FAMILY: HCI Poppy;fareast-font-family: 휴먼명조; mso-hansi-font-family: HCI Poppy lang=EN-US", "");      
      s = s.replaceAll("&amp;", " ").replaceAll("sim;", " ").replaceAll("harr;", " ").replaceAll("&rArr;", " ").replaceAll("&nbsp;", " ").replaceAll("&quot;", "").replace("&", "").replaceAll("FONT-WEIGHT: bold;",""); //html 태그 제거
      s = s.replaceAll("nbsp;", " ").replaceAll("&amp;", " ").replaceAll("gt;", " ").replaceAll("rarr;", " ").replaceAll("&#xD;", " ").replaceAll("#xD;", "").replaceAll("lt;/br", "").replaceAll("lt;/p", "").replaceAll("lt;table", "").replaceAll("lt;caption", "").replaceAll("lt;tr", "").replaceAll("lt;th", "").replaceAll("lt;/tr", "").replaceAll("lt;/th", "").replaceAll("lt;/p", ""); // html 태그 제거
      s = s.replaceAll("&lt;br/&", "").replaceAll("&lt;/dd&", "").replaceAll("&lt;/dl&", "").replaceAll("&lt;/div&", "").replaceAll("&lt;div&", "").replaceAll("&lt;dl&", "").replaceAll("&lt;dt&", "").replaceAll("lt;colgroup", "").replaceAll("lt;col", "").replaceAll("class=w_100", "").replaceAll("lt;tbody", "").replaceAll("scope=row", "").replaceAll("colSpan=3", "").replaceAll("scope=row", "").replaceAll("lt;tbody", "").replaceAll("class=dtable", "");
      s = s.replaceAll(" gt","").replaceAll("ltbr", "").replaceAll("lt;div", "").replaceAll("lt;dl", "").replaceAll("lt;dt", "").replaceAll("lt;/dt", "").replaceAll("lt;dd", "").replaceAll("lt;/dd", "").replaceAll("lt;br", "").replaceAll("lt;p", "").replaceAll(" / ", "").replaceAll("lt;/caption", "");
      s = s.replaceAll("lt;", "").replaceAll("!--startfragment--", "").replaceAll("style=LINE-HEIGHT:", "").replaceAll("130%;", "").replaceAll("LAYOUT-GRID-MODE:", "").replaceAll("char", "").replaceAll("class=바탕글", "").replaceAll("span style=FONT-FAMILY:", "").replaceAll("HCI", "").replaceAll("Poppy;", "").replaceAll("mso-fareast-font-family:", "").replaceAll("휴먼명조;", "").replaceAll("mso-hansi-font-family:", "").replaceAll("Poppy", "").replaceAll("lang=EN-US", "");
      s = s.replaceAll("mso-ascii-font-family:", "").replaceAll("style=FONT-FAMILY:", "").replaceAll("span", "").replaceAll("/dl", "").replaceAll("/div", "").replaceAll("/td", "").replaceAll("/tbody", "").replaceAll("/table", "").replaceAll("/colgroup", "");
      s = s.replaceAll("lt;/colgroup","").replaceAll("lt;/colgroup", "").replaceAll("lt;td", "").replaceAll("lt;/td", "").replaceAll("lt;/tbody", "").replaceAll("lt;/table", "");
      s = s.replace("?", "").replaceAll("<xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\">", "");
      s = s.replaceAll("</body></response><body>", "").replaceAll("</body></response><body/></response><body>", "").replaceAll("`", "");    
      s = s.replaceAll("<items>", "").replaceAll("</items>", "");
      
      //null(-) 값제거
      s = s.replaceAll(">-<", "><");
      //주소
      s = s.replaceAll("addrJibun", "addr").replaceAll("addr", "addr").replaceAll("address", "addr").replaceAll("addss1", "addr").replaceAll("resAddress", "addr").replaceAll("Host", "addr").replaceAll("place", "addr").replaceAll("host", "addr").replaceAll("mtShopAddr", "addr").replaceAll("ldgAddress", "addr").replaceAll("touLocation", "addr").replaceAll("location", "addr");
      //상세주소
      s = s.replaceAll("detail", "addr2").replaceAll("addss2", "addr2").replaceAll("area", "addr2").replaceAll("addressStr", "addr2");
      //홈페이지
      s = s.replaceAll("homepage", "homepage").replaceAll("userHomepage", "homepage").replaceAll("resHomepage", "homepage").replaceAll("ldgHomepage", "homepage").replaceAll("touHomepage", "homepage");
      //위도
      s = s.replaceAll("latitude", "latitude").replaceAll("wgsx", "latitude").replaceAll("gpsLat", "latitude").replaceAll("gpsLa", "latitude");
      //경도
      s = s.replaceAll("longtitude", "longtitude").replaceAll("wgsy", "longtitude").replaceAll("longitude", "longtitude").replaceAll("gpsLon", "longtitude").replaceAll("gpsLo", "longtitude");
      //시간
      s = s.replaceAll("openTerm", "time").replaceAll("usetime", "time").replaceAll("opentime", "time").replaceAll("resBusinesshour", "time").replaceAll("time", "time").replaceAll("useperiod", "time").replaceAll("businessTime", "time").replaceAll("touUsehour", "time");
      //주차
      s = s.replaceAll("parking", "parking").replaceAll("parkest", "parking").replaceAll("parkfree", "parking").replaceAll("Parkest", "parking").replaceAll("parkingyn", "parking").replaceAll("resPark", "parking").replaceAll("ldgPark", "parking").replaceAll("touParking", "parking");
      //연락처
      s = s.replaceAll("tel", "tel").replaceAll("guide", "tel").replaceAll("contactPlace", "tel").replaceAll("resPhone", "tel").replaceAll("telNo", "tel").replaceAll("contactPlace", "tel").replaceAll("mtShopTel", "tel").replaceAll("ldgPhone", "tel").replaceAll("touPhone", "tel").replaceAll("<tel1>", "<tel>").replaceAll("</tel1>", "").replaceAll("<tel2>", "").replaceAll("</tel2>", "").replaceAll("<tel3>", "").replaceAll("</tel3>","</tel>");
      //카드
      s = s.replaceAll("credit", "credit").replaceAll("carduse", "credit");
      //시간 및 가격
      s = s.replaceAll("USEPERIOD", "t_and_m");
      //메뉴 요금 정보 
      s = s.replaceAll("resMenuprice", "m_and_p").replaceAll("menu", "m_and_p").replaceAll("mtShopMenu", "m_and_p").replaceAll("entfree", "m_and_p").replaceAll("price", "m_and_p").replaceAll("costInfo", "m_and_p").replaceAll("ldgPay", "m_and_p").replaceAll("touFree", "m_and_p");
      //제목
      s = s.replaceAll("name", "name").replaceAll("dataTitle", "name").replaceAll("trrsrNm", "name").replaceAll("mvScene", "name").replaceAll("marketnm", "name").replaceAll("resName", "name").replaceAll("festivalName", "name").replaceAll("rstrtName", "name").replaceAll("parkName", "name").replaceAll("rstrtName", "name").replaceAll("accName", "name").replaceAll("mtShopName", "name").replaceAll("ldgName", "name").replaceAll("touName", "name").replaceAll("storeName", "name");
      //내용
      s = s.replaceAll("dataContent", "contents").replaceAll("contents", "contents").replaceAll("aqalptsIntro", "contents").replaceAll("info", "contents").replaceAll("resContent", "contents").replaceAll("restrIntroduction", "contents").replaceAll("accArea", "contents").replaceAll("ldgContent", "contents").replaceAll("touContent", "contents").replaceAll("touCopy", "contents");
      //휴일
      s = s.replaceAll("holiday", "holiday").replaceAll("Holiday", "holiday").replaceAll("restDate", "holiday");
      //메인이미지
      s = s.replaceAll("mainimgthumb", "mainimg").replaceAll("trrsrtImage", "mainimg").replaceAll("mvTrrsrNm", "mainimg").replaceAll("<resImage>", "<mainimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/restaurant/").replaceAll("</resImage>","</mainimg>").replaceAll("major", "mainimg").replaceAll("rstrtImage", "mainimg").replaceAll("accImage", "mainimg").replaceAll("<ldgImage>", "<mainimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/lodging/").replaceAll("</ldgImage>","</mainimg>").replaceAll("<touImage>", "<mainimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/tourinfo/").replaceAll("</touImage>","</mainimg>");
      //메인이미지설명
      s = s.replaceAll("ldgImagedetail", "mainimgdetail").replaceAll("touImagedetail", "mainimgdetail").replaceAll("resImagedetail", "mainimgdetail");
      //이미지 1
      s = s.replaceAll("img1thumb", "img1").replaceAll("trrsrtDetailImage", "img1").replaceAll("imgPath", "img1").replaceAll("rstrtDetailImages", "img1").replaceAll("accDetailImages", "img1");
      //이미지 1 제목
      s = s.replaceAll("imgTitle1","img1title");
      //이미지 2
      s = s.replaceAll("img2thumb", "img2").replaceAll("imgPath2", "img2");
      //이미지2 제목
      s = s.replaceAll("imgTitle2","img2title");
      //이미지3
      s = s.replaceAll("img3thumb","img3");
      //목록 이미지
      s = s.replaceAll("<ldgImage1>", "<listimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/lodging/").replaceAll("</ldgImage1>", "</listimg>").replaceAll("<touImage1>", "<listimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/tourinfo/").replaceAll("</touImage1>", "</listimg>").replaceAll("<resImage1>", "<listimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/restaurant/").replaceAll("</resImage1>", "</listimg>");
      //목록이미지 설명
      s = s.replaceAll("ldgImagedetail1","listimgdetail").replaceAll("touImagedetail1","listimgdetail").replaceAll("resImagedetail1","listimgdetail");
      //약도이미지
      s = s.replaceAll("<ldgImage5>", "<ldgimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/lodging/").replaceAll("</ldgImage5>", "</ldgimg>").replaceAll("<touImage6>", "<listimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/tourinfo/").replaceAll("</touImage6>", "</listimg>").replaceAll("<resImage5>", "<listimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/restaurant/").replaceAll("</resImage5>", "</listimg>");
      //약도설명
      s = s.replaceAll("ldgImagedetail1","ldgImgdetail").replaceAll("touImagedetail6","ldgImgdetail").replaceAll("resImagedetail5","ldgImgdetail");
      //코스이미지
      s = s.replaceAll("<touImage5>","<courseimg>http://tour.yeongdo.go.kr/include/ThumbGenerate.asp?VFilePath=/program/data/tour/tourinfo/").replaceAll("</touImage5>","</courseimg>");
      //코스이미지 설명
      s = s.replaceAll("touImagedetail5","courseimgdetail");
      //가시는길
      s = s.replaceAll("way","trafin").replaceAll("Way","trafin").replaceAll("findway","trafin").replaceAll("resMap","trafin").replaceAll("ldgMap","trafin").replaceAll("touMap","trafin");
      //교통편 in;
      s = s.replaceAll("trafin","trafin").replaceAll("Trafin","trafin").replaceAll("resTrafficinfo","trafin").replaceAll("touTrafficinfo","trafin");
      //교통편 out
      s = s.replaceAll("trafout","trafout").replaceAll("Trafout","Trafout");
      
      //detail
      //취급품목
      s = s.replaceAll("sellItems", "sellItems");
      //사용가능 상품권
      s = s.replaceAll("useGiftCerti", "useGiftCerti");
      //편의
      s = s.replaceAll("disest", "disest");
      //프로그램
      s = s.replaceAll("expe", "expe");
      //사용시설
      s = s.replaceAll("useest", "useest");
      //영화명
      s = s.replaceAll("mvTrrsrtNm", "mvTrrsrtNm");
      //영화 출연배우
      s = s.replaceAll("mvActors", "mvActors");
      //카테고리
      s = s.replaceAll("resCategory", "category").replaceAll("touCategory", "category").replaceAll("ldgCategory", "category").replaceAll("<mtPosiCode>01", "<category>송정광어골주변").replaceAll("<mtPosiCode>02", "<category>달맞이길주변").replaceAll("<mtPosiCode>03", "<category>해운대구청주변").replaceAll("<mtPosiCode>04", "<category>해운대전통시장").replaceAll("<mtPosiCode>05", "<category>해운대 구남로 주변").replaceAll("<mtPosiCode>06", "<category>영화의 전당 주변").replaceAll("<mtPosiCode>07", "<category>벡스코 주변").replaceAll("<mtPosiCode>08", "<category>벡스코 내 식당가").replaceAll("<mtPosiCode>09", "<category>백화점 내 식당가").replaceAll("mtPosiCode", "category").replaceAll("R0100", "한식").replaceAll("R0200", "양식").replaceAll("R0300", "중식").replaceAll("R0400", "일식").replaceAll("R0500", "횟집").replaceAll("R0600", "기타").replaceAll("T0100", "영도 8경").replaceAll("H0200", "추천관광지").replaceAll("C0100", "국가지정문화재").replaceAll("C0200", "시 지정 문화재").replaceAll("C0300", "시 지정 문화재 자료").replaceAll("C0400", "전통사찰").replaceAll("C0500", "기념비").replaceAll("L0100", "호텔").replaceAll("L0200", "모텔").replaceAll("L0300", "여관").replaceAll("L0400", "콘도/맨션/민박").replaceAll("L0500", "스파").replaceAll("L0600", "기타").replaceAll("clsName", "category").replaceAll("mtShopDiv", "category");
      //주변볼거리
      s = s.replaceAll("resSightseeing", "around").replaceAll("ldgSightseeing", "around").replaceAll("touSightseeing", "around");
      //기타정보
      s = s.replaceAll("resEtc", "etc").replaceAll("ldgEtc", "etc").replaceAll("touEtc", "etc").replaceAll("festivalInfo", "etc");
      //축제 시작
      s = s.replaceAll("startDate", "startDate");
      //축제 끝
      s = s.replaceAll("endDate", "endDate");
      //예약 가능 여부
      s = s.replaceAll("reservation", "reservation");
      //시설
      s = s.replaceAll("ldgInstitution", "institution").replaceAll("touInstitution", "institution");
      //등산코스
      s = s.replaceAll("touCourse","touCourse");
      //특산품
      s = s.replaceAll("touProduct", "touProduct");
      //향토음식
      s = s.replaceAll("touFood", "touFood");
      //관광지도
      s = s.replaceAll("touMapinfo", "touMapinfo");
      
      System.out.println("파싱 완료");
      
      br.close();
      input.close();
      
      return stt + s;

      


   }

}