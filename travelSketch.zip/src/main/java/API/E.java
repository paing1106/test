package API;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class E{
   static ArrayList<String> dataSid = new ArrayList<String>();

   public void detail(String ServiceKey) {
      // TODO Auto-generated method stub
      try{
         //String ServiceKey = "=UacjSK4evQPG0r2wiHPEHdsmKQumjLqjLqTRmWQvOD%2Fk%2BLEOhREsaWIDYYMhXOF5Qhq80ZnNEwegsacwJBoByg%3D%3D";
         File file = new File("c:/rest.xml");
         FileOutputStream fos = new FileOutputStream(file,true);
         PrintWriter print = new PrintWriter(fos);
        
         String durl =  "http://opendata.busan.go.kr/openapi/service/GoodPriceStoreService/getGoodPriceStoreDetail";
         for(String sid : dataSid){

            StringBuilder urlBuilder = new StringBuilder(durl); /*URL*/
            urlBuilder.append("?" + URLEncoder.encode("ServiceKey","UTF-8") +ServiceKey); /*Service Key*/
            urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("999", "UTF-8")); /*검색건수*/
            urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
            urlBuilder.append("&" + URLEncoder.encode("idx", "UTF-8") + "=" + URLEncoder.encode(sid, "UTF-8"));
            
            URL url = new URL(urlBuilder.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-type", "application/json");
            System.out.println("Response code: " + conn.getResponseCode());
            BufferedReader rd;
            if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
               rd = new BufferedReader(new InputStreamReader(conn.getInputStream())); 
            } else {
               rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            }
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = rd.readLine()) != null) {
               sb.append(line);
            }
            rd.close();
            conn.disconnect();
            //System.out.println(sb.toString());
            print.write(sb.toString());         
         }              
         print.close();
         fos.close();
        
      }catch(Exception e){e.printStackTrace();}
   }

   public void list (String ServiceKey){
      try {
         ArrayList<String> list = new ArrayList<String>();
         //목록
         list.add("http://opendata.busan.go.kr/openapi/service/GoodPriceStoreService/getGoodPriceStoreList");//부산 착한가격업소 목록 정보 조회
         
         for (String string : list) {
            //String ServiceKey = "=UacjSK4evQPG0r2wiHPEHdsmKQumjLqjLqTRmWQvOD%2Fk%2BLEOhREsaWIDYYMhXOF5Qhq80ZnNEwegsacwJBoByg%3D%3D";
            StringBuilder urlBuilder = new StringBuilder(string); /* URL */
            urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8")+ ServiceKey); 
            urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("999", "UTF-8"));
            urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
            URL url = new URL(urlBuilder.toString());
            URLConnection connection = url.openConnection();

            // File fXmlFile = new File("/Users/mkyong/staff.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(connection.getInputStream());

            // optional, but recommended
            // read this -
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("item");

            for (int temp = 0; temp < nList.getLength(); temp++) {
               Node nNode = nList.item(temp);

               if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                  Element eElement = (Element) nNode;
                  dataSid.add(eElement.getElementsByTagName("idx").item(0).getTextContent());
               }
            }                       
         } 
         for(String sid : dataSid){               
            System.out.println(sid);               
         }
      }catch (Exception e) {
         e.printStackTrace();
      } 
   }
}