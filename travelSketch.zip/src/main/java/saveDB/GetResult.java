//package saveDB;
//
//import java.io.File;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.List;
//
//import bufs.bit.domain.ItemVO;
//
//
//public class GetResult {
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		try {
//			File file = new File("c:/culAPI.xml");
//			parser xmlParser = new parser(file);
//			List<ItemVO> tmp = xmlParser.parse("item");
//
//			ConnectDB connectDB = new ConnectDB();
//			Connection conn = ConnectDB.getConnection();
//			String sql = "insert into culture (name, addr, addr2, homepage, latitude, longtitude, time, parking, tel, credit, t_and_m, m_and_p,  contents, holiday, mainimg, mainimgdetail, img1, img1title, img2, img2title, img3,	listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail, trafin, trafout, sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around, etc, startDate,	endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo, category) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
//			PreparedStatement stmt = conn.prepareStatement(sql);
//
//			for (int i = 0; i < tmp.size(); i++) {
//				stmt.setString(1, tmp.get(i).getName());
//				stmt.setString(2, tmp.get(i).getAddr());
//				stmt.setString(3, tmp.get(i).getAddr2());
//				stmt.setString(4, tmp.get(i).getHomepage());
//				stmt.setString(5, tmp.get(i).getLatitude());
//				stmt.setString(6, tmp.get(i).getLongtitude());
//				stmt.setString(7, tmp.get(i).getTime());
//				stmt.setString(8, tmp.get(i).getParking());
//				stmt.setString(9, tmp.get(i).getTel());
//				stmt.setString(10, tmp.get(i).getCredit());
//				stmt.setString(11, tmp.get(i).getT_and_m());
//				stmt.setString(12, tmp.get(i).getM_and_p());
//				stmt.setString(13, tmp.get(i).getContents());
//				stmt.setString(14, tmp.get(i).getHoliday());
//				stmt.setString(15, tmp.get(i).getMainimg());
//				stmt.setString(16, tmp.get(i).getMainimgdetail());
//				stmt.setString(17, tmp.get(i).getImg1());
//				stmt.setString(18, tmp.get(i).getImg1title());
//				stmt.setString(19, tmp.get(i).getImg2());
//				stmt.setString(20, tmp.get(i).getImg2title());
//				stmt.setString(21, tmp.get(i).getImg3());
//				stmt.setString(22, tmp.get(i).getListimg());
//				stmt.setString(23, tmp.get(i).getListimgdetail());
//				stmt.setString(24, tmp.get(i).getLdgimg());
//				stmt.setString(25, tmp.get(i).getLdgImgdetail());
//				stmt.setString(26, tmp.get(i).getCourseimg());
//				stmt.setString(27, tmp.get(i).getCourseimgdetail());
//				stmt.setString(28, tmp.get(i).getTrafin());
//				stmt.setString(29, tmp.get(i).getTrafout());
//				stmt.setString(30, tmp.get(i).getSellItems());
//				stmt.setString(31, tmp.get(i).getUseGiftCerti());
//				stmt.setString(32, tmp.get(i).getDisest());
//				stmt.setString(33, tmp.get(i).getExpe());
//				stmt.setString(34, tmp.get(i).getUseest());
//				stmt.setString(35, tmp.get(i).getMvTrrsrtNm());
//				stmt.setString(36, tmp.get(i).getMvActors());
//				stmt.setString(37, tmp.get(i).getAround());
//				stmt.setString(38, tmp.get(i).getEtc());
//				stmt.setString(39, tmp.get(i).getStartDate());
//				stmt.setString(40, tmp.get(i).getEndDate());
//				stmt.setString(41, tmp.get(i).getReservation());
//				stmt.setString(42, tmp.get(i).getInstitution());
//				stmt.setString(43, tmp.get(i).getTouCourse());
//				stmt.setString(44, tmp.get(i).getTouProduct());
//				stmt.setString(45, tmp.get(i).getTouFood());
//				stmt.setString(46, tmp.get(i).getTouMapinfo());
//				stmt.setString(47, tmp.get(i).getCategory());	
//
//				stmt.addBatch();
//				System.out.println("success to save");
//			}
//			stmt.executeBatch();
//			conn.commit();
//			System.out.println("끝");
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//}
