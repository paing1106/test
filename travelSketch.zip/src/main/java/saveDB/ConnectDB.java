package saveDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectDB {
	String URL  = "jdbc:oracle:thin:@localhost:1521:xe";
	String user = "penguin";
	String password = "11";
	static Connection conn = null;

	public ConnectDB(){
		try {
			System.out.println("try : get connection");
			Class.forName("oracle.jdbc.OracleDriver"); 
			conn = DriverManager.getConnection(URL, user, password);
			System.out.println("success !");
		} catch (SQLException e) {} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Connection getConnection(){
		return conn;
	}
} 
