package saveDB;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import bufs.bit.domain.ItemVO;
import bufs.bit.domain.ItemVO;

public class parser {
	private DocumentBuilderFactory documentBuilderFactory;
	private DocumentBuilder documentBuilder;
	private Document document;
	private NodeList nodeList;

	public parser(File file) {
		DomParser(file);
	}

	public void DomParser(File file) {

		try {
			documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilder = documentBuilderFactory.newDocumentBuilder();
			document = documentBuilder.parse(file);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<ItemVO> parse(String tagName) throws NullPointerException {

		List<ItemVO> listOfData = new ArrayList<ItemVO>();

		String addr;
		String addr2;
		String homepage;
		String latitude;
		String longtitude;
		String time;
		String parking;
		String tel;
		String credit;
		String t_and_m;
		String m_and_p;
		String name;
		String contents;
		String holiday;
		String mainimg;
		String mainimgdetail;
		String img1;
		String img1title;
		String img2;
		String img2title;
		String img3;
		String listimg;
		String listimgdetail;
		String ldgimg;
		String ldgImgdetail;
		String courseimg;
		String courseimgdetail;
		String trafin;
		String trafout;
		String sellItems;
		String useGiftCerti;
		String disest;
		String expe;
		String useest;
		String mvTrrsrtNm;
		String mvActors;
		String around;
		String etc;
		String startDate;
		String endDate;
		String reservation;
		String institution;
		String touCourse;
		String touProduct;
		String touFood;
		String touMapinfo;
		String category;

		int count = 1;

		nodeList = document.getElementsByTagName(tagName);

		for (int i = 0; i < nodeList.getLength(); i++) {

			Element element = (Element) nodeList.item(i);

			try {
				name = this.getTagValue("name", element);
				System.out.println("name" + name);
			} catch (NullPointerException e) {
				name = "";
				
			}

			try {
				addr = this.getTagValue("addr", element);
				System.out.println("addr" + addr);
			} catch (NullPointerException e) {
				addr = "";
				
			}

			try {
				addr2 = this.getTagValue("addr2", element);
				System.out.println("addr2" + addr2);
			} catch (NullPointerException e) {
				addr2 = "";
				
			}

			try {
				homepage = this.getTagValue("homepage", element);
				System.out.println("hompage" + homepage);
			} catch (NullPointerException e) {
				homepage = "";
				
			}

			try {
				latitude = this.getTagValue("latitude", element);
				System.out.println("latitude" + latitude);
			} catch (NullPointerException e) {
				latitude = "";
				
			}

			try {
				longtitude = this.getTagValue("longtitude", element);
				System.out.println("longtitude" + longtitude);
			} catch (NullPointerException e) {
				longtitude = "";
				
			}

			try {
				time = this.getTagValue("time", element);
				System.out.println("time" + time);
			} catch (NullPointerException e) {
				time = "";
				
			}
			try {
				parking = this.getTagValue("parking", element);
				System.out.println("parking" + parking);
			} catch (NullPointerException e) {
				parking = "";
				
			}
			try {
				tel = this.getTagValue("tel", element);
				System.out.println("tel" + tel);
			} catch (NullPointerException e) {
				tel = "";
				
			}
			try {
				credit = this.getTagValue("credit", element);
				System.out.println("credit" + credit);
			} catch (NullPointerException e) {
				credit = "";
				
			}
			try {
				t_and_m = this.getTagValue("t_and_m", element);
				System.out.println("t_and_m" + t_and_m);
			} catch (NullPointerException e) {
				t_and_m = "";
				
			}
			try {
				m_and_p = this.getTagValue("m_and_p", element);
				System.out.println("m_and_p" + m_and_p);
			} catch (NullPointerException e) {
				m_and_p = "";
				
			}
			try {
				contents = this.getTagValue("contents", element);
				System.out.println("contents" + contents);
			} catch (NullPointerException e) {
				contents = "";
				
			}
			try {
				holiday = this.getTagValue("holiday", element);
				System.out.println("holiday" + holiday);
			} catch (NullPointerException e) {
				holiday = "";
				
			}
			try {
				mainimg = this.getTagValue("mainimg", element);
				System.out.println("mainimg" + mainimg);
			} catch (NullPointerException e) {
				mainimg = "";
				
			}
			try {
				mainimgdetail = this.getTagValue("mainimgdetail", element);
				System.out.println("mainimgdetail" + mainimgdetail);
			} catch (NullPointerException e) {
				mainimgdetail = "";
				
			}
			try {
				img1 = this.getTagValue("img1", element);
				System.out.println("img1" + img1);
			} catch (NullPointerException e) {
				img1 = "";
				
			}
			try {
				img1title = this.getTagValue("img1title", element);
				System.out.println("img1title" + img1title);
			} catch (NullPointerException e) {
				img1title = "";
				
			}
			try {
				img2 = this.getTagValue("img2", element);
				System.out.println("img2" + img2);
			} catch (NullPointerException e) {
				img2 = "";
				
			}
			try {
				img2title = this.getTagValue("img2title", element);
				System.out.println("img2title" + img2title);
			} catch (NullPointerException e) {
				img2title = "";
				
			}
			try {
				img3 = this.getTagValue("img3", element);
				System.out.println("img3" + img3);
			} catch (NullPointerException e) {
				img3 = "";
				
			}
			try {
				listimg = this.getTagValue("listimg", element);
				System.out.println("listimg" + listimg);
			} catch (NullPointerException e) {
				listimg = "";
				
			}
			try {
				listimgdetail = this.getTagValue("listimgdetail", element);
				System.out.println("listimgdetail" + listimgdetail);
			} catch (NullPointerException e) {
				listimgdetail = "";
				
			}
			try {
				ldgimg = this.getTagValue("ldgimg", element);
				System.out.println("ldgimg" + ldgimg);
			} catch (NullPointerException e) {
				ldgimg = "";
				
			}
			try {
				ldgImgdetail = this.getTagValue("ldgImgdetail", element);
				System.out.println("ldgImgdetail" + ldgImgdetail);
			} catch (NullPointerException e) {
				ldgImgdetail = "";
				
			}
			try {
				courseimg = this.getTagValue("courseimg", element);
				System.out.println("courseimg" + courseimg);
			} catch (NullPointerException e) {
				courseimg = "";
				
			}
			try {
				courseimgdetail = this.getTagValue("courseimgdetail", element);
				System.out.println("courseimgdetail" + courseimgdetail);
			} catch (NullPointerException e) {
				courseimgdetail = "";
				
			}
			try {
				trafin = this.getTagValue("trafin", element);
				System.out.println("trafin" + trafin);
			} catch (NullPointerException e) {
				trafin = "";
				
			}
			try {
				trafout = this.getTagValue("trafout", element);
				System.out.println("trafout" + trafout);
			} catch (NullPointerException e) {
				trafout = "";
				
			}
			try {
				sellItems = this.getTagValue("sellItems", element);
				System.out.println("sellItems" + sellItems);
			} catch (NullPointerException e) {
				sellItems = "";
				
			}
			try {
				useGiftCerti = this.getTagValue("useGiftCerti", element);
				System.out.println("useGiftCerti" + useGiftCerti);
			} catch (NullPointerException e) {
				useGiftCerti = "";
				
			}
			try {
				disest = this.getTagValue("disest", element);
				System.out.println("disest" + disest);
			} catch (NullPointerException e) {
				disest = "";
				
			}
			try {
				expe = this.getTagValue("expe", element);
				System.out.println("expe" + expe);
			} catch (NullPointerException e) {
				expe = "";
				
			}
			try {
				useest = this.getTagValue("useest", element);
				System.out.println("useest" + useest);
			} catch (NullPointerException e) {
				useest = "";
				
			}
			try {
				mvTrrsrtNm = this.getTagValue("mvTrrsrtNm", element);
				System.out.println("mvTrrsrtNm" + mvTrrsrtNm);
			} catch (NullPointerException e) {
				mvTrrsrtNm = "";
				
			}
			try {
				mvActors = this.getTagValue("mvActors", element);
				System.out.println("mvActors" + mvActors);
			} catch (NullPointerException e) {
				mvActors = "";
				
			}
			try {
				around = this.getTagValue("around", element);
				System.out.println("around" + around);
			} catch (NullPointerException e) {
				around = "";
				
			}
			try {
				etc = this.getTagValue("etc", element);
				System.out.println("etc" + etc);
			} catch (NullPointerException e) {
				etc = "";
				
			}
			try {
				startDate = this.getTagValue("startDate", element);
				System.out.println("startDate" + startDate);
			} catch (NullPointerException e) {
				startDate = "";
				
			}
			try {
				endDate = this.getTagValue("endDate", element);
				System.out.println("endDate" + endDate);
			} catch (NullPointerException e) {
				endDate = "";
				
			}
			try {
				reservation = this.getTagValue("reservation", element);
				System.out.println("reservation" + reservation);
			} catch (NullPointerException e) {
				reservation = "";
				
			}
			try {
				institution = this.getTagValue("institution", element);
				System.out.println("institution" + institution);
			} catch (NullPointerException e) {
				institution = "";
				
			}
			try {
				touCourse = this.getTagValue("touCourse", element);
				System.out.println("touCourse" + touCourse);
			} catch (NullPointerException e) {
				touCourse = "";
				
			}
			try {
				touProduct = this.getTagValue("touProduct", element);
				System.out.println("touProduct" + touProduct);
			} catch (NullPointerException e) {
				touProduct = "";
				
			}
			try {
				touFood = this.getTagValue("touFood", element);
				System.out.println("touFood" + touFood);
			} catch (NullPointerException e) {
				touFood = "";
				
			}
			try {
				touMapinfo = this.getTagValue("touMapinfo", element);
				System.out.println("touMapinfo" + touMapinfo);
			} catch (NullPointerException e) {
				touMapinfo = "";
				
			}
			try {
				category = this.getTagValue("category", element);
				System.out.println("category" + category);
			} catch (NullPointerException e) {
				category = "";
				
			}

//			listOfData.add(new ItemVO(addr, addr2, homepage, latitude, longtitude, time, parking, tel, credit, t_and_m,
//					m_and_p, name, contents, holiday, mainimg, mainimgdetail, img1, img1title, img2, img2title, img3,
//					listimg, listimgdetail, ldgimg, ldgImgdetail, courseimg, courseimgdetail, trafin, trafout,
//					sellItems, useGiftCerti, disest, expe, useest, mvTrrsrtNm, mvActors, around, etc, startDate,
//					endDate, reservation, institution, touCourse, touProduct, touFood, touMapinfo, category));

			System.out.println(count++);

		}
		return listOfData;
	}

	private String getTagValue(String tagName, Element element) {
		NodeList nodeList = element.getElementsByTagName(tagName).item(0).getChildNodes();
		Node node = nodeList.item(0);
		return node.getNodeValue();
	}

}
